<template>
  <div>
    <el-alert title="提示:您可以在本页面查看，添加,删除发现规则以实现服务自动化"
              type="info"
              show-icon
              effect="dark"
              style="margin: 25px; padding: 12px;width:96%">
    </el-alert>
    <el-card style="margin: 25px; padding: 12px">
      <div slot="header">
        <div style="float:left">
          <svg t="1635665058427"
               class="icon"
               viewBox="0 0 1707 1024"
               version="1.1"
               xmlns="http://www.w3.org/2000/svg"
               p-id="3326"
               width="30"
               height="30">
            <path d="M507.75 433.75c0 214.375 173.75 388.125 388.125 388.125s388.125-173.75 388.125-388.125C1284.125 219.375 1110.25 45.625 896 45.625c-214.375 0-388.25 173.75-388.25 388.125z m0 0"
                  fill="#61C6F1"
                  p-id="3327"></path>
            <path d="M845.5 1008.75c-278.5 0-504.375-225.75-504.375-504.375 0-278.5 225.75-504.375 504.375-504.375 278.5 0 504.375 225.75 504.375 504.375 0 278.5-225.875 504.375-504.375 504.375z m0-947.625c-244.75 0-443.25 198.5-443.25 443.25s198.5 443.25 443.25 443.25S1288.75 749.125 1288.75 504.375c0-117.5-46.75-230.25-129.875-313.375S963 61.125 845.5 61.125z m0 0"
                  fill="#333333"
                  p-id="3328"></path>
            <path d="M1112 305.75c-8.875 0-17.375-3.875-23.25-10.75-61-70.875-149.875-111.625-243.25-111.625-16.875 0-30.625-13.75-30.625-30.625s13.625-30.625 30.625-30.625c111.5-0.25 217.625 48.375 290.375 133 7.875 9.125 9.5 22 4.375 33-5.125 11-16.25 17.875-28.25 17.625z m222.5 718.25c-8.125 0-15.875-3.25-21.5-9L1160.125 862.125c-10.375-12.125-9.75-30.25 1.625-41.5 11.25-11.25 29.375-12 41.5-1.625L1356.125 971.875c8.75 8.75 11.25 21.875 6.625 33.25-4.75 11.375-15.875 18.875-28.25 18.875z m0 0"
                  fill="#333333"
                  p-id="3329"></path>
          </svg>
        </div>
        <div style="margin-left:30px;width:97%;height:30px;line-height:30px">
          已添加的发现规则
          <el-button type="primary"
                     size="mini"
                     icon="el-icon-edit"
                     plain
                     style="float:right"
                     @click="getDate()">添加发现规则</el-button>

          <router-link @click.native="get_trigger(scope.$index, scope.row)"
                       :to="{ path: '/monitor/item/'}"
                       replace>
            <el-button type="primary"
                       size="mini"
                       icon="el-icon-edit"
                       plain
                       style="float:right;margin-right:10px">为选定主机安装监控客户端</el-button>
          </router-link>
        </div>
      </DIV>
      <el-table :data="
          tableData.filter(
            (data) =>
              !search ||
              data.priority.toLowerCase().includes(search.toLowerCase()) ||
              data.groupid.toLowerCase().includes(search.toLowerCase()) ||
              data.expression.toLowerCase().includes(search.toLowerCase()) ||
              data.name.toLowerCase().includes(search.toLowerCase()) ||
              data.模板.toLowerCase().includes(search.toLowerCase())
          )
        "
                style="width: 100%"
                stripe>
        <el-table-column type="index"
                         width="50">
        </el-table-column>
        <el-table-column label="发现规则id"
                         prop="druleid"
                         align="center">
        </el-table-column>
        <el-table-column label="发现规则名称"
                         prop="name"
                         align="center">
        </el-table-column>
        <el-table-column label="使用的地址池范围"
                         prop="iprange"
                         align="center">
        </el-table-column>
        <el-table-column label="频率(每*秒)"
                         prop="delay"
                         align="center">
        </el-table-column>
        <el-table-column label="服务状态"
                         prop="status"
                         align="center">
        </el-table-column>
        <el-table-column align="center"
                         width="150">
          <template slot="header"
                    slot-scope="scope">
            <el-input v-model="search"
                      size="mini"
                      placeholder="输入关键字搜索" />
          </template>
          <template slot-scope="scope">
            <el-button type="danger"
                       size="mini"
                       icon="el-icon-delete"
                       circle
                       @click="handleDel(scope.$index, scope.row)"></el-button>
          </template>
        </el-table-column>
      </el-table>
      <el-pagination :current-page="param.currentPage"
                     :page-sizes="[5, 10, 15, 20]"
                     :page-size="param.pagesize"
                     layout="total, sizes, prev, pager, next, jumper"
                     :total="total"
                     @size-change="handleSizeChange"
                     @current-change="handleCurrentChange" />
    </el-card>
    <el-dialog title="添加新的发现规则"
               :visible.sync="dialogVisible"
               width="45%"
               style="padding:150px">
      <el-form ref="$form"
               :model="model"
               label-position="left"
               label-width="100px"
               size="small">
        <el-form-item label="请输入发现规则的名称"
                      label-width="210px">
          <el-input v-model="model.drule_name"
                    placeholder="请输入"
                    style="width:250px"
                    clearable></el-input>
        </el-form-item>
        <el-form-item label="请输入发现规则的地址池范围，格式192.168.72.1-254"
                      label-width="210px">
          <el-input v-model="model.drule_iprange"
                    placeholder="请输入"
                    style="width:250px"
                    clearable></el-input>
        </el-form-item>
        <el-form-item label="请输入发现的时间频率，每*秒。输入整数"
                      label-width="210px">
          <el-input v-model="model.drule_delay"
                    placeholder="请输入"
                    clearable
                    style="width:250px"></el-input>
        </el-form-item>
        <el-form-item label="请选择发现主机后要添加的主机群组"
                      label-width="210px">
          <el-select v-model="model.drule_host_group"
                     placeholder="请选择"
                     style="width:250px">
            <el-option v-for="(item, $index) in host_group_data"
                       :key="item.groupid"
                       :label="item.name"
                       :value="item.groupid"
                       :disabled="!!item.disabled"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="请选择发现主机后要使用的监控模板"
                      label-width="210px">
          <el-select v-model="model.drule_host_template"
                     placeholder="请选择"
                     style="width:250px">
            <el-option v-for="(item, $index) in host_template_data"
                       :key="item.templateid"
                       :label="item.name"
                       :value="item.templateid"
                       :disabled="!!item.disabled"></el-option>
          </el-select>
        </el-form-item>
      </el-form>
      <span slot="footer"
            class="dialog-footer">
        <el-button @click="dialogVisible = false">取 消</el-button>
        <el-button type="primary"
                   @click="adddrule">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
import cons from "@/components/constant";

export default {
  data () {
    return {
      tableData: [],
      dialogVisible: false,
      search: "",
      value: '',
      param: {
        currentPage: 1, // 当前页
        pagesize: 5, // 默认每页多少张
        hostid: ''
      },
      model: {
        drule_name: "",
        drule_iprange: "",
        drule_delay: "",
        drule_host_group: "",
        drule_host_template: "",
      },
      total: 0, // 共多少页
      join: null,
      host_group_data: null,
      host_template_data: null,
      submit_loading: false,
    };
  },

  mounted () {
    this.getList();
  },

  methods: {

    //获取基本数据
    getList: function (num) {
      const vm = this;
      this.$http
        .post(cons.apis + "/get/drules/", vm.param, {
          responseType: "json",
        })
        .then((res) => {
          if (res.data.code == 200)
          {
            console.log(res.data.data);
            vm.total = res.data.total;
            vm.tableData = res.data.data;
          }
        })
        .catch((err) => {
          console.log(err);
        });
    },

    //删除指定内容
    handleDel (index, row) {
      console.log(row.hostgroupid);
      this.$http
        .get(
          cons.apis + "/del/drule/?druleid=" + row.druleid,
          {
            responseType: "json",
          }
        )
        .then((res) => {
          if (res.data.code == 200)
          {
            // console.log(res.data.data);
            this.getList();
            this.$notify({
              title: "恭喜你",
              message: "删除主机群组成功啦",
              type: "success",
            });

          }
          else
          {
            console.log(res);
            alert("Cannot delete")
          }
        })
        .catch((err) => {
          console.log(err);
        });
    },

    //以下两个是分页功能的实现
    handleSizeChange: function (size) {
      const a = this;
      a.param.pagesize = size;
      this.getList();
      console.log(a.param.pagesize); // 每页下拉显示数据
    },
    handleCurrentChange: function (currentPage) {
      const b = this;
      b.param.currentPage = currentPage;
      console.log(this.currentPage); // 点击第几页
      this.getList();
    },

    //添加主机群组
    adddrule () {
      this.dialogVisible = false;
      const vm = this;
      console.log(this.model);
      this.$http
        .post(cons.apis + "/add/drule/", vm.model, {
          responseType: "json",
        })
        .then((res) => {
          if (res.data.code == 200)
          {
            // console.log(res.data.data);
            this.$notify({
              title: "恭喜你",
              message: "创建发现规则成功啦",
              type: "success",
            });
            this.$router.go(0);
          }
        })
        .catch((err) => {
          console.log(err);
          this.$notify({
            title: "失败啦",
            message: "你个鳖孙，创建发现规则失败啦",
            type: "error",
          });
        });
    },
    //添加前获取数据
    getDate () {
      this.dialogVisible = true;
      this.$http
        .get(cons.apis + "/get/hostdate/", {
          responseType: "json",
        })
        .then((res) => {
          if (res.data.code == 200)
          {
            console.log(res.data.data);
            this.host_group_data = res.data.data[0];
            this.host_template_data = res.data.data[1];
          }
        })
        .catch((err) => {
          console.log(err);
          vm.$message.error("又出错了");
        });
    },
  },
};
</script>

<style>
</style>
