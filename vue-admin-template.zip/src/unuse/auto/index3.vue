<!--  -->
<template>
  <div></div>
</template>

<script>
import Utils from '@/utils/crypto.js'
export default {
  data () {
    return {
      a: {
        "sites": [
          { "name": "Runoob", "url": "www.runoob.com" }
        ]
      }
    };
  },


  mounted () {
    this.a = JSON.stringify(this.a)
    var jiami = Utils.encrypt(this.a);
    console.log(jiami)
    var jiemi = Utils.decrypt(jiami);
    console.log(jiemi)
  },

  methods: {}
}

</script>
<style lang='less' scoped>
</style>