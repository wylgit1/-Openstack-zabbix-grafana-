<template>
  <div>

    <el-alert title="提示:您可以在添加,查看，删除主机监控项"
              type="info"
              show-icon
              effect="dark"
              style="margin: 25px; padding: 12px;width:96%">
    </el-alert>
    <el-card style="margin: 25px; padding: 12px">

      <div slot="header">
        <div style="float:left">
          <svg t="1635682143547"
               class="icon"
               viewBox="0 0 1141 1024"
               version="1.1"
               xmlns="http://www.w3.org/2000/svg"
               p-id="4261"
               width="30"
               height="30">
            <path d="M1140.483293 937.937675v-715.169869a72.962543 72.962543 0 0 0-65.810845-79.505586 82.472781 82.472781 0 0 0-13.694742 0H613.235719a70.109472 70.109472 0 0 1-41.464636-12.553514s-19.020475-31.573989-54.01815-82.548863c-31.573989-57.061426-73.038625-47.551188-73.038625-47.551188h-346.172649a92.0591 92.0591 0 0 0-98.145652 85.592139 36.861681 36.861681 0 0 0-0.38041 6.466961v838.802959c0 104.612614 79.505587 92.0591 79.505587 92.0591h991.347169c82.548863 0 69.614939-85.592139 69.61494-85.592139zM289.126821 756.482341h-3.804095a58.811309 58.811309 0 0 1-56.681017-60.104701v-4.184505a58.316777 58.316777 0 0 1 60.485112-56.300607 60.294907 60.294907 0 1 1 0 120.589813z m0-225.582836h-3.804095a58.773269 58.773269 0 0 1-56.681017-60.104702 60.485111 60.485111 0 1 1 60.485112 60.104702z m590.775961 222.53956H498.732458a57.25163 57.25163 0 0 1 0-114.503261h381.170324a57.25163 57.25163 0 1 1 0 114.503261z m0-225.582836H498.732458a57.25163 57.25163 0 0 1 0-114.503261h381.170324a57.25163 57.25163 0 1 1 0 114.503261z"
                  fill="#2D9EF4"
                  p-id="4262"></path>
          </svg>
        </div>
        <div style="margin-left:30px;width:97%;height:30px;line-height:30px">
          <el-button type="primary"
                     size="mini"
                     icon="el-icon-edit"
                     plain
                     style="float:right"
                     @click="getDate()">添加监控项</el-button>
        </div>
      </div>
      <el-table :data="
          tableData.filter(
            (data) =>
              !search ||
              data.priority.toLowerCase().includes(search.toLowerCase()) ||
              data.triggerid.toLowerCase().includes(search.toLowerCase()) ||
              data.expression.toLowerCase().includes(search.toLowerCase()) ||
              data.description.toLowerCase().includes(search.toLowerCase()) ||
              data.templateid.toLowerCase().includes(search.toLowerCase())
          )
        "
                style="width: 100%"
                stripe>
        <el-table-column type="index"
                         width="50">
        </el-table-column>
        <el-table-column label="监控项id"
                         prop="itemid"
                         align="center">
        </el-table-column>
        <el-table-column label="监控项名称"
                         prop="name"
                         align="center">
        </el-table-column>
        <el-table-column label="监控项key"
                         prop="key_"
                         align="center">
        </el-table-column>
        <el-table-column align="center"
                         width="150">
          <template slot="header"
                    slot-scope="scope">
            <el-input v-model="search"
                      size="mini"
                      placeholder="输入关键字搜索" />
          </template>
          <template slot-scope="scope">
            <el-button type="danger"
                       size="mini"
                       icon="el-icon-delete"
                       circle
                       @click="handleDel(scope.$index, scope.row)"></el-button>
          </template>
        </el-table-column>
      </el-table>
      <el-pagination :current-page="param.currentPage"
                     :page-sizes="[5, 10, 15, 20]"
                     :page-size="param.pagesize"
                     layout="total, sizes, prev, pager, next, jumper"
                     :total="total"
                     @size-change="handleSizeChange"
                     @current-change="handleCurrentChange" />
    </el-card>
    <el-dialog title="添加监控项"
               :visible.sync="dialogVisible"
               width="50%">

      <el-form ref="$form"
               :model="model"
               label-position="left"
               label-width="100px"
               size="small">
        <el-form-item label="请输入要添加的监控项名称:"
                      label-width="200px">
          <el-input v-model="model.item_name"
                    placeholder="请输入"
                    style="width:250px;margin-left:170px"
                    clearable></el-input>
        </el-form-item>
        <el-form-item label="请输入监控项键值，如果需要脚本，请上传:"
                      label-width="200px">
          <el-input type="textarea"
                    style="width:250px;"
                    v-model="model.item_key"></el-input>

          <el-upload class="upload-demo"
                     action="http://192.168.1.168:8000/get/file/"
                     :on-preview="handlePreview"
                     :on-remove="handleRemove"
                     :before-remove="beforeRemove"
                     multiple
                     :limit="3"
                     :on-exceed="handleExceed"
                     style="float:right">

            <el-button size="small"
                       type="primary">点击上传</el-button>
            <div slot="tip"
                 class="el-upload__tip">上传脚本文件，支持多个，只能在同级目录调用</div>
          </el-upload>

        </el-form-item>
        <el-form-item label="请输入要添加的监控项的信息类型，数据类型和单位:"
                      label-width="200px">
          <el-select v-model="model.item_data_type"
                     placeholder="信息类型"
                     style="width:180px">
            <el-option v-for="(item, $index) in value_type"
                       :key="item.value"
                       :label="item.label"
                       :value="item.value"
                       :disabled="!!item.disabled"></el-option>
          </el-select>
          <el-select v-model="model.item_shuju_type"
                     placeholder="数据类型"
                     style="width:180px;margin-left:5px">
            <el-option v-for="(item, $index) in data_type"
                       :key="item.value"
                       :label="item.label"
                       :value="item.value"
                       :disabled="!!item.disabled"></el-option>
          </el-select>
          <el-input v-model="model.unit"
                    placeholder="请输入监控项单位"
                    style="width:180px;margin-left:5px"
                    clearable></el-input>
        </el-form-item>
        <el-form-item label="请输入要添加的监控项的应用集:"
                      label-width="200px">
          <el-select v-model="model.item_application"
                     placeholder="请选择"
                     multiple
                     style="width:250px;margin-left:170px">
            <el-option v-for="(item, $index) in application_data"
                       :key="item.applicationid"
                       :label="item.name"
                       :value="item.applicationid"
                       :disabled="!!item.disabled"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item 
                      label="请输入对要添加监控项的描述:"
                      label-width="200px">
          <el-input type="textarea"
                    v-model="model.item_desc"></el-input>
        </el-form-item>
      </el-form>
      <span slot="footer"
            class="dialog-footer">
        <el-button @click="dialogVisible = false">取 消</el-button>
        <el-button type="primary"
                   @click="createitem()">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
import cons from "@/components/constant";
import {getapplication} from "@/api/application"

export default {
  data () {
    return {
      tableData: [],
      dialogVisible: false,
      search: "",
      value: '100',
      param: {
        currentPage: 1, // 当前页
        pagesize: 5, // 默认每页多少张
        hostid: ''
      },
      total: 0, // 共多少页
      join: null,
      forms: ["$form"],
      model: {
        'unit':''
      },
      value_type: [{
        value: 0,
        label: "numeric float"
      }, {
        value: 1,
        label: "character"
      }, {
        value: 2,
        label: "log"
      }, {
        value: 3,
        label: "numeric unsigned"
      }, {
        value: 4,
        label: "text"
      }
      ],
      data_type: [{
        value: 0, label: "decimal(default)"
      },
      { value: 1, label: "octal" },
      { value: 2, label: "hexadecimal" },
      { value: 3, label: "boolean" }

      ],
      application_data: null,
      submit_loading: false,
    };
  },

  mounted () {
    this.getList()
    console.log(localStorage.token)
  },

  methods: {

    //获取基本数据
    getList: function (num) {
      let token = localStorage.token;
      const vm = this;
      vm.param.hostid = sessionStorage.getItem('hostid')
      console.log(vm.param);
      this.$http
        .post(cons.apis + "/get/host_item_date/", vm.param, {
          responseType: "json",
        })
        .then((res) => {
          if (res.data.code == 200)
          {
            console.log(res.data.data);
            vm.total = res.data.total;
            vm.tableData = res.data.data;
          }
        })
        .catch((err) => {
          console.log(err);
        });
    },

    //删除指定内容
    handleDel (index, row) {
      console.log(row.triggerid);
      this.$http
        .get(
          cons.apis + "/del/item/?itemid=" + row.itemid,
          {
            responseType: "json",
          }
        )
        .then((res) => {
          if (res.data.code == 200)
          {
            // console.log(res.data.data);
            this.getList();
          }
          else
          {
            console.log(res);
            alert("Cannot delete templated item")
          }
        })
        .catch((err) => {
          console.log(err);
        });
    },

    //以下两个是分页功能的实现
    handleSizeChange: function (size) {
      const a = this;
      a.param.pagesize = size;
      this.getList();
      console.log(a.param.pagesize); // 每页下拉显示数据
    },
    handleCurrentChange: function (currentPage) {
      const b = this;
      b.param.currentPage = currentPage;
      console.log(this.currentPage); // 点击第几页
      this.getList();
    },

    //添加内容前获取基本信息
    getDate () {
      this.dialogVisible = true;
      let vm = this;
      getapplication(sessionStorage.getItem('hostid'), {
          responseType: "json",
        })
        .then((res) => {
          if (res.data.code == 200)
          {
            console.log(res.data);
            vm.application_data = res.data.applications;
            // vm.host_template_data = res.data.data[1];
          }
        })
        .catch((err) => {
          console.log(err);
          vm.$message.error("又出错了");
        });
    },
    handleRemove (file, fileList) {
      console.log(file, fileList);
    },
    handlePreview (file) {
      console.log(file);
    },
    //文件上传相关
    handleExceed (files, fileList) {
      this.$message.warning(`当前限制选择 1 个文件，本次选择了 ${files.length} 个文件，共选择了 ${files.length + fileList.length} 个文件`);
    },
    beforeRemove (file, fileList) {
      return this.$confirm(`确定移除 ${file.name}？`);
    },

    onBeforeUploadImage (file, fileList) {

      if (this.formData.length == 0)
      {
        this.formData = new FormData();
      }

      this.formData.append('file', file.file);
    },

    //创建监控项
    createitem () {
      this.dialogVisible = false;
      const vm = this;
      vm.model.hostid = sessionStorage.getItem('hostid')
      console.log(this.model);
      this.$http
        .post(cons.apis + "/create/item/", vm.model, {
          responseType: "json",
        })
        .then((res) => {
          if (res.data.code == 200)
          {
            // console.log(res.data.data);
            this.$notify({
              title: "恭喜你",
              message: "创建主机成功啦",
              type: "success",
            });
          }
        })
        .catch((err) => {
          console.log(err);
          this.$notify({
            title: "失败啦",
            message: "你个鳖孙，创建主机失败啦",
            type: "error",
          });
        });
    }

  },
};
</script>