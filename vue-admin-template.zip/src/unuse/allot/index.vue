<template>
   <el-card style="margin: 25px; padding: 12px">
  <el-table
      :data="vm"
      style="width: 100%">
      <el-table-column
        prop="VM_name"
        label="主机"
        width="180">
      </el-table-column>
      <el-table-column
        prop="nickname"
        label="用户"
        width="180">
      </el-table-column>
      <el-table-column
        prop="username"
        label="用户更改">
        <template slot-scope="scope">
        <el-select  v-model="scope.row[scope.column.property]" placeholder="请选择">
            <el-option
                v-for="(index,value,key) in usernames"
                :key="value"
                :label="key['username']"
                :value="key['username']">
            </el-option>
        </el-select>
        </template>
      </el-table-column>
      <el-table-column label="操作">
      <template slot-scope="scope">
        <el-button
          size="mini"
          @click="handleEdit(scope.$index, scope.row)">确定</el-button>
      </template>
    </el-table-column>
    </el-table>
   </el-card>
</template>

<script>
import cons from "@/components/constant";
import { getVM } from "@/api/vmManagement";
import {getUsername} from "@/api/user"

export default {
    data() {
        return {
            tabledata:[],
            users:[
            ],
            usernames:[],
            vm:[
                {
                VM_name:"",
                nickname: "",
                username:''
                }
            ],

        }
    },
    mounted(){
        this.getVMMessage();
        this.getUserMessage();
      },
    methods:{
        // getVMMessage(){
        //   this.$http
        // .get(cons.apis + "/virtual_machines/", this.vm, {
        //   responseType: "json",
        // })
        // .then((res) => {
        //   if (res.status == 200) {
        //     console.log("###");
        //     // console.log(res.data);
        //     this.vm =  res.data;
        //     console.log(this.vm);
        //   }
        // })
        // .catch((err) => {
        //   console.log(err);
        // });
        // },
        getVMMessage() {
          getVM()
        .then((res) => {
          this.vm = res.data;         
        })
        .catch((err) => {
          console.log(err);
        });
    },
    getUsernames() {
      getUsername()
        .then((res) => {
          this.usernames = res.data;
          console.log(this.usernames);
        })
        .catch((err) => {
          console.log(err);
        });
    },
        // getUserMessage(){
        //   this.$http
        // .get(cons.apis + "/users/",this.users, {
        //   responseType: "json",
        // })
        // .then((res) => {
        //   if (res.status == 200) {
        //     console.log("###");
        //     this.users =res.data;
        //     console.log(this.users);
        //     for (let index = 0; index < this.users.length; index++) {
        //          this.usernames[index]=this.users[index].username
        //     }
        //     this.usernames=Object.assign({}, this.usernames);
        //     // this.usernames=JSON.stringify(this.usernames);

        //     console.log(this.usernames);

        //   }
        // })
        // .catch((err) => {
        //   console.log(err);
        // });
        // },
        handleEdit(){
          this.$http
        .post(cons.apis + "/virtual_machine/",this.vm,{
          responseType: "json",
        })
        .then((res) => {
          if (res.status == 200) {
            console.log(res.data);
            this.tableData = res.data;
          }
        })
        .catch((err) => {
          console.log(err);
        });
        }
    }
}
</script>

<style>

</style>