<template>

  <div>
    <el-alert title="提示:您可以在添加,查看，删除主机"
              type="info"
              show-icon
              effect="dark"
              style="margin: 25px; padding: 12px;width:96%">
    </el-alert>

    <el-card style="margin: 25px; padding: 12px">
      <div slot="header">
        <div style="float:left">
          <svg t="1635681306066"
               class="icon"
               viewBox="0 0 1024 1024"
               version="1.1"
               xmlns="http://www.w3.org/2000/svg"
               p-id="2801"
               width="30"
               height="30">
            <path d="M778.9 166.2H344.7c-24 0-43.4 19.4-43.4 43.4v651.2c0 24 19.4 43.4 43.4 43.4h434.2c24 0 43.4-19.4 43.4-43.4V209.7c0-24-19.4-43.5-43.4-43.5zM778.9 948.9H344.7c-18 0-32.6 14.6-32.6 32.6s14.6 32.6 32.6 32.6h434.2c18 0 32.6-14.6 32.6-32.6-0.1-18-14.6-32.6-32.6-32.6z"
                  fill="#4DBBF7"
                  p-id="2802"></path>
            <path d="M670.3 101.1v694.7H236.2V101.1h434.1m0-65.1H236.2c-36 0-65.1 29.2-65.1 65.1v694.7c0 36 29.2 65.1 65.1 65.1h434.2c36 0 65.1-29.2 65.1-65.1V101.1c0-35.9-29.2-65.1-65.2-65.1z"
                  fill=""
                  p-id="2803"></path>
            <path d="M583.5 249.9H323c-18 0-32.6-14.6-32.6-32.6s14.6-32.6 32.6-32.6h260.5c18 0 32.6 14.6 32.6 32.6s-14.6 32.6-32.6 32.6zM583.5 401.8H323c-18 0-32.6-14.6-32.6-32.6s14.6-32.6 32.6-32.6h260.5c18 0 32.6 14.6 32.6 32.6 0 18.1-14.6 32.6-32.6 32.6z"
                  fill=""
                  p-id="2804"></path>
            <path d="M453.3 684m-43.4 0a43.4 43.4 0 1 0 86.8 0 43.4 43.4 0 1 0-86.8 0Z"
                  fill=""
                  p-id="2805"></path>
            <path d="M670.3 948.9H236.2c-18 0-32.6-14.6-32.6-32.6s14.6-32.6 32.6-32.6h434.2c18 0 32.6 14.6 32.6 32.6-0.1 18-14.7 32.6-32.7 32.6z"
                  fill="#231815"
                  p-id="2806"></path>
          </svg>
        </div>
        <div style="margin-left:30px;width:97%;height:30px;line-height:30px">
          <el-button type="primary"
                     size="mini"
                     icon="el-icon-edit"
                     plain
                     style="float:right"
                     @click="getDate()">添加主机</el-button>
        </div>
      </div>
      <el-table :data="
          tableData.filter(
            (data) =>
              !search ||
              data.priority.toLowerCase().includes(search.toLowerCase()) ||
              data.triggerid.toLowerCase().includes(search.toLowerCase()) ||
              data.expression.toLowerCase().includes(search.toLowerCase()) ||
              data.description.toLowerCase().includes(search.toLowerCase()) ||
              data.templateid.toLowerCase().includes(search.toLowerCase())
          )
        "
                style="width: 100%"
                stripe>
        <el-table-column label="主机id"
                         prop="hostid"
                         width="110"
                         align="center">
        </el-table-column>
        <el-table-column label="主机名称"
                         prop="name"
                         width="150"
                         align="center">
        </el-table-column>
        <el-table-column label="应用集"
                         prop="hostid"
                         align="center">
          <template slot-scope="scope">
            <el-link type="primary">
              <router-link @click.native="get_trigger(scope.$index, scope.row)"
                           :to="{ path: '/monitor/application/'}"
                           replace>应用集
              </router-link>
            </el-link>
          </template>
        </el-table-column>

        <el-table-column label="监控项"
                         prop="hostid"
                         align="center">
          <template slot-scope="scope">
            <el-link type="success">
              <router-link @click.native="get_trigger(scope.$index, scope.row)"
                           :to="{ path: '/monitor/item/'}"
                           replace>监控项
              </router-link>
            </el-link>
          </template>
        </el-table-column>

        <el-table-column label="触发器"
                         prop="hostid"
                         align="center">
          <template slot-scope="scope">
            <el-link type="warning">
              <router-link @click.native="get_trigger(scope.$index, scope.row)"
                           :to="{ path: '/monitor/trigger/'}"
                           replace>触发器
              </router-link>
            </el-link>
          </template>
        </el-table-column>
        <el-table-column label="运行状态"
                         align="center">
          <el-tooltip :content="'Switch value: ' + value"
                      placement="top">
            <el-switch v-model="value"
                       active-color="#13ce66"
                       inactive-color="#ff4949"
                       active-value="100"
                       inactive-value="0">
            </el-switch>
          </el-tooltip>

        </el-table-column>
        <el-table-column label="主机ip"
                         prop="interfaces[0].ip"
                         align="center"></el-table-column>
        <el-table-column align="center"
                         width="150">
          <template slot="header"
                    slot-scope="scope">
            <el-input v-model="search"
                      size="mini"
                      placeholder="输入关键字搜索" />
          </template>
          <template slot-scope="scope">
            <el-button type="danger"
                       size="mini"
                       icon="el-icon-delete"
                       circle
                       @click="handleDel(scope.$index, scope.row)"></el-button>
          </template>
        </el-table-column>
      </el-table>
      <el-pagination :current-page="param.currentPage"
                     :page-sizes="[5, 10, 15, 20]"
                     :page-size="param.pagesize"
                     layout="total, sizes, prev, pager, next, jumper"
                     :total="total"
                     @size-change="handleSizeChange"
                     @current-change="handleCurrentChange" />
    </el-card>
    <el-dialog title="添加主机"
               :visible.sync="dialogVisible"
               width="50%">
      <el-form ref="$form"
               :model="model"
               label-position="left"
               label-width="100px"
               size="small">
        <el-divider content-position="left">手动添加主机(主机需提前安装好监控客户端)</el-divider>
        <el-form-item prop="host_name"
                      label="请输入主机名"
                      label-width="120px">
          <el-input v-model="model.host_name"
                    placeholder="请输入"
                    clearable></el-input>
        </el-form-item>
        <el-form-item prop="host_ip"
                      label="请输入主机ip"
                      label-width="120px">
          <el-input v-model="model.host_ip"
                    placeholder="请输入"
                    clearable></el-input>
        </el-form-item>
        <el-form-item prop="host_group"
                      label="请选择主机群组"
                      label-width="120px">
          <el-select v-model="model.host_group"
                     placeholder="请选择"
                     :style="{ width: '100%' }">
            <el-option v-for="(item, $index) in host_group_data"
                       :key="item.groupid"
                       :label="item.name"
                       :value="item.groupid"
                       :disabled="!!item.disabled"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item prop="host_template"
                      label="请选择模板"
                      label-width="120px">
          <el-select v-model="model.host_template"
                     placeholder="请选择"
                     :style="{ width: '100%' }">
            <el-option v-for="(item, $index) in host_template_data"
                       :key="item.templateid"
                       :label="item.name"
                       :value="item.templateid"
                       :disabled="!!item.disabled"></el-option>
          </el-select>
        </el-form-item>
        <el-divider content-position="left">自动添加(请配合自动化一起使用)</el-divider>
        <!-- <el-form-item prop="host_ip"
                      label="请输入主机ip"
                      label-width="120px">
          <el-input v-model="model.host_ip2"
                    placeholder="请输入"
                    clearable></el-input>
        </el-form-item> -->
        <!-- 这是穿梭框 -->
        <el-transfer v-model="model.rightData"
                     :props="{key: 'value',label: 'label'}"
                     :titles="['所有主机', '预添加的主机']"
                     @change="handleChange"
                     :data="model.liftData"></el-transfer>

      </el-form>
      <span slot="footer"
            class="dialog-footer">
        <el-button @click="dialogVisible = false">取 消</el-button>
        <el-button type="primary"
                   @click="createHost">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
import cons from "@/components/constant";

export default {
  data () {

    return {
      fileArr: [], //穿梭框文件列表
      tableData: [],
      search: "",
      value: '100',
      param: {
        currentPage: 1, // 当前页
        pagesize: 5, // 默认每页多少张
      },
      total: 0, // 共多少页
      join: null,
      dialogVisible: false,
      forms: ["$form"],
      noData: [{ id: "a", name: '测试1' }, { id: "b", name: '测试2' }],
      yesData: ["a"],
      model: {
        host_name: "",
        host_ip: "",
        host_group: "",
        host_template: "",
        liftData: [], //穿梭框文件id数组
        rightData: [], // 注意:key 的字符类型要一致!!!
      },
      host_group_data: null,
      host_template_data: [
        {
          label: "选项1",
          value: "1",
          disabled: false,
        },
      ],
      submit_loading: false,
    };
  },
  mounted () {
    this.getList();
    sessionStorage.removeItem('hostid')
  },

  methods: {
    handleDel (index, row) {
      // console.log(row);
      this.$http
        .get(
          cons.apis + "/del/host/?hostid=" + row.hostid,

          {
            responseType: "json",
          }
        )
        .then((res) => {
          if (res.data.code == 200)
          {
            // console.log(res.data.data);
            this.getList();
          }
        })
        .catch((err) => {
          console.log(err);
        });
    },
    handleSizeChange: function (size) {
      const a = this;
      a.param.pagesize = size;
      this.getList();
      console.log(a.param.pagesize); // 每页下拉显示数据
    },
    handleCurrentChange: function (currentPage) {
      const b = this;
      b.param.currentPage = currentPage;
      console.log(this.currentPage); // 点击第几页
      this.getList();
    },
    getList: function (num) {
      let token = localStorage.token;
      const vm = this;
      console.log(vm.param);
      this.$http
        .post(cons.apis + "/get/hosts_data/", vm.param, {
          responseType: "json",
        })
        .then((res) => {
          if (res.data.code == 200)
          {
            console.log(res.data.data);
            vm.total = res.data.total;
            vm.tableData = res.data.data;
          }
        })
        .catch((err) => {
          console.log(err);
        });
    },
    // 获取创建主机的必要数据
    getDate () {
      this.dialogVisible = true;
      this.getHostsAlready();
      let vm = this;
      this.$http
        .get(cons.apis + "/get/hostdate/", {
          responseType: "json",
        })
        .then((res) => {
          if (res.data.code == 200)
          {
            console.log(res.data.data);
            vm.host_group_data = res.data.data[0];
            vm.host_template_data = res.data.data[1];
          }
        })
        .catch((err) => {
          console.log(err);
          vm.$message.error("又出错了");
        });
    },
    //开始创建主机
    createHost () {
      this.dialogVisible = false;
      const vm = this;
      console.log(this.model);
      this.$http
        .post(cons.apis + "/create/host/", vm.model, {
          responseType: "json",
        })
        .then((res) => {
          if (res.data.code == 200)
          {
            // console.log(res.data.data);
            this.$message('删除成功');
          }
        })
        .catch((err) => {
          console.log(err);
          this.$notify({
            title: "失败啦",
            message: "你个鳖孙，创建主机失败啦",
            type: "error",
          });
        });
    },
    //获取穿梭框需要的数据
    getHostsAlready () {
      this.$http
        .get(
          cons.apis + "/get/hosts_already/",
          {
            responseType: "json",
          }
        )
        .then((res) => {
          if (res.data.code == 200)
          {
            console.log(res.data.data);
            this.model.liftData = res.data.data

          }
        })
        .catch((err) => {
          console.log(err);
        });
    },
    //穿梭框测试
    handleChange (value, direction, movedKeys) {
      console.log(value, direction, movedKeys);
    },
    get_trigger (index, row) {
      console.log(row.hostid)
      sessionStorage.setItem('hostid', row.hostid)
    },
  },
}
</script>