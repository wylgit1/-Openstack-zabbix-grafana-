<template>
  <div>
    <el-card style="margin: 25px; padding: 12px">
      <el-table
        :data="
          tableData.filter(
            (data) =>
              !search ||
              data.priority.toLowerCase().includes(search.toLowerCase()) ||
              data.triggerid.toLowerCase().includes(search.toLowerCase()) ||
              data.expression.toLowerCase().includes(search.toLowerCase()) ||
              data.description.toLowerCase().includes(search.toLowerCase()) ||
              data.templateid.toLowerCase().includes(search.toLowerCase())
          )
        "
        style="width: 100%"
        stripe
      >
        <el-table-column
          label="触发器id"
          prop="triggerid"
          width="110"
          align="center"
        >
        </el-table-column>
        <el-table-column
          label="触发器优先级"
          prop="priority"
          width="150"
          align="center"
        >
        </el-table-column>
        <el-table-column label="故障标识符" prop="expression">
        </el-table-column>
        <el-table-column label="触发器描述" prop="description">
        </el-table-column>
        <el-table-column
          label="触发器模板id"
          prop="templateid"
          width="150"
          align="center"
        >
        </el-table-column>
        <el-table-column align="center" width="150">
          <template slot="header" slot-scope="scope">
            <el-input
              v-model="search"
              size="mini"
              placeholder="输入关键字搜索"
            />
          </template>
          <template slot-scope="scope">
            <el-button
              prop="status"
              size="mini"
              type="primary"
              @click="handleEdit(scope.$index, scope.row)"
              v-show="!scope.row.status"
              >自动排错</el-button
            >
            <el-button
              prop="status"
              size="mini"
              type="info"
              @click="handle(scope.$index, scope.row)"
              v-show="scope.row.status"
              style="margin-left: 0px"
              >创建动作</el-button
            >
          </template>
        </el-table-column>
      </el-table>
      <el-pagination
        :current-page="param.currentPage"
        :page-sizes="[5, 10, 15, 20]"
        :page-size="param.pagesize"
        layout="total, sizes, prev, pager, next, jumper"
        :total="total"
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
      />
    </el-card>
  </div>
</template>

<script>
import cons from "@/components/constant";

export default {
  data() {
    return {
      tableData: [],
      search: "",
      param: {
        currentPage: 1, // 当前页
        pagesize: 5, // 默认每页多少张
      },
      total: 0, // 共多少页
      join: null,
    };
  },

  mounted() {
    this.getList();
    // this.getinfo();
    setInterval(() => {
      // 这里调用调用需要执行的方法，1为自定义的参数，由于特殊的需求它将用来区分，定时器调用和手工调用，然后执行不同的业务逻辑
      this.getList();
    }, 1200000);
  },

  methods: {
    handleEdit(index, row) {
      // console.log(index, row);
      // 获取到triggerid
      console.log(row);
      // 发送请求查找智能库是否包含此类故障
      this.$http
        .get(
          cons.apis +
            "/repair?triggerid=" +
            row.triggerid +
            "&&expression=" +
            row.expression,
          {
            responseType: "json",
          }
        )
        .then((res) => {
          if (res.data.code == 200) {
            console.log(res.data.data);
            // vm.total = res.data.total;
            // vm.tableData = res.data.data;
            this.join = false;
          }
        })
        .catch((err) => {
          console.log(err);
        });
    },
    handle(index, row) {
      console.log(index, row);
      this.$router.push("/action/index");
    },
    handleSizeChange: function (size) {
      const a = this;
      a.param.pagesize = size;
      this.getList();
      console.log(a.param.pagesize); // 每页下拉显示数据
    },
    handleCurrentChange: function (currentPage) {
      const b = this;
      b.param.currentPage = currentPage;
      console.log(this.currentPage); // 点击第几页
      this.getList();
    },

    getList: function (num) {
      let token = sessionStorage.token;
      const vm = this;
      this.$http
        .post(cons.apis + "/get/alerts/", vm.param, {
          headers: {
            Authorization: "JWT " + token,
          },
          responseType: "json",
        })
        .then((res) => {
          if (res.data.code == 200) {
            console.log(res.data.data);
            vm.total = res.data.total;
            vm.tableData = res.data.data;
          }
        })
        .catch((err) => {
          console.log(err);
        });
    },
  },
};
</script>