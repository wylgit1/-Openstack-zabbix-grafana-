<template>

  <div>
    <el-alert title="提示:您可以在添加,查看，删除主机"
              type="info"
              show-icon
              effect="dark"
              style="margin: 25px; padding: 12px;width:96%">
    </el-alert>

    <el-card style="margin: 25px; padding: 12px">
      <div slot="header">
        <div style="float:left">
          <svg t="1636096754378"
               class="icon"
               viewBox="0 0 1024 1024"
               version="1.1"
               xmlns="http://www.w3.org/2000/svg"
               p-id="2434"
               width="30"
               height="30">
            <path d="M512 512m-448 0a448 448 0 1 0 896 0 448 448 0 1 0-896 0Z"
                  fill="#CE924C"
                  p-id="2435"></path>
            <path d="M608.4 260.2c-85 0-154.7 69.8-154.7 154.7v1.3c0 7.6 5.1 12.7 12.7 12.7s12.7-5.1 12.7-12.7c0-72.3 58.3-129.4 130.6-129.4S739 345.2 739 417.5c0 71-58.3 129.4-129.4 129.4h-1.3c-7.6 0-12.7 5.1-12.7 12.7 0 6.3 5.1 12.7 12.7 12.7h3.8c40.6-1.3 78.6-17.8 107.8-46.9 29.2-29.2 44.4-67.2 44.4-109.1 0.1-87.6-69.7-156.1-155.9-156.1z"
                  fill="#FFFFFF"
                  p-id="2436"></path>
            <path d="M668 415c0-33-26.6-59.6-59.6-60.9-33 0-59.6 26.6-60.9 60.9 0 33 26.6 59.6 60.9 59.6 33 0 59.6-26.6 59.6-59.6z m-95.1 0c0-19 15.2-35.5 35.5-35.5 19 0 35.5 15.2 35.5 35.5 0 19-15.2 35.5-35.5 35.5-19 0-35.5-16.5-35.5-35.5zM545 560.8c-3.8 0-7.6 1.3-10.1 5.1l-2.5 2.5-88.8 104h-69.8v63.4h-86.2v-62.1l169.9-185.2v-1.3c2.5-2.5 3.8-5.1 3.8-8.9 0-6.3-5.1-12.7-12.7-12.7-3.8 0-6.3 1.3-8.9 3.8l-2.5 2.5-175 191.5v96.4h137v-63.4h57.1L554 582.3V581c2.5-2.5 3.8-5.1 3.8-8.9 0-3.8-1.3-6.3-3.8-8.9-2.7-1.1-5.2-2.4-9-2.4zM259.6 762.5v1.3-1.3z"
                  fill="#FFFFFF"
                  p-id="2437"></path>
          </svg>
        </div>
        <div style="margin-left:30px;width:97%;height:30px;line-height:30px">
          <el-button type="primary"
                     size="mini"
                     icon="el-icon-edit"
                     plain
                     style="float:right"
                     @click="dialogVisible = true">为一台主机添加账号密码</el-button>
        </div>
      </div>
      <el-table :data="tableData"
                @expand-change="getDate"
                style="width: 100%">
        <el-table-column type="expand">
          <template slot-scope="props">
            <el-form label-position="left"
                     inline
                     ref="form"
                     :model="form"
                     class="demo-table-expand">
              <el-form-item label="cpu">
                <span>{{ form.name }}</span>
              </el-form-item>
              <el-form-item label="内存">
                <span>{{ props.row.shop }}</span>
              </el-form-item>
              <el-form-item label="磁盘">
                <span>{{ props.row.id }}</span>
              </el-form-item>
              <el-form-item label="主机名">
                <span>{{ props.row.shopId }}</span>
              </el-form-item>
              <el-form-item label="商品分类">
                <span>{{ props.row.category }}</span>
              </el-form-item>
              <el-form-item label="店铺地址">
                <span>{{ props.row.address }}</span>
              </el-form-item>
              <el-form-item label="商品描述">
                <span>{{ props.row.desc }}</span>
              </el-form-item>
            </el-form>
          </template>
        </el-table-column>
        <el-table-column label="ID"
                         width="80px"
                         prop="id">
        </el-table-column>
        <el-table-column label="创建时间"
                         prop="create_time">
        </el-table-column>
        <el-table-column label="更新时间"
                         prop="update_time">
        </el-table-column>
        <el-table-column label="ip地址"
                         prop="server">
        </el-table-column>
        <el-table-column label="端口"
                         prop="port">
        </el-table-column>
        <el-table-column label="用户名"
                         prop="server_name">
        </el-table-column>
        <el-table-column label="创建人"
                         prop="master">
        </el-table-column>
        <el-table-column label="备注"
                         prop="remark">
        </el-table-column>
        <el-table-column label="操作"
                         width="120">
          <template slot-scope="scope">
            <el-button @click.native.prevent="deleteRow(scope.$index, scope.row)"
                       type="text"
                       size="small">
              移除
            </el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>
    <el-dialog :visible.sync="dialogVisible"
               title="Dialog Titile">
      <el-form ref="elForm"
               :model="formData"
               :rules="rules"
               size="medium"
               label-width="200px">
        <el-form-item label="ip地址"
                      prop="server">
          <el-input v-model="formData.server"
                    placeholder="请输入ip地址"
                    clearable
                    :style="{width: '100%'}"></el-input>
        </el-form-item>
        <el-form-item label="端口号"
                      prop="port">
          <el-input v-model="formData.port"
                    placeholder="请输入端口号"
                    clearable
                    :style="{width: '100%'}"></el-input>
        </el-form-item>
        <el-form-item label="用户名"
                      prop="server_name">
          <el-input v-model="formData.server_name"
                    placeholder="请输入用户名"
                    clearable
                    :style="{width: '100%'}">
          </el-input>
        </el-form-item>
        <el-form-item label="密码"
                      prop="passwd">
          <el-input v-model="formData.passwd"
                    placeholder="请输入密码"
                    clearable
                    show-password
                    :style="{width: '100%'}"></el-input>
        </el-form-item>
        <el-form-item label="创建人"
                      prop="master">
          <el-input v-model="formData.master"
                    placeholder="请输入创建人"
                    clearable
                    :style="{width: '100%'}"></el-input>
        </el-form-item>
        <el-form-item label="备注"
                      prop="remark">
          <el-input v-model="formData.remark"
                    type="textarea"
                    placeholder="请输入备注"
                    :autosize="{minRows: 4, maxRows: 4}"
                    :style="{width: '100%'}"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer">
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary"
                   @click="addserver">确定</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import cons from "@/components/constant";

export default {
  inheritAttrs: false,
  components: {},
  props: [],
  data () {
    return {
      tableData: [],
      rules: {
        ip: [{
          required: true,
          message: '请输入ip地址',
          trigger: 'blur'
        }],
        port: [{
          required: true,
          message: '请输入端口号',
          trigger: 'blur'
        }],
        master: [{
          required: true,
          message: '请输入用户名',
          trigger: 'blur'
        }],
        remark: [{
          required: true,
          message: '请输入备注',
          trigger: 'blur'
        }],
        server_name: [{
          required: true,
          message: '请输入用户名',
          trigger: 'blur'
        }],
        passwd: [{
          required: true,
          message: '请输入密码',
          trigger: 'blur'
        }],
        owner: [],
        backend: [],
      },
      formData: {
      },
      form: {
        name: 'guoshao',
        region: '',
        date1: '',
        date2: '',
        delivery: false,
        type: [],
        resource: '',
        desc: ''

      },
      dialogVisible: false,
      forms: ["$form"],
      model: '',
    };
  },

  mounted () {
    // 获取主机
    this.getList();
  },

  methods: {
    deleteRow (index, rows) {
      console.log(rows)
      this.$http
        .get(
          cons.apis + "/del/server/" + rows.id,
          {
            responseType: "json",
          }
        )
        .then((res) => {
          if (res.status == 204)
          {
            // console.log(res.data.data);
            this.getList();
          }
          console.log(res)
        })
        .catch((err) => {
          console.log(err);
        });
    },
    getList () {
      this.$http
        .get(cons.apis + "/server/", {
          responseType: "json",
        })
        .then((res) => {
          if (res.status == 200)
          {
            console.log(res.data);
            this.tableData = res.data

          }
        })
        .catch((err) => {
          console.log(err);
        });
    },
    //获取主机详细信息
    getDate (row, event, column) {
      console.log(row)
    },
    //开始创建主机
    addserver () {
      this.dialogVisible = false
      const vm = this;
      console.log(this.model);
      this.$http
        .post(cons.apis + "/server/", vm.formData, {
          responseType: "json",
        })
        .then((res) => {
          if (res.status == 200)
          {
            // console.log(res.data.data);
            this.getList();
            this.$notify({
              title: "恭喜你",
              message: "创建主机成功啦",
              type: "success",
            });
          }

        })
        .catch((err) => {
          console.log(err);
          this.$notify({
            title: "失败啦",
            message: "你个鳖孙，创建主机失败啦",
            type: "error",
          });
        });
    },
  },
};
</script>

<style>
.demo-table-expand {
  font-size: 0;
}
.el-form-item__label {
  text-align: center;
}
.demo-table-expand label {
  width: 90px;
  color: #99a9bf;
}
.demo-table-expand .el-form-item {
  margin-right: 0;
  margin-bottom: 0;
  width: 50%;
}
</style>
