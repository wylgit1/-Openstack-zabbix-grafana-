<template>
  <div>
    <el-alert title="提示:您可以在添加,查看，删除主机群组"
              type="info"
              show-icon
              effect="dark"
              style="margin: 25px; padding: 12px;width:96%">
    </el-alert>
    <el-card style="margin: 25px; padding: 12px">
      <div slot="header">
        <div style="float:left">
          <svg t="1635681428366"
               class="icon"
               viewBox="0 0 1024 1024"
               version="1.1"
               xmlns="http://www.w3.org/2000/svg"
               p-id="2461"
               width="30"
               height="30">
            <path d="M848 73.6L775.04 64h-512l-72.96 9.6a32 32 0 0 0-28.16 32v202.88a32 32 0 0 0 28.16 32l76.8 9.6h512l72.96-9.6a32 32 0 0 0 28.16-32V105.6a32 32 0 0 0-32-32z m-35.84 206.72l-44.16 5.76H269.44l-44.8-5.76V133.76L264.96 128H768l42.88 5.76z"
                  fill="#1B213F"
                  p-id="2462"></path>
            <path d="M599.04 156.16a16 16 0 0 0-16 16v74.24a16 16 0 0 0 32 0V172.16a16 16 0 0 0-16-16zM704 156.16a16 16 0 0 0-16 16v74.24a16 16 0 0 0 32 0V172.16a16 16 0 0 0-16-16zM848 388.48l-72.96-9.6h-512l-72.96 9.6a32 32 0 0 0-28.16 32v202.88a32 32 0 0 0 28.16 32l76.8 9.6h512l72.96-9.6a32 32 0 0 0 28.16-32V420.48a32 32 0 0 0-32-32z m-35.84 206.72l-44.16 5.76H269.44L224 595.2V448l40.96-5.76H768l42.88 5.76z"
                  fill="#1B213F"
                  p-id="2463"></path>
            <path d="M599.04 471.04a16 16 0 0 0-16 16v74.24a16 16 0 0 0 32 0V487.04a16 16 0 0 0-16-16zM704 471.04a16 16 0 0 0-16 16v74.24a16 16 0 0 0 32 0V487.04a16 16 0 0 0-16-16zM848 704l-72.96-9.6h-512L188.16 704a32 32 0 0 0-28.16 32v203.52a32 32 0 0 0 28.16 32l76.8 9.6h512l72.96-9.6a32 32 0 0 0 28.16-32v-204.16a32 32 0 0 0-30.08-31.36z m-35.84 206.72l-40.96 5.76H269.44l-44.8-5.76v-147.2l40.96-5.76H768l42.88 5.76z"
                  fill="#1B213F"
                  p-id="2464"></path>
            <path d="M599.04 785.92a16 16 0 0 0-16 16v74.24a16 16 0 0 0 32 0v-74.24a16 16 0 0 0-16-16zM704 785.92a16 16 0 0 0-16 16v74.24a16 16 0 0 0 32 0v-74.24a16 16 0 0 0-16-16zM128 206.72a16 16 0 0 0 12.8-18.56 16 16 0 0 0-18.56-12.8l-48 9.6a16 16 0 0 0-12.8 16v272a16 16 0 0 0 12.8 16l48 9.6a16 16 0 0 0 0-32l-32.64-7.04V213.12zM970.88 184.32l-48-9.6a16 16 0 1 0-6.4 31.36l35.2 7.04v246.4l-35.2 7.04a16 16 0 0 0 0 32l48-9.6a16 16 0 0 0 12.8-16V200.32a16 16 0 0 0-6.4-16zM128 576a16 16 0 0 0 12.8-18.56 16 16 0 0 0-18.56-12.8l-48 9.6a16 16 0 0 0-12.8 16v272.64a16 16 0 0 0 12.8 16l48 9.6a16 16 0 0 0 0-32L89.6 832V584.32zM970.88 555.52l-48-9.6a16 16 0 1 0-6.4 31.36l35.2 7.04V832l-35.2 7.04a16 16 0 0 0 0 32l48-9.6a16 16 0 0 0 12.8-16V570.88a16 16 0 0 0-6.4-15.36z"
                  fill="#1B213F"
                  p-id="2465"></path>
          </svg>
        </div>
        <div style="margin-left:30px;width:97%;height:30px;line-height:30px">
          <el-button type="primary"
                     size="mini"
                     icon="el-icon-edit"
                     plain
                     style="float:right"
                     @click="dialogVisible=true">添加主机群组</el-button>
        </div>
      </div>

      <el-table :data="
          tableData.filter(
            (data) =>
              !search ||
              data.priority.toLowerCase().includes(search.toLowerCase()) ||
              data.groupid.toLowerCase().includes(search.toLowerCase()) ||
              data.expression.toLowerCase().includes(search.toLowerCase()) ||
              data.name.toLowerCase().includes(search.toLowerCase()) ||
              data.templateid.toLowerCase().includes(search.toLowerCase())
          )
        "
                style="width: 100%"
                stripe>
        <el-table-column type="index"
                         width="50">
        </el-table-column>
        <el-table-column label="主机群组id"
                         prop="groupid"
                         align="center">
        </el-table-column>
        <el-table-column label="主机群组名称"
                         prop="name"
                         align="center">
        </el-table-column>

        <el-table-column align="center"
                         width="150">
          <template slot="header"
                    slot-scope="scope">
            <el-input v-model="search"
                      size="mini"
                      placeholder="输入关键字搜索" />
          </template>
          <template slot-scope="scope">
            <el-button type="danger"
                       size="mini"
                       icon="el-icon-delete"
                       circle
                       @click="handleDel(scope.$index, scope.row)"></el-button>
          </template>
        </el-table-column>
      </el-table>
      <el-pagination :current-page="param.currentPage"
                     :page-sizes="[5, 10, 15, 20]"
                     :page-size="param.pagesize"
                     layout="total, sizes, prev, pager, next, jumper"
                     :total="total"
                     @size-change="handleSizeChange"
                     @current-change="handleCurrentChange" />
    </el-card>
    <el-dialog title="添加主机群组"
               :visible.sync="dialogVisible"
               width="50%">
      <el-form ref="$form"
               :model="model"
               label-position="left"
               label-width="100px"
               size="small">
        <el-form-item prop="hostgroup_name"
                      label="主机群组名称"
                      label-width="120px">
          <el-input v-model="model.hostgroup_name"
                    placeholder="请输入要创建的主机群组名称"
                    clearable></el-input>
        </el-form-item>
      </el-form>
      <span slot="footer"
            class="dialog-footer">
        <el-button @click="dialogVisible = false">取 消</el-button>
        <el-button type="primary"
                   @click="addhostgroup">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
import cons from "@/components/constant";

export default {
  data () {
    return {
      tableData: [],
      dialogVisible: false,
      search: "",
      value: '100',
      param: {
        currentPage: 1, // 当前页
        pagesize: 5, // 默认每页多少张
        hostid: ''
      },
      total: 0, // 共多少页
      join: null,
      forms: ["$form"],
      model: {
        hostgroup_name: "",
      },
      host_group_data: null,
      host_template_data: [
        {
          label: "选项1",
          value: "1",
          disabled: false,
        },
      ],
      submit_loading: false,
    };
  },

  mounted () {
    this.getList()
  },

  methods: {

    //获取基本数据
    getList: function (num) {
      const vm = this;
      this.$http
        .post(cons.apis + "/get/hostgroups/", vm.param, {
          responseType: "json",
        })
        .then((res) => {
          if (res.data.code == 200)
          {
            console.log(res.data.data);
            vm.total = res.data.total;
            vm.tableData = res.data.data;
          }
        })
        .catch((err) => {
          console.log(err);
        });
    },

    //删除指定内容
    handleDel (index, row) {
      console.log(row.hostgroupid);
      this.$http
        .get(
          cons.apis + "/del/hostgroup/?hostgroupid=" + row.groupid,
          {
            responseType: "json",
          }
        )
        .then((res) => {
          if (res.data.code == 200)
          {
            // console.log(res.data.data);
            this.getList();
            this.$notify({
              title: "恭喜你",
              message: "删除主机群组成功啦",
              type: "success",
            });

          }
          else
          {
            console.log(res);
            alert("Cannot delete")
          }
        })
        .catch((err) => {
          console.log(err);
        });
    },

    //以下两个是分页功能的实现
    handleSizeChange: function (size) {
      const a = this;
      a.param.pagesize = size;
      this.getList();
      console.log(a.param.pagesize); // 每页下拉显示数据
    },
    handleCurrentChange: function (currentPage) {
      const b = this;
      b.param.currentPage = currentPage;
      console.log(this.currentPage); // 点击第几页
      this.getList();
    },

    //添加主机群组
    addhostgroup () {
      this.dialogVisible = false;
      const vm = this;
      console.log(this.model);
      this.$http
        .post(cons.apis + "/add/hostgroups/", vm.model, {
          responseType: "json",
        })
        .then((res) => {
          if (res.data.code == 200)
          {
            // console.log(res.data.data);
            this.$notify({
              title: "恭喜你",
              message: "创建主机群组成功啦",
              type: "success",
            });
            this.$router.go(0);
          }
        })
        .catch((err) => {
          console.log(err);
          this.$notify({
            title: "失败啦",
            message: "你个鳖孙，创建主机群组失败啦",
            type: "error",
          });
        });
    },
  },
};
</script>