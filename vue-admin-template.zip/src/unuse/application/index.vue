<template>
  <div>
    <el-alert title="提示:您可以在添加,查看，删除应用集"
              type="info"
              show-icon
              effect="dark"
              style="margin: 25px; padding: 12px;width:96%">
    </el-alert>
    <el-card style="margin: 25px; padding: 12px">
      <div slot="header">
        <div style="float:left">
          <svg t="1635682489816"
               class="icon"
               viewBox="0 0 1024 1024"
               version="1.1"
               xmlns="http://www.w3.org/2000/svg"
               p-id="5025"
               width="30"
               height="30">
            <path d="M348.16 65.536H77.824c-19.456 0-34.816 6.144-48.128 19.456C16.384 98.304 10.24 113.664 10.24 132.096v270.336c0 18.432 6.144 34.816 19.456 48.128 13.312 13.312 28.672 20.48 48.128 20.48H348.16c18.432 0 34.816-7.168 48.128-20.48 13.312-13.312 20.48-29.696 20.48-48.128V132.096c0-18.432-7.168-34.816-20.48-48.128C382.976 71.68 366.592 65.536 348.16 65.536zM994.304 221.184L802.816 29.696C789.504 16.384 773.12 10.24 754.688 10.24c-18.432 0-34.816 7.168-48.128 20.48L515.072 222.208c-13.312 13.312-19.456 28.672-19.456 47.104 0 18.432 6.144 33.792 19.456 47.104L706.56 507.904c13.312 13.312 29.696 20.48 48.128 20.48 18.432 0 34.816-6.144 48.128-19.456L994.304 317.44c13.312-13.312 19.456-29.696 19.456-48.128 0-18.432-6.144-34.816-19.456-48.128zM348.16 607.232H77.824c-18.432 0-34.816 6.144-48.128 19.456C16.384 640 10.24 656.384 10.24 674.816v271.36c0 18.432 6.144 34.816 19.456 48.128C43.008 1007.616 58.368 1013.76 77.824 1013.76H348.16c18.432 0 34.816-6.144 48.128-19.456 13.312-13.312 20.48-28.672 20.48-48.128V674.816c0-18.432-7.168-34.816-20.48-48.128-13.312-12.288-29.696-19.456-48.128-19.456zM890.88 607.232H619.52c-18.432 0-34.816 6.144-48.128 19.456-13.312 13.312-20.48 28.672-20.48 48.128v271.36c0 18.432 7.168 34.816 20.48 48.128 13.312 13.312 29.696 19.456 48.128 19.456H890.88c18.432 0 34.816-6.144 48.128-19.456 13.312-13.312 19.456-28.672 19.456-48.128V674.816c0-18.432-6.144-34.816-19.456-48.128-14.336-12.288-29.696-19.456-48.128-19.456z"
                  fill="#007EE7"
                  p-id="5026"></path>
          </svg>
        </div>
        <div style="margin-left:30px;width:97%;height:30px;line-height:30px">
          <el-button type="primary"
                     size="mini"
                     icon="el-icon-edit"
                     plain
                     style="float:right"
                     @click="dialogVisible=true">添加应用集</el-button>
        </div>
      </div>
      <el-dialog title="添加应用集"
                 :visible.sync="dialogVisible"
                 width="50%">
        <el-form ref="$form"
                 :model="model"
                 label-position="left"
                 label-width="100px"
                 size="small">
          <el-form-item prop="application_name"
                        label="应用集名称"
                        label-width="120px">
            <el-input v-model="model.application_name"
                      placeholder="请输入要创建的应用集名称"
                      clearable></el-input>
          </el-form-item>
        </el-form>
        <span slot="footer"
              class="dialog-footer">
          <el-button @click="dialogVisible = false">取 消</el-button>
          <el-button type="primary"
                     @click="addapplication">确 定</el-button>
        </span>
      </el-dialog>
      <el-table :data="
          tableData.filter(
            (data) =>
              !search ||
              data.priority.toLowerCase().includes(search.toLowerCase()) ||
              data.applicationid.toLowerCase().includes(search.toLowerCase()) ||
              data.expression.toLowerCase().includes(search.toLowerCase()) ||
              data.description.toLowerCase().includes(search.toLowerCase()) ||
              data.templateid.toLowerCase().includes(search.toLowerCase())
          )
        "
                style="width: 100%"
                stripe>
        <el-table-column type="index"
                         width="50">
        </el-table-column>
        <el-table-column label="应用集id"
                         prop="applicationid"
                         align="center">
        </el-table-column>
        <el-table-column label="应用集名称"
                         prop="name"
                         align="center">
        </el-table-column>

        <el-table-column align="center"
                         width="150">
          <template slot="header"
                    slot-scope="scope">
            <el-input v-model="search"
                      size="mini"
                      placeholder="输入关键字搜索" />
          </template>
          <template slot-scope="scope">
            <el-button type="danger"
                       size="mini"
                       icon="el-icon-delete"
                       circle
                       @click="handleDel(scope.$index, scope.row)"></el-button>
          </template>
        </el-table-column>
      </el-table>
      <el-pagination :current-page="param.currentPage"
                     :page-sizes="[5, 10, 15, 20]"
                     :page-size="param.pagesize"
                     layout="total, sizes, prev, pager, next, jumper"
                     :total="total"
                     @size-change="handleSizeChange"
                     @current-change="handleCurrentChange" />
    </el-card>
  </div>
</template>

<script>
import cons from "@/components/constant";

export default {
  data () {
    return {
      tableData: [],
      search: "",
      dialogVisible: false,
      value: '100',
      param: {
        currentPage: 1, // 当前页
        pagesize: 5, // 默认每页多少张
        hostid: ''
      },
      total: 0, // 共多少页
      join: null,
      forms: ["$form"],
      model: {
        application_name: "",
        hostid: ''
      },
      host_group_data: null,
      host_template_data: [
        {
          label: "选项1",
          value: "1",
          disabled: false,
        },
      ],
      submit_loading: false,
    };
  },

  mounted () {
    this.getList()
  },

  methods: {

    //获取基本数据
    getList: function (num) {
      let token = localStorage.token;
      const vm = this;
      vm.param.hostid = sessionStorage.getItem('hostid')
      console.log(vm.param);
      this.$http
        .post(cons.apis + "/get/host_application_date/", vm.param, {
          responseType: "json",
        })
        .then((res) => {
          if (res.data.code == 200)
          {
            console.log(res.data.data);
            vm.total = res.data.total;
            vm.tableData = res.data.data;
          }
        })
        .catch((err) => {
          console.log(err);
        });
    },

    //删除指定内容
    handleDel (index, row) {
      console.log(row.applicationid);
      this.$http
        .get(
          cons.apis + "/del/application/?applicationid=" + row.applicationid,
          {
            responseType: "json",
          }
        )
        .then((res) => {
          if (res.data.code == 200)
          {
            // console.log(res.data.data);
            this.getList();
          }
          else
          {
            console.log(res);
            alert("Cannot delete templated application")
          }
        })
        .catch((err) => {
          console.log(err);
        });
    },

    //以下两个是分页功能的实现
    handleSizeChange: function (size) {
      const a = this;
      a.param.pagesize = size;
      this.getList();
      console.log(a.param.pagesize); // 每页下拉显示数据
    },
    handleCurrentChange: function (currentPage) {
      const b = this;
      b.param.currentPage = currentPage;
      console.log(this.currentPage); // 点击第几页
      this.getList();
    },
    //添加应用集
    addapplication () {
      this.dialogVisible = false;
      const vm = this;
      vm.model.hostid = sessionStorage.getItem('hostid')
      console.log(this.model);
      this.$http
        .post(cons.apis + "/add/application/", vm.model, {
          responseType: "json",
        })
        .then((res) => {
          if (res.data.code == 200)
          {
            // console.log(res.data.data);
            this.$notify({
              title: "恭喜你",
              message: "创建主机群组成功啦",
              type: "success",
            });
            this.$router.go(0);
          }
        })
        .catch((err) => {
          console.log(err);
          this.$notify({
            title: "失败啦",
            message: "你个鳖孙，创建主机群组失败啦",
            type: "error",
          });
        });
    },

  },
};
</script>