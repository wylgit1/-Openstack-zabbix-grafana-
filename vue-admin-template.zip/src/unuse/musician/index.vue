<template>

</template>

<script>
import cons from "@/components/constant";
export default {
  //  页面加载时像后端获取数据
  mounted() {
    // 获取主机
    this.getList();
  },
  methods: {
    getList() {
      this.$http
        .get(cons.apis + "/guoshao_test/", {
          responseType: "json",
        })
        .then((res) => {
          if (res.status == 200) {
            console.log(res.data);
            this.tableData = res.data;
          }
        })
        .catch((err) => {
          console.log(err);
        });
    },
  },
};
</script>

<style>
</style>