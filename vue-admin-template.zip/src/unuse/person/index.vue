<!-- 个人中心页面 -->
<template>
  <div>
    <el-card style="margin: 25px; padding: 12px">
      <el-tabs v-model="activeName" type="card" @tab-click="handleClick">
        <el-tab-pane label="个人中心" name="first" style="margin: 40px">
          <el-form
            ref="$form"
            :model="model"
            label-position="left"
            label-width="100px"
            size="small"
          >
            <el-form-item prop="avatar" label="更换头像">
              <el-input
                v-model="model.avatar"
                placeholder="请输入"
                clearable
                prefix-icon="el-icon-user-solid"
                style="width: 50%"
              ></el-input>
            </el-form-item>
            <el-form-item prop="username" label="修改用户名">
              <el-input
                v-model="model.username"
                placeholder="请输入"
                clearable
                prefix-icon="el-icon-user"
                style="width: 50%"
              ></el-input>
            </el-form-item>
            <el-form-item prop="password" label="修改密码">
              <el-input
                v-model="model.password"
                placeholder="请输入"
                clearable
                show-password
                prefix-icon="el-icon-s-order"
                style="width: 50%"
              ></el-input>
            </el-form-item>
            <el-form-item label="注册时间">
              <el-input
                v-model="model.join_time"
                readonly
                prefix-icon="el-icon-date"
                style="width: 50%"
              ></el-input>
            </el-form-item>
            <el-form-item label="手机号码">
              <el-input
                v-model="model.tel"
                readonly
                prefix-icon="el-icon-phone"
                style="width: 50%"
              ></el-input>
            </el-form-item>

            <el-row
              :gutter="20"
              type="flex"
              justify="start"
              align="top"
              tag="div"
            >
              <el-col :span="6" :offset="0" :push="0" :pull="0" tag="div">
                <el-button
                  size="small"
                  type="primary"
                  icon="el-icon-check"
                  @click="submit"
                  >提 交</el-button
                >
              </el-col>
              <el-col :span="6" :offset="0" :push="0" :pull="0" tag="div">
                <el-button
                  size="small"
                  icon="el-icon-refresh-left"
                  @click="forms.forEach((form) => $refs[form].resetFields())"
                  >重 置</el-button
                >
              </el-col>
            </el-row>
          </el-form>
        </el-tab-pane>

        <el-tab-pane label="我的脚本" name="second" style="margin: 40px">
          <template>
            <el-table
              :data="
                myScripts.filter(
                  (data) =>
                    !search ||
                    data.username
                      .toLowerCase()
                      .includes(search.toLowerCase()) ||
                    data.date_joined
                      .toLowerCase()
                      .includes(search.toLowerCase()) ||
                    data.mobile.toLowerCase().includes(search.toLowerCase())
                )
              "
              style="width: 100%"
              stripe
            >
              <el-table-column type="expand">
                <template slot-scope="props">
                  <el-form
                    label-position="left"
                    inline
                    class="demo-table-expand"
                    v-for="item in props.row.flow_script"
                    :key="item.index"
                  >
                    <el-form-item label="处理脚本id">
                      <span>{{ item.id }}</span>
                    </el-form-item>
                    <el-form-item label="处理脚本名称">
                      <span>{{ item.script_name }}</span>
                    </el-form-item>
                    <el-form-item label="处理脚本描述">
                      <span>{{ item.script_desc }}</span>
                    </el-form-item>
                    <el-form-item label="处理脚本大小">
                      <span>{{ item.script_size }}</span>
                    </el-form-item>
                    <el-form-item label="处理脚本上传时间">
                      <span>{{ item.create_time }}</span>
                    </el-form-item>
                    <el-form-item label="处理脚本修改时间">
                      <span>{{ item.update_time }}</span>
                    </el-form-item>
                    <el-divider></el-divider>
                  </el-form>
                </template>
              </el-table-column>
              <el-table-column
                label="流程脚本ID"
                prop="id"
                width="100px"
                align="center"
              >
              </el-table-column>
              <el-table-column
                label="故障标识符"
                prop="fault_name"
                width="250px"
                align="center"
              >
              </el-table-column>
              <el-table-column
                label="故障描述"
                prop="fault_desc"
                width="250px"
                align="center"
              >
              </el-table-column>
              <el-table-column
                label="流程脚本大小"
                prop="file_size"
                width="150px"
              >
              </el-table-column>
              <el-table-column
                label="流程脚本名称"
                prop="file_path"
                align="center"
              >
              </el-table-column>
              <el-table-column align="center" width="150" label="是否共享">
                <template slot-scope="scope_s">
                  <el-switch
                    v-model="scope_s.row.is_show"
                    active-text="是"
                    inactive-text="否"
                    @change="edit_share_status(scope_s.row)"
                  >
                  </el-switch>
                </template>
              </el-table-column>
            </el-table> </template
        ></el-tab-pane>

        <el-tab-pane
          label="用户概览"
          name="third"
          style="margin: 40px"
          v-if="visable"
        >
          <div class="chart-container">
            <el-row>
              <el-col :span="12">
                <div id="chartLine" style="width: 500px; height: 400px"></div>
              </el-col>
            </el-row>
          </div>
        </el-tab-pane>

        <el-tab-pane
          label="用户详情"
          name="forth"
          style="margin: 40px 40px 0px 40px"
          v-if="visable"
        >
          <template>
            <el-table
              :data="
                tableData.filter(
                  (data) =>
                    !search ||
                    data.username
                      .toLowerCase()
                      .includes(search.toLowerCase()) ||
                    data.date_joined
                      .toLowerCase()
                      .includes(search.toLowerCase()) ||
                    data.mobile.toLowerCase().includes(search.toLowerCase())
                )
              "
              style="width: 100%"
              stripe
            >
              <el-table-column type="index" width="50"> </el-table-column>
              <el-table-column
                label="用户名称"
                prop="username"
                width="110"
                align="center"
              >
              </el-table-column>
              <el-table-column
                label="注册时间"
                prop="date_joined"
                width="200"
                align="center"
              >
              </el-table-column>
              <el-table-column
                label="手机号"
                prop="mobile"
                width="200"
                align="center"
              >
              </el-table-column>
              <el-table-column label="用户头像" prop="avatar" align="center">
                <template slot-scope="scope_a">
                  <el-avatar :size="40" :src="scope_a.row.avatar"></el-avatar>
                </template>
              </el-table-column>
              <el-table-column label="超级管理员" width="300" align="center">
                <template slot-scope="scope">
                  <el-switch
                    v-model="scope.row.is_superuser"
                    active-text="是"
                    inactive-text="否"
                    :disabled="status"
                    @change="editUser(scope.row)"
                  >
                  </el-switch>
                </template>
              </el-table-column>
              <el-table-column align="center" width="150">
                <template slot="header" slot-scope="scope">
                  <el-input
                    v-model="search"
                    size="mini"
                    placeholder="输入关键字搜索"
                  />
                </template>
                <template slot-scope="scope">
                  <el-button
                    type="primary"
                    icon="el-icon-edit"
                    @click="handleEdit(scope.$index, scope.row)"
                    circle
                    size="mini"
                  ></el-button>
                  <el-button
                    type="danger"
                    icon="el-icon-delete"
                    @click="handleDel(scope.$index, scope.row)"
                    circle
                    size="mini"
                  ></el-button>
                </template>
              </el-table-column>
            </el-table> </template></el-tab-pane
      ></el-tabs>
    </el-card>
  </div>
</template>


<script>
import cons from "@/components/constant";
import store from "@/store";
import echarts from "echarts";
export default {
  data() {
    return {
      activeName: "first",
      forms: ["$form"],
      model: {
        avatar: "",
        username: "",
        password: "",
        join_time: "",
        tel: "",
      },
      value1: true,
      tableData: [],
      myScripts: [],
      search: "",
      join: null,
      status: true,
      visable: false,
      chartLine: null,
    };
  },
  mounted() {
    // 获取用户个人信息
    var data = JSON.parse(window.sessionStorage.getItem("data"));
    console.log(data);
    this.model.username = data.username;
    this.model.tel = data.mobile;
    this.model.join_time = data.date_joined;
    this.model.avatar = data.avatar;
    if (data.is_superuser === true) {
      this.visable = true;
    }
  },
  methods: {
    handleClick(tab) {
      // console.log(tab);
      console.log(tab.name);
      if (tab.name === "forth") {
        console.log(4);
        this.getList();
      } else if (tab.name === "second") {
        var data = JSON.parse(window.sessionStorage.getItem("data"));
        console.log(data.user_id);
        this.myScripts = data.user_id;
      } else if (tab.name === "third") {
        this.drawLineChart();
      }
    },

    submit() {
      Promise.all(this.forms.map((form) => this.$refs[form].validate())).then(
        () => {
          this.submit_loading = true;
          // TODO demo
          console.log(this.model);
          setTimeout(() => {
            this.submit_loading = false;
          }, 3000);
        }
      );
      var data = JSON.parse(window.sessionStorage.getItem("data"));
      var id = data.id;
      let vm = this;
      this.$http
        .put(cons.apis + "/users/" + id + "/", vm.model, {
          responseType: "json",
        })
        .then((res) => {
          // console.log(res);
          if (res.status == 200) {
            this.getList();
            this.status = true;
            this.$notify({
              title: "恭喜你",
              message: "个人信息修改成功",
              type: "success",
            });
          }
        })
        .catch((err) => err);
    },
    handleEdit(index, row) {
      // console.log(index, row);
      // 获取到triggerid
      console.log(row);
      this.status = false;
    },
    // 删除用户
    handleDel(index, row) {
      const vm = this;
      this.$http
        .delete(cons.apis + "/users/" + row.id + "/", {
          responseType: "json",
        })
        .then((res) => {
          // console.log(res);
          if (res.status == 204) {
            this.getList();
            this.status = true;
            this.$notify({
              title: "恭喜你",
              message: "删除用户成功",
              type: "success",
            });
          }
        })
        .catch((err) => {
          console.log(err);
        });
    },
    // 修改用户
    editUser(data) {
      const vm = this;
      this.$http
        .put(
          cons.apis + "/users/" + data.id + "/",
          {
            username: data.username,
            is_superuser: data.is_superuser,
          },
          {
            responseType: "json",
          }
        )
        .then((res) => {
          if (res.status == 200) {
            // console.log(res.data);
            this.status = true;
            this.$notify({
              title: "恭喜你",
              message: "修改用户权限成功",
              type: "success",
            });
          }
        })
        .catch((err) => {
          console.log(err);
        });
    },
    getList: function () {
      let token = localStorage.token;
      const vm = this;
      this.$http
        .get(cons.apis + "/users/", {
          headers: {
            Authorization: "JWT " + token,
          },
          responseType: "json",
        })
        .then((res) => {
          if (res.status == 200) {
            console.log(res.data);
            // vm.total = res.data.total;
            vm.tableData = res.data;
          }
        })
        .catch((err) => {
          console.log(err);
        });
    },

    // 修改脚本共享状态
    edit_share_status(row) {
      console.log(row.is_show);
      this.$http
        .put(cons.apis + "/intelligent/" + row.id + "/", row, {
          responseType: "json",
        })
        .then((res) => {
          console.log(res);
          if (res.status == 200) {
            this.status = !this.status;
            this.$notify({
              title: "恭喜你",
              message: "修改用户权限成功",
              type: "success",
            });
          }
        })
        .catch((err) => {
          console.log(err);
        });
    },

    // 绘制图表
    drawLineChart() {
      this.chartLine = echarts.init(document.getElementById("chartLine"));
      this.chartLine.setOption({
        title: {
          text: "Line Chart",
        },
        tooltip: {
          trigger: "axis",
        },
        legend: {
          data: ["邮件营销", "联盟广告", "搜索引擎"],
        },
        grid: {
          left: "3%",
          right: "4%",
          bottom: "3%",
          containLabel: true,
        },
        xAxis: {
          type: "category",
          boundaryGap: false,
          data: ["周一", "周二", "周三", "周四", "周五", "周六", "周日"],
        },
        yAxis: {
          type: "value",
        },
        series: [
          {
            name: "邮件营销",
            type: "line",
            stack: "总量",
            data: [120, 132, 101, 134, 90, 230, 210],
          },
          {
            name: "联盟广告",
            type: "line",
            stack: "总量",
            data: [220, 182, 191, 234, 290, 330, 310],
          },
          {
            name: "搜索引擎",
            type: "line",
            stack: "总量",
            data: [820, 932, 901, 934, 1290, 1330, 1320],
          },
        ],
      });
    },
  },
};
</script>

<style>
.demo-table-expand {
  font-size: 0;
}
.demo-table-expand label {
  width: 140px;
  color: #99a9bf;
}
.demo-table-expand .el-form-item {
  margin-right: 0;
  margin-bottom: 0;
  width: 50%;
}
</style>