<template>
  <div>
    <el-alert title="提示:您可以在添加,查看，删除主机模板"
              type="info"
              show-icon
              effect="dark"
              style="margin: 25px; padding: 12px;width:96%">
    </el-alert>
    <el-card style="margin: 25px; padding: 12px">
      <div slot="header">
        <div style="float:left">
          <svg t="1635681752110"
               class="icon"
               viewBox="0 0 1024 1024"
               version="1.1"
               xmlns="http://www.w3.org/2000/svg"
               p-id="3307"
               width="30"
               height="30">
            <path d="M622.2 64H64v832h511.8v-64H128V128h416v227h224v36l-0.1 184.4h64L832 391v-86.8L622.2 64zM608 145l127.5 146H608V145z"
                  fill="#727272"
                  p-id="3308"></path>
            <path d="M384 384.8h320v64H384zM384 639.9h319.9v64H384zM384 511.9h319.9v64H384z"
                  fill="#B2B2B2"
                  p-id="3309"></path>
            <path d="M832 960h-64V832H640v-64h128V640h64v128h128v64H832z"
                  fill="#669E8B"
                  p-id="3310"></path>
            <path d="M192 191.6h253v128H192zM192 389h128v379H192z"
                  fill="#5280C1"
                  p-id="3311"></path>
          </svg>
        </div>
        <div style="margin-left:30px;width:97%;height:30px;line-height:30px">
          <el-button type="primary"
                     size="mini"
                     icon="el-icon-edit"
                     plain
                     style="float:right"
                     @click="getDate()">添加主机模板</el-button>
        </div>
      </div>
      <el-table :data="
          tableData.filter(
            (data) =>
              !search ||
              data.priority.toLowerCase().includes(search.toLowerCase()) ||
              data.groupid.toLowerCase().includes(search.toLowerCase()) ||
              data.expression.toLowerCase().includes(search.toLowerCase()) ||
              data.name.toLowerCase().includes(search.toLowerCase()) ||
              data.模板.toLowerCase().includes(search.toLowerCase())
          )
        "
                style="width: 100%"
                stripe>
        <el-table-column type="index"
                         width="50">
        </el-table-column>
        <el-table-column label="主机模板id"
                         prop="templateid"
                         align="center">
        </el-table-column>
        <el-table-column label="主机模板名称"
                         prop="name"
                         align="center">
        </el-table-column>

        <el-table-column align="center"
                         width="150">
          <template slot="header"
                    slot-scope="scope">
            <el-input v-model="search"
                      size="mini"
                      placeholder="输入关键字搜索" />
          </template>
          <template slot-scope="scope">
            <el-button type="danger"
                       size="mini"
                       icon="el-icon-delete"
                       circle
                       @click="handleDel(scope.$index, scope.row)"></el-button>
          </template>
        </el-table-column>
      </el-table>
      <el-pagination :current-page="param.currentPage"
                     :page-sizes="[5, 10, 15, 20]"
                     :page-size="param.pagesize"
                     layout="total, sizes, prev, pager, next, jumper"
                     :total="total"
                     @size-change="handleSizeChange"
                     @current-change="handleCurrentChange" />
    </el-card>
    <el-dialog title="添加一台新的模板"
               :visible.sync="dialogVisible"
               width="50%">

      <el-input v-model="params.host_template_name"
                placeholder="请输入模板名"
                clearable
                style="width:200px"></el-input>
      <el-select v-model="params.value"
                 clearable
                 placeholder="请选择主机群组">
        <el-option v-for="item in host_group_data"
                   :key="item.groupid"
                   :label="item.name"
                   :value="item.groupid">
        </el-option>
      </el-select>
      <span slot="footer"
            class="dialog-footer">
        <el-button @click="dialogVisible = false">取 消</el-button>
        <el-button type="primary"
                   @click="addtemplate">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
import cons from "@/components/constant";

export default {
  data () {
    return {
      tableData: [],
      dialogVisible: false,
      search: "",
      value: '',
      param: {
        currentPage: 1, // 当前页
        pagesize: 5, // 默认每页多少张
        hostid: ''
      },
      total: 0, // 共多少页
      join: null,
      host_group_data: null,
      params: {
        host_template_name: null,
        value: '',
      },

      submit_loading: false,
    };
  },

  mounted () {
    this.getList();
  },

  methods: {

    //获取基本数据
    getList: function (num) {
      const vm = this;
      this.$http
        .post(cons.apis + "/get/templates/", vm.param, {
          responseType: "json",
        })
        .then((res) => {
          if (res.data.code == 200)
          {
            console.log(res.data.data);
            vm.total = res.data.total;
            vm.tableData = res.data.data;
          }
        })
        .catch((err) => {
          console.log(err);
        });
    },

    //删除指定内容
    handleDel (index, row) {
      console.log(row.hostgroupid);
      this.$http
        .get(
          cons.apis + "/del/template/?templateid=" + row.templateid,
          {
            responseType: "json",
          }
        )
        .then((res) => {
          if (res.data.code == 200)
          {
            // console.log(res.data.data);
            this.getList();
            this.$notify({
              title: "恭喜你",
              message: "删除主机群组成功啦",
              type: "success",
            });

          }
          else
          {
            console.log(res);
            alert("Cannot delete")
          }
        })
        .catch((err) => {
          console.log(err);
        });
    },

    //以下两个是分页功能的实现
    handleSizeChange: function (size) {
      const a = this;
      a.param.pagesize = size;
      this.getList();
      console.log(a.param.pagesize); // 每页下拉显示数据
    },
    handleCurrentChange: function (currentPage) {
      const b = this;
      b.param.currentPage = currentPage;
      console.log(this.currentPage); // 点击第几页
      this.getList();
    },

    //添加主机群组
    addtemplate () {
      this.dialogVisible = false;
      const vm = this;
      console.log(this.model);
      this.$http
        .post(cons.apis + "/add/template/", vm.params, {
          responseType: "json",
        })
        .then((res) => {
          if (res.data.code == 200)
          {
            // console.log(res.data.data);
            this.$notify({
              title: "恭喜你",
              message: "创建主机模板成功啦",
              type: "success",
            });
            this.$router.go(0);
          }
        })
        .catch((err) => {
          console.log(err);
          this.$notify({
            title: "失败啦",
            message: "你个鳖孙，创建主机模板失败啦",
            type: "error",
          });
        });
    },
    //添加前获取数据
    getDate () {
      this.dialogVisible = true;
      this.$http
        .get(cons.apis + "/get/template_data/", {
          responseType: "json",
        })
        .then((res) => {
          if (res.data.code == 200)
          {
            // console.log(res.data.data);
            this.host_group_data = res.data.data[0];
            // console.log(this.host_group_data)
          }
        })
        .catch((err) => {
          console.log(err);
          vm.$message.error("又出错了");
        });
    },
  },
};
</script>