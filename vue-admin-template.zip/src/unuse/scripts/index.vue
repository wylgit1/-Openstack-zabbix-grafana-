<template>
  <div>
    <el-card style="margin: 25px; padding: 12px">
      <el-table :data="tableData" style="width: 100%" stripe>
        <el-table-column type="expand">
          <template slot-scope="props">
            <el-form
              label-position="left"
              inline
              class="demo-table-expand"
              v-for="item in props.row.flow_script"
              :key="item.index"
            >
              <el-form-item label="处理脚本id">
                <span>{{ item.id }}</span>
              </el-form-item>
              <el-form-item label="处理脚本名称">
                <span>{{ item.script_name }}</span>
              </el-form-item>
              <el-form-item label="处理脚本描述">
                <span>{{ item.script_desc }}</span>
              </el-form-item>
              <el-form-item label="处理脚本大小">
                <span>{{ item.script_size }}</span>
              </el-form-item>
              <el-form-item label="处理脚本上传时间">
                <span>{{ item.create_time }}</span>
              </el-form-item>
              <el-form-item label="处理脚本修改时间">
                <span>{{ item.update_time }}</span>
              </el-form-item>
              <el-divider></el-divider>
            </el-form>
          </template>
        </el-table-column>
        <el-table-column
          label="流程脚本ID"
          prop="id"
          width="100px"
          align="center"
        >
        </el-table-column>
        <el-table-column
          label="故障标识符"
          prop="fault_name"
          width="250px"
          align="center"
        >
        </el-table-column>
        <el-table-column
          label="故障描述"
          prop="fault_desc"
          width="250px"
          align="center"
        >
        </el-table-column>
        <el-table-column
          label="流程脚本大小"
          prop="file_size"
          width="150px"
          align="center"
        >
        </el-table-column>
        <el-table-column label="流程脚本名称" prop="file_path" align="center">
        </el-table-column>
        <el-table-column width="100px" prop="id" align="right">
          <template slot-scope="flow_id">
            <el-button
              type="danger"
              icon="el-icon-delete"
              circle
              size="small"
              :disabled="premission"
              @click="delete_flow_script(flow_id.row.id)"
            ></el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>
  </div>
</template>

<style>
.demo-table-expand {
  font-size: 0;
}
.demo-table-expand label {
  width: 140px;
  color: #99a9bf;
}
.demo-table-expand .el-form-item {
  margin-right: 0;
  margin-bottom: 0;
  width: 50%;
}
</style>

<script>
import cons from "@/components/constant";
export default {
  data() {
    return {
      tableData: null,
      premission: true,
    };
  },
  mounted() {
    this.fetchData();
    var data = JSON.parse(window.sessionStorage.getItem("data"));
    if (data.is_superuser === true) {
      this.premission = false;
    }
  },
  methods: {
    fetchData() {
      let vm = this;
      this.$http
        .get(cons.apis + "/intelligent/", {
          responseType: "json",
        })
        .then((res) => {
          console.log(res.data);
          vm.tableData = res.data;
        })
        .catch((err) => {
          console.log(err);
        });
    },
    delete_flow_script(id) {
      let vm = this;
      this.$http
        .delete(cons.apis + "/intelligent/" + id + "/", {
          responseType: "json",
        })
        .then((res) => {
          console.log(res.data);
          // vm.tableData = res.data;
          vm.fetchData();
        })
        .catch((err) => {
          console.log(err);
        });
    },
  },
};
</script>
