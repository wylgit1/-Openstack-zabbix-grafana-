<template>
  <div>
    <el-card style="margin: 25px; padding: 12px">
      <iframe src="http://192.168.1.168:8000/add_triggers/"
              frameborder="0"
              scrolling="auto"
              id="show-iframe"></iframe>

    </el-card>
  </div>

</template>
 
<script>
export default {
  mounted () {
    /**
      * iframe-宽高自适应显示
      */
    const oIframe = document.getElementById('show-iframe');
    const deviceWidth = document.documentElement.clientWidth;
    const deviceHeight = document.documentElement.clientHeight;
    oIframe.style.width = deviceWidth + 'px';
    oIframe.style.height = deviceHeight + 'px';
  }

}

</script>
 
<style scoped>
</style>