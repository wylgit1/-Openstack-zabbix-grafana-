import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

/* Layout */
import Layout from '@/layout'

/**
 * Note: sub-menu only appear when route children.length >= 1
 * Detail see: https://panjiachen.github.io/vue-element-admin-site/guide/essentials/router-and-nav.html
 *
 * hidden: true                   if set true, item will not show in the sidebar(default is false)
 * alwaysShow: true               if set true, will always show the root menu
 *                                if not set alwaysShow, when item has more than one children route,
 *                                it will becomes nested mode, otherwise not show the root menu
 * redirect: noRedirect           if set noRedirect will no redirect in the breadcrumb
 * name:'router-name'             the name is used by <keep-alive> (must set!!!)
 * meta : {
    roles: ['admin','editor']    control the page roles (you can set multiple roles)
    title: 'title'               the name show in sidebar and breadcrumb (recommend set)
    icon: 'svg-name'/'el-icon-x' the icon show in the sidebar
    breadcrumb: false            if set false, the item will hidden in breadcrumb(default is true)
    activeMenu: '/example/list'  if set path, the sidebar will highlight the path you set
  }
 */

/**
 * constantRoutes
 * a base page that does not have permission requirements
 * all roles can be accessed
 */
export const constantRoutes = [{
        path: '/login',
        component: () =>
            import ('@/views/login/index'),
        hidden: true
    },
    {
        path: '/register',
        component: () =>
            import ('@/views/register/index'),
        hidden: true
    },
    // {
    //     path: '/share',
    //     component: () =>
    //         import ('@/views/share/index'),
    //     hidden: true
    // },
    {
        path: '/404',
        component: () =>
            import ('@/views/404'),
        hidden: true
    },
   
    // {
    //     path: '/',
    //     component: Layout,
    //     redirect: '/dashboard',
    //     children: [{
    //         path: 'dashboard',
    //         name: 'Dashboard',
    //         component: () =>
    //             import ('@/views/dashboard/index'),
    //         meta: { title: 'ccc管理系统', icon: 'dashboard' }
    //     }]
    // },
    {
        path: '/',
        component: Layout,
        redirect: '/hello',
        children: [{
            path: 'hello',
            name: 'hello',
            component: () =>
                import ('@/views/hello/index'),
            meta: { 
                title: 'ccc管理系统', icon: 'dashboard' }
        }]
    },
    {   
    path: '/basic',
    component: Layout,
    // redirect: '/log/system',
    name: 'basic',
    meta: {
        title: '基本管理',
        icon: 'nested'
    },
        children: [{
        // path 中有/ 则它的路径直接为/userManagement
        path: '/userManagement',
        component: () =>
            import ('@/views/userManagement/index'),
        name:'person',
        meta: { title: '用户管理', icon: 'el-icon-user' }
        
    },
    {
        path: '/allot2',
        name: 'allot2',
        component: () =>
            import ('@/views/allot2/index'),
        meta: { title: '分配主机', icon: 'el-icon-set-up' }
    },
    {
        path: '/stateManagement',
        name: 'stateManagement',
        component: () =>
            import ('@/views/stateManagement/index'),
        meta: { title: '状态管理', icon: 'el-icon-eleme' }
    },
    {
        path: '/vmManagement',
        name: 'vmManagement',
        component: () =>
            import ('@/views/vmManagement/index'),
        meta: { title: '主机管理', icon: 'el-icon-monitor' }
    },
    {
        path: '/snapshotManagement',
        name: 'snapshotManagement',
        component: () =>
            import ('@/views/snapshotManagement/index'),
        meta: { title: '快照管理', icon: 'el-icon-video-camera' }
    },
    {
        path: '/securityGroupManagement',
        name: 'securityGroupManagement',
        component: () =>
            import ('@/views/securityGroupManagement/index'),
        meta: { title: '安全组管理', icon: 'el-icon-lollipop' }
    },
    {
        path: '/volumeManagement',
        name: 'volumeManagement',
        component: () =>
            import ('@/views/volumeManagement/index'),
        meta: { title: '云盘管理', icon: 'el-icon-potato-strips' }
    },
]
},

    
    // {
    //     path: '/hosts',
    //     component: Layout,
    //     children: [{
    //         path: 'index',
    //         name: 'hosts',
    //         component: () =>
    //             import ('@/views/hosts/index'),
    //         meta: { title: 'hosts管理', icon: 'el-icon-potato-strips' }
    //     }]
    // },
    // {
    //     path: '/template',
    //     component: Layout,
    //     children: [{
    //         path: 'index',
    //         name: 'template',
    //         component: () =>
    //             import ('@/views/template/index'),
    //         meta: { title: '模板管理', icon: 'el-icon-potato-strips' }
    //     }]
    // },
    
{
    path: '/monitor',
    component: Layout,
    redirect: '/monitor/overview',
    name: 'monitor',
    meta: {
        title: '监控中心',
        icon: 'nested'
    },

    children: [{
        path: 'hosts',
        component: () =>
            import('@/views/hosts/index'), // Parent router-view
        name: 'hosts',
        meta: { title: '主机管理', icon: 'form' },
    },{
        path: 'asset',
        component: () =>
            import('@/views/asset/index'), // Parent router-view
        name: 'hosts',
        meta: { title: '资产管理', icon: 'nested' },
    },
    {
        path: 'template2',
        component: () =>
            import('@/views/template2/index'), // Parent router-view
        name: 'template2',
        meta: { title: '主机模板', icon: 'form' },
    },{
        path: 'group',
        component: () =>
            import('@/views/group/index'), // Parent router-view
        name: 'group',
        meta: { title: '主机群组', icon: 'form' },
    },{
        path: 'application',
        hidden: true,
        component: () =>
            import('@/views/application/index'), // Parent router-view
        name: 'application',
        meta: { title: '应用集', icon: 'form' }
    },
    {
        path: 'item',
        hidden: true,
        component: () =>
            import('@/views/item/index'), // Parent router-view
        name: 'item',
        meta: { title: '监控项', icon: 'form' }
    },
    {
        path: 'trigger',
        hidden: true,
        component: () =>
            import('@/views/trigger/index'), // Parent router-view
        name: 'trigger',
        meta: { title: '触发器', icon: 'form' }
    },
    {
        path: 'child',
        hidden: true,
        component: () =>
            import('@/views/child/index'), // Parent router-view
        name: 'child',
        meta: { title: '添加触发器', icon: 'form' }
    },
    {
        path: 'action',
        component: () =>
            import('@/views/action/index'), // Parent router-view
        name: 'action',
        meta: { title: '解决方案', icon: 'form' }
    },
    {
        path: 'add_action',
        hidden: true,
        component: () =>
            import('@/views/action/index3'), // Parent router-view
        name: 'add_action',
        meta: { title: '添加解决方案', icon: 'form' }
    },
    {
        path: 'lead_action',
        hidden: true,
        component: () =>
            import('@/views/action/index3'), // Parent router-view
        name: 'lead_action',
        meta: { title: '导入解决方案', icon: 'form' }
    },
    // {
    //     path: 'operation',
    //     component: () =>
    //         import('@/views/operation/index'), // Parent router-view
    //     name: 'scripts',
    //     meta: { title: '动作操作', icon: 'form' }
    // },
    ]
},

{
    path: '/auto',
    component: Layout,
    redirect: '/auto/autofind',
    name: 'auto',
    meta: {
        title: '自动化',
        icon: 'nested'
    },

    children: [{
        // path 中没有/ 则它的路径为/auto/autofind
        path: 'autofind',
        component: () =>
            import('@/views/auto/index'), // Parent router-view
        name: 'autofind',
        meta: { title: '添加自动发现规则', icon: 'nested' }
    },
    {
        path: 'install-zabbix-agent',
        hidden: true,
        component: () =>
            import('@/views/auto/index2'), // Parent router-view
        name: 'install-zabbix-agent',
        meta: { title: 'zabbix-agent', icon: 'form' }
    },
    //  {
    //     path: 'script',
    //     component: () =>
    //         import('@/views/script/index'), // Parent router-view
    //     name: 'script',
    //     meta: { title: '批量执行脚本', icon: 'nested' }
    // },
    {
        path: 'playbook',
        component: () =>
            import('@/views/playbook/index'), // Parent router-view
        name: 'scripts',
        meta: { title: '剧本管理', icon: 'form' }
    },

    ]
},
{
    path: '/log',
    component: Layout,
    redirect: '/log/system',
    name: 'log',
    meta: {
        title: '日志管理',
        icon: 'nested'
    },

    children: [{
        path: 'system',
        component: () =>
            import('@/views/log/index'), // Parent router-view
        name: 'system',
        meta: { title: '系统运行日志', icon: 'nested' }
    },
    {
        path: 'taskdetail',
        component: () =>
            import('@/views/taskdetail/task_detail'), // Parent router-view
        name: 'scripts',
        meta: { title: '剧本日志', icon: 'form' }
    },

    ]
},


   
 
    // {
    //     path: '/trigger',
    //     component: Layout,
    //     children: [{
    //         path: 'index',
    //         name: 'trigger',
    //         component: () =>
    //             import ('@/views/trigger/index'),
    //         meta: { title: '磁盘管理', icon: 'nested' }
    //     }]
    // },

    // 404 page must be placed at the end !!!
    // { path: '*', redirect: '/404', hidden: true }
]
export const asyncRoutes = [
    {
        path: '/create',
        component: Layout,
        children: [{
            path: 'index',
            name: 'create',
            component: () =>
                import ('@/views/create/index'),
            meta: { 
                title: '创建主机', 
                icon: 'el-icon-edit-outline',
                roles:['0']
             }
        }]
    },
    { path: '*', redirect: '/404', hidden: true }


]
const createRouter = () => new Router({
    // mode: 'history', // require service support
    scrollBehavior: () => ({ y: 0 }),
    routes: constantRoutes
})

const router = createRouter()

// Detail see: https://github.com/vuejs/vue-router/issues/1234#issuecomment-357941465
export function resetRouter() {
    const newRouter = createRouter()
    router.matcher = newRouter.matcher // reset router
}

export default router