<template>
   <el-card style="margin: 25px; padding: 12px">
      <div class="welcome">
      <span>Welcome to ccc!</span>
      </div>
      <div class="img">
      <el-image
      style="width: 400px; height: 400px;text-align:center;"
      :src="imgUrl"
      ></el-image>
      </div>
   </el-card>

</template>
<script>

export default {
   data(){
        return {
            imgUrl:require("@/assets/images/合作.png")
        }
    }
}
</script>

<style>
.welcome{
    bottom:10px;
    width:100%;
    right:390px;
    font-family:"Time New Roman";
    font-weight: 800;
    font-size: 50px;
    text-align:center;
    padding:10px;
    background-color:#fff;
}
.img{
   width:100%;
   text-align:center;
}
</style>