<template>
  <div class="register-container">
    <article class="header">
      <header>
        <el-avatar icon="el-icon-user-solid" shape="circle" />
        <span class="login">
          <em class="bold">已有账号？</em>
          <a href="/login">
            <el-button type="primary" size="mini">登录</el-button>
          </a>
        </span>
      </header>
    </article>
    <section>
      <el-form
        ref="registerForm"
        :model="registerForm"
        :rules="rules"
        label-width="100px"
        autocomplete="off"
        :hide-required-asterisk="true"
        size="medium"
      >
        <div style="padding-top: 10px">
          <el-form-item label="用户名" prop="username">
            <el-col :span="10">
              <el-input
                v-model="registerForm.username"
                placeholder="输入用户名"
              />
            </el-col>
          </el-form-item>
          <el-form-item label="密码" prop="password">
            <el-col :span="10">
              <el-input v-model="registerForm.password" type="password" />
            </el-col>
          </el-form-item>
          <el-form-item label="确认密码" prop="cpwd">
            <el-col :span="10">
              <el-input v-model="registerForm.cpwd" type="password" />
            </el-col>
          </el-form-item>
          <el-form-item label="请选择身份" prop="type">
           <el-select v-model="registerForm.type"  placeholder="请选择">          
    <el-option
      v-for="item in userstype"
      :key="item.label"
      :label="item.label"
      :value="item.value">
    </el-option>
  </el-select>
          </el-form-item>
          <el-form-item label="邮箱" prop="email">
            <el-col :span="10">
              <el-input
                v-model="registerForm.email"
                placeholder="输入邮箱"
              />
            </el-col>
            <span class="status">{{ statusMsg }}</span>
          </el-form-item>
          <el-form-item>
            <el-button
              type="primary"
              style="width: 40%"
              @click.native="userRegister()"
            >注册</el-button>
          </el-form-item>
        </div>
      </el-form>
    </section>

    <div class="error">{{ error }}</div>
  </div>
</template>

<script>
import { register } from '@/api/user';
import encryption from '@/utils/crypto';
export default {
  name: 'Register',
  data() {
    return {
      registerForm: {
        username:'',
        email: '',
        password: '',
        is_superuser:'',
        is_active:1,
        type:'',
        cpwd: '',
      },
      userstype:[{
          value: 0,
          label: '管理员'
      },{
          value: 1,
          label: '教师'
      },{
          value: 2,
          label: '学生'
      },{
          value: 3,
          label: '普通用户'
      }
      ],
      statusMsg: '',
      error: '',
      isDisable: false,
      codeLoading: false,
      
      rules: {
        email: [{
          required: true,
          type: 'email',
          message: '请输入邮箱',
          trigger: 'blur'
        }],
        username: [{
          required: true,
          type: 'string',
          message: '请输入姓名',
          trigger: 'blur'
        },{
          validator: (rule, value, callback) => {
            if (value === '') {
              callback(new Error('请输入姓名，'))
            } else if (value.length<6) {
              callback(new Error('姓名长度过短，长度需大于6'))
            } else {
              callback()
            }
          },
          trigger: 'blur'
        }],
        password: [{
          required: true,
          message: '创建密码',
          trigger: 'blur'
        }, { pattern: /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,20}$/, message: '密码必须同时包含数字与字母,且长度为 8-20位' }],
        cpwd: [{
          required: true,
          message: '确认密码',
          trigger: 'blur'
        }, {
          validator: (rule, value, callback) => {
            if (value === '') {
              callback(new Error('请再次输入密码'))
            } else if (value !== this.registerForm.password) {
              console.log(this.registerForm.password);
              callback(new Error('两次输入密码不一致'))
            } else {
              callback()
            }
          },
          trigger: 'blur'
        }]

      }
    }
  },
  methods: {
    // 用户注册
    userRegister() {
      this.$refs['registerForm'].validate((valid) => {
        if (valid) {
          //  let pwd=encryption.encrypt(this.registerForm.password);
          //  console.log(pwd);
          var user = new FormData();
          user={
            username:this.registerForm.username,
            password: this.registerForm.password,    
            email: this.registerForm.email,
            is_active:this.registerForm.is_active,
            type:this.registerForm.type,
            is_superuser:""
          }
          if(user.type==0){
            user.is_superuser=1
          }
          else{
            user.is_superuser=0
          }
          console.log(user);
          register(user).then(res => {
            this.$message({
              showClose: true,
              message: '注册成功，正在跳转到登录界面...',
              type: 'success'
            })
            setTimeout(() => {
              this.$router.push('/')
            }, 2000)
          }).catch(err => {
            console.log(err.response.data.message)
          })
        }
      })
    }
  }
}
</script>

<style lang="scss">
/* 修复input 背景不协调 和光标变色 */
/* Detail see https://github.com/PanJiaChen/vue-element-admin/pull/927 */

$bg: #283443;
$light_gray: #fff;
$cursor: #fff;

@supports (-webkit-mask: none) and (not (cater-color: $cursor)) {
  .register-container .el-input input {
    color: $cursor;
  }
}

/* reset element-ui css */
.register-container {
  .el-input {
    display: inline-block;
    height: 47px;
    width: 95%;

    input {
      background: rgba(0, 0, 0, 0.1);
      border-radius: 5px;
      border: 1px solid rgba(255, 255, 255, 0.1);
      -webkit-appearance: none;
      padding: 12px 5px 12px 15px;
      color: $light_gray;
      height: 47px;
      caret-color: $cursor;

      &:-webkit-autofill {
        box-shadow: 0 0 0px 1000px $bg inset !important;
        -webkit-text-fill-color: $cursor !important;
      }
    }
  }

  .el-form-item {
    label {
      font-style: normal;
      font-size: 12px;
      color: $light_gray;
    }
  }
}
</style>

<style lang="scss" scoped>
$bg: #2d3a4b;
$dark_gray: #889aa4;
$light_gray: #eee;

.register-container {
  min-height: 100%;
  width: 100%;
  background-color: $bg;
  overflow: hidden;

  .header {
    border-bottom: 2px solid rgb(235, 232, 232);
    min-width: 980px;
    color: #666;

    header {
      margin: 0 auto;
      padding: 10px 0;
      width: 980px;

      .login {
        float: right;
      }

      .bold {
        font-style: normal;
        color: $light_gray;
      }
    }
  }

  > section {
    margin: 0 auto 30px;
    padding-top: 30px;
    width: 980px;
    min-height: 300px;
    padding-right: 100px;
    box-sizing: border-box;

    .status {
      font-size: 12px;
      margin-left: 20px;
      color: #e6a23c;
    }

    .error {
      color: red;
    }
  }

  .tips {
    float: right;
    font-size: 14px;
    color: #fff;
    margin-bottom: 10px;

    span {
      &:first-of-type {
        margin-right: 16px;
      }
    }
  }
}
</style>

<style scoped>
/* 修改验证器样式 */
 .el-form-item.is-error .el-input__inner {
  border-color: #889aa4;
}
 .el-form-item.is-error .el-input__validateIcon {
  color: #889aa4;
}
 .el-form-item__error {
  color: #e6a23c;
}
</style>

