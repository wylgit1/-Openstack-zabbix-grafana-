<template>
 <el-card style="margin: 25px; padding: 12px">
   <div slot="header">
        <div style="margin-left:30px;width:97%;height:30px;line-height:30px">
          <el-button type="primary"
                     size="mini"
                     icon="el-icon-edit"
                     plain
                     style="float:left"
                     @click="allot()">分配主机</el-button>
        <el-dialog
              title="提示"
              :visible.sync="dialogVisible"
              :before-close="handleClose"
            >
              <span>请选择给主机分配的用户</span>
              <el-form
                ref="allotNewUser"
                :model="allotNewUser"
                label-width="100px"
              >
              <el-form-item prop="nickname" label="用户姓名">
                  <el-select
                    class="nickname"
                    v-model="allotNewUser.nickname"
                    placeholder="nickname"
                  >
                    <el-option
                      v-for="(key, value, index) in usernames"
                      :key="index"
                      :label="key['username']"
                      :value="key['username']"
                    >
                    </el-option>
                  </el-select>
                </el-form-item>
                <el-form-item>
                  <el-button @click="dialogVisible = false">取消</el-button>
                  <el-button type="primary" @click="allotVM()"
                    >确定</el-button
                  >
                </el-form-item>
              </el-form>
            </el-dialog>
        </div>
   </div>
  <el-table
    :data="vm"
    tooltip-effect="dark"
    style="width: 100%"
    @selection-change="handleSelectionChange">
    <el-table-column
      type="selection"
      width="55">
    </el-table-column>
    <el-table-column
      prop="VM_name"
      label="主机"
      width="300">
    </el-table-column>
    <el-table-column
      prop="nickname"
      label="用户"
      width="300">
    </el-table-column>
  </el-table>
          </el-card>
</template>

<script>
import { getVMall,updateVM } from "@/api/vmManagement";
import {getUsername} from "@/api/user"

  export default {
    data() {
      return {
        //存放主机信息
        vm:[
                {
                VM_name:"",
                nickname: "",
                username:''
                }
            ],
        //存放分配时需要选择的主机名字
        usernames:[],
        //修改后的新用户信息
        allotNewUser:{
           nickname: "",
        },
        title:"",
        //dialog显示
        dialogVisible: false, 
        //选中的值
        multipleSelection: []
      }
    },
     mounted(){
        this.getVMMessage();
        this.getUsernames();
      },
    methods: {
      //得到所有虚拟机信息
      getVMMessage() {
          getVMall()
        .then((res) => {
          this.vm = res.data;         
        })
        .catch((err) => {
          console.log(err);
        });
    },

    //得到用户姓名
    getUsernames() {
      getUsername()
        .then((res) => {
          this.usernames = res.data;
          console.log(this.usernames);
        })
        .catch((err) => {
          console.log(err);
        });
    },
      // toggleSelection(rows) {
      //   if (rows) {
      //     rows.forEach(row => {
      //       this.$refs.multipleTable.toggleRowSelection(row);
      //     });
      //   } else {
      //     this.$refs.multipleTable.clearSelection();
      //   }
      // },

    //得到所选中的虚拟机信息
    handleSelectionChange(val) {
        this.multipleSelection = val;
        console.log(val)

      },
    //dialog控制关闭
    handleClose(done) {
      this.$confirm("确定关闭吗")
        .then(() => {
          // function(done)，done 用于关闭 Dialog
          done();
          console.info("点击右上角 'X' ，取消按钮或遮罩层时触发");
        })
        .catch(() => {
          console.log("点击确定时触发");
        });
    },
    //分配  弹出dialog
    allot(){
      this.dialogVisible = true;
      },
    //真正的分配
    allotVM(){
      for (let index = 0; index < this.multipleSelection.length; index++) {
        this.multipleSelection[index].nickname=this.allotNewUser.nickname;
        updateVM(this.multipleSelection[index])
          .then((res) => {
            console.log(res);
            this.dialogVisible=false;
            this.title=this.multipleSelection[index].VM_name+this.title+""
          })
          .catch((err) => {
            console.log(err);
          });
          }
          this.$notify({
              title: this.title+"修改成功",
              message: "！",
              type: "success",
            });
      }
    }
  }
</script>