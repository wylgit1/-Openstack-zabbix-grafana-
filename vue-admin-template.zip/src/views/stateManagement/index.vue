<template>
  <div>
    <el-alert
      title="提示:"
      type="info"
      show-icon
      effect="dark"
      style="margin: 25px; padding: 12px; width: 96%"
    >
    </el-alert>
    <el-card style="margin: 25px; padding: 12px">
      <el-table :data="table_data"
        @filter-change="HandeleFilterChange"
         ref="filterTable"  
         style="width: 100%">
        <el-table-column prop="VM_id" label="主机id"> </el-table-column>
        <el-table-column prop="VM_name" label="主机"> </el-table-column>
        <el-table-column prop="nickname" label="用户"> </el-table-column>
        <el-table-column prop="status" label="主机状态"> </el-table-column>
        <el-table-column label="操作">
          <template slot-scope="scope">
            <el-dropdown split-button type="primary">
        更多菜单
            <el-dropdown-menu slot="dropdown">
                        
                <!-- <el-dropdown-item @click.native="click()" ref="messageDrop">scope.row.黄金糕</el-dropdown-item> -->
                <span v-for="role,index in scope.row.role" :key="index">
                    <el-dropdown-item @click.native="changeStatus(scope.row,role.status)">{{role.value}}</el-dropdown-item>
	            </span>
                        
    </el-dropdown-menu>
    </el-dropdown>
    </template>
        </el-table-column>
       <el-table-column align="right"
                         >
          <template slot="header" slot-scope="scope">
            <el-input v-model="search"
                      size="mini"
                      placeholder="输入关键字搜索"
                       />
          </template>
                  </el-table-column>
      </el-table>
      <el-pagination :current-page="param.currentPage"
                     :page-sizes="[5, 10, 15, 20]"
                     :page-size="param.pagesize"
                     layout="total, sizes,prev, pager, next, jumper"
                     :total="parseInt(total)"
                     @size-change="handleSizeChange"
                     @current-change="handleCurrentChange" />
    </el-card>
  </div>
</template>

<script>
import cons from "@/components/constant";
import { getVM,updateVM } from "@/api/vmManagement";

export default {
  data() {
    return {
      //存放所有主机信息用以显示
      vm:[],
      tabledata:[],
      temp: "", //存放修改时所选的vm的id
      designatedVM: [], //存放修改时所选当前vm信息
      // 按钮字典
      roles: [{
          id:1,
          value: '关闭实例',
          status:'关闭',
      },{
          id:2,
          value: '恢复实例',
          status:'运行',
      },{
          id:3,
          value: '挂起实例',
          status:'挂起',
      }
      ],
      role1: [{
          id:1,
          value: '关闭实例',
          status:'关闭',
      },{
          id:2,
          value: '挂起实例',
          status:'挂起',
      }
      ],
      role2: [{
          id:1,
          value: '恢复实例',
          status:'运行',
      }
      ],

      /* 分页所需数据*/
      value: '100',
      param: {
        currentPage: 1, // 当前页
        pagesize: 5, // 默认每页多少张
      },
      total: 0, // 共多少页
      join: null,
      currentIndex: '',
			currentPage: 1, //初始页
			pagesize: 5, //    每页的数据

      /* 过滤器查询所需数据 */
      usernames:[],
      IPs:[{text: 'selfservice', value: 'selfservice'}, {text: 'provider', value: 'provider'}],
      selectdata: {nickname: [], ip: []},
      newData: [],
      twoData: [],
      data: [],
      listdata: '',

      //查询
        search:"",

// 验证规则
      rulesUpdateVM: {
        // username: [
        //   { required: true, message: '请输入用户名', trigger: 'blur' }
        // ],
        // password: [
        //   { required: true, message: '请输入用户密码', trigger: 'blur' }
        // ],
        // email: [
        //   { required: true, message: '请输入邮箱', trigger: 'blur' },
        //   {
        //     type: 'email',
        //     message: '请输入正确的邮箱地址',
        //     trigger: ['blur', 'change']
        //   }
        // ],
      },
    };
  },
  mounted() {
    this.getVMMessage(); //得到所有主机信息展示在页面
    
  },
  methods: {
    // changeRoles(vm){
        
    //     for (let i = 0; i < vm.length; i++) {
    //         for (let j = 0; j < this.roles.length; j++) {
    //             console.log("#############")
    //             console.log(vm[i].status)
    //             console.log(this.roles[j].status)
    //             if(vm[i].status==this.roles[j].status)
    //                { 
    //                    let temp=[{id:1,
    //                         value: '暂停实例',
    //                         status:'暂停',
    //                     },{
    //                         id:2,
    //                         value: '恢复实例',
    //                         status:'运行',
    //                     },{
    //                         id:3,
    //                         value: '挂起实例',
    //                         status:'挂起',
    //                     },{
    //                         id:4,
    //                         value: '废弃实例',
    //                         status:'废弃',}]
    //                    console.log(this.roles[j])
    //                     console.log("这是roles的值")
    //                     console.log(this.roles)
    //                  console.log("temp的值!")
    //                     console.log(temp)
    //                    delete(temp[j])
    //                    console.log("!!!!!!!!!!!!")
    //                     console.log(temp)
    //                     vm[i].roles=temp
    //                     console.log("#@#@#@#@")
    //                     console.log(this.roles)
    //                     console.log("!!!!#@#@#@#@")
    //                     console.log(vm[i].roles)
    //                }
    //         }
            
    //     }
    // },
    // 修改状态
    changeStatus(row,state){
      console.log("#####@@@@@@")
      console.log(row)
      for (let index = 0; index < this.vm.length; index++) {
        if (this.vm[index].id == row.id) {
          this.designatedVM = this.vm[index];
        }
      }
      console.log(this.designatedVM)
      this.designatedVM.status=state
      console.log("###@@@###")
      console.log(this.designatedVM)
        updateVM(this.designatedVM)
        .then((res) => {
          console.log(res);
          this.$notify({
            title: "更改状态成功",
            message: "！",
            type: "success",
          });
          this.getVMMessage();
        })
        .catch((err) => {
          console.log(err);
        });
    },

    //得到所有主机信息展示在页面
    getVMMessage() {
      getVM()
        .then((res) => {
          this.vm = res.data;
        //   this.changeRoles(this.vm)
        for (let index = 0; index < this.vm.length; index++) {
          if(this.vm[index].status=="运行"){
            this.vm[index].role=this.role1;
          }else{
            this.vm[index].role=this.role2;
          }
        }
          console.log(this.vm);
        })
        .catch((err) => {
          console.log(err);
        });
    }, 

    //控制关闭dialog
    handleClose(done) {
      this.$confirm("确定关闭吗")
        .then(() => {
          // function(done)，done 用于关闭 Dialog
          done();

          console.info("点击右上角 'X' ，取消按钮或遮罩层时触发");
        })
        .catch(() => {
          console.log("点击确定时触发");
        });
    },
    handleClick() {
        alert('button click');
        this.$refs.messageDrop.hide();
    },

    /* 查询相关 */
  //获取用户姓名用以过滤器查询
  getUsernames(){
    getUsername()
        .then((res) => {
          console.log("***************#@^%^");
          console.log(res);
          this.usernames=res.data;
          for (let index = 0; index < res.data.length; index++) {
            this.usernames[index].text = res.data[index].username;
            this.usernames[index].value = res.data[index].username;
          }
          console.log(this.usernames)
        })
        .catch((err) => {
          console.log(err);
        });
  },
  /*过滤器*/
  filterHandler(value, row, column) {
        const property = column['property'];
        return row[property] === value;
      },
  //控制过滤数据
  HandeleFilterChange(filters){
    //调用时重新将全部vm信息给newdata
     this.newData = [];
     for (let p = 0; p < this.tabledata.length; p++) {
              this.newData.push(this.tabledata[p])
            }
     console.log("###@@@");
       console.log(this.tabledata)
      this.selectdata[String(Object.keys(filters))] = filters[String(Object.keys(filters))]
      console.log("###@@@1")
     console.log(this.selectdata);
      console.log("###@@@2")
     console.log(this.newData);
      //循环遍历选择数组
      for (let j = 0; j < Object.keys(this.selectdata).length; j++) {
        console.log("选择数组长度")
        console.log(this.selectdata[Object.keys(this.selectdata)[j]].length)
        //如果筛选条件只有一个
        if (this.selectdata[Object.keys(this.selectdata)[j]].length <= 1) {
          for (let k = 0; k < this.selectdata[Object.keys(this.selectdata)[j]].length; k++) {
            for (let i = 0; i < this.newData.length; i++) {
              if (this.selectdata[Object.keys(this.selectdata)[j]][k] !== this.newData[i][String(Object.keys(this.selectdata)[j])]) {
                this.newData.splice(i, 1)
                i--
              }
            }
          }
        } else {
          // 筛选条件有多个
          this.twoData = []
          for (let k = 0; k < this.selectdata[Object.keys(this.selectdata)[j]].length; k++) {
            for (let i = 0; i < this.newData.length; i++) {
              if (this.selectdata[Object.keys(this.selectdata)[j]][k] === this.newData[i][String(Object.keys(this.selectdata)[j])]) {
                this.twoData.push(this.newData[i])
              }
            }
          }
          if (this.twoData.length !== 0) {
            this.newData = []
            for (let io = 0; io < this.twoData.length; io++) {
              this.newData.push(this.twoData[io])
            }
          }
        }
      }
      console.log("###@@@$")
      console.log(this.newData)
      this.vm = this.newData
    },
  
  /* 分页 */
    handleSizeChange: function(size) {
			this.pagesize = size;
			// console.log(this.pagesize) //每页下拉显示数据
		},
		handleCurrentChange: function(currentPage) {
			this.currentPage = currentPage;
			// console.log(this.currentPage) //点击第几页
		},

  },
   computed: {
  table_data() {
    let search = this.search;
    // 搜索功能
    if (search){
      let list =this.vm.filter(data => !search || data.nickname.toLowerCase().includes(search.toLowerCase())|| data.VM_name.toLowerCase().includes(search.toLowerCase()));
      let fenye = list.slice((this.currentPage-1)*this.pagesize,this.currentPage*this.pagesize);
      // 获取查询的结果，把数组长度赋值给 分页组件中的total
      this.total = fenye.length;
      return list,fenye
    }
    // 分页功能
    else {
     //所有数据的长度  赋值给分页组件中的total
      this.total = this.vm.length;                        
      let fenye = this.vm.slice((this.currentPage-1)*this.pagesize,this.currentPage*this.pagesize)
      return fenye
    }
  }
}
};
</script>

<style>
  .el-dropdown {
    vertical-align: top;
  }
  .el-dropdown + .el-dropdown {
    margin-left: 15px;
  }
  .el-icon-arrow-down {
    font-size: 12px;
  }

</style>