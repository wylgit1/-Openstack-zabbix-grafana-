<template>
  <div class="control_git">
    <div class="left">
      <!--     <datatable ref="datatable" :columns="columns" :table-data="tableData" @operater="operater" />-->
      <el-table
        ref="singleTable"
        :data="tableData"
        highlight-current-row
        @current-change="handleCurrentChange"
        style="width: 100%">
        <el-table-column
          property="codeName"
          label="编号">
        </el-table-column>
        <el-table-column
          fixed="right"
          label="操作"
          width="100">
          <template slot-scope="scope">
            <el-button :disabled="scope.row.status===1" @click.native.prevent="packageApp(scope.$index, scope.row)"
                       fcontrol type="text" 
                       size="small">
              {{ scope.row.status === 0 ? "打包" : "正在打包" }}
            </el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <div class="right">
      <codemirror ref="codemirror" v-model="content" :options="options"></codemirror>
    </div>
  </div>
</template>
<script>
  import datatable from '@/wegits/datatable'
  import {codemirror} from 'vue-codemirror'
  import 'codemirror/lib/codemirror.css'
  import 'codemirror/theme/rubyblue.css'
  import 'codemirror/mode/javascript/javascript.js'

  export default {
    name: 'controlGit',
    components: {datatable, codemirror},
    data() {
      return {
        editDialogShow: false,
        tableData: [],
        searchItem: {gitCode: '', gitUrl: '', account: '', password: '', page: {page: 1, size: 10}},
        editItem: {id: null, gitCode: '', gitUrl: '', account: '', password: ''},

        content: '',
        // 默认配置
        options: {
          tabSize: 2, // 缩进格式
          theme: 'rubyblue', // 指定主题，对应主题库 JS 需要提前引入
          lineNumbers: true, // 是否显示行号
          //指定语言类型,如果需要编辑和显示其他语言,需要import语言js然后修改此配置
          mode: 'javascript',
          line: true,
          styleActiveLine: true, // 高亮选中行
          //是否为只读,如果为"nocursor" 不仅仅为只读 连光标都无法在区域聚焦
          readOnly: true,
          // hintOptions: {
          //   completeSingle: true // 当匹配只有一项的时候是否自动补全
          // },
          viewportMargin: 30
        },
      }
    },
    mounted: function () {
      this.loadTableData();
    },
    methods: {
      packageApp: function (index, row) {
        this.$confirm('确定要开始打包吗？').then(() => {
          this.$post('/fcontrol/app/startPackage', {id: row.id}).then(res => {
            if (res.data.code === '1') {
              this.loadTableData();
              let message = JSON.stringify(row);
              this.$ws.send(message);  // 这里是自己分装的websocket代码
              this.$ws.ws.onmessage = this.onmessage;
            }
          }).catch(this.$error);
        });
      },

      setCurrent(row) {
        this.$refs.singleTable.setCurrentRow(row);
      },
      handleCurrentChange(val) {
        this.currentRow = val;
      },
      operater: function (op, data) {
        if (op === 'edit') {
          this.$copy(data, this.editItem);
          this.editDialogShow = true;
        } else if (op === 'page') {
          this.searchItem.page.page = data;
          this.loadTableData();
        } else if (op === 'delete') {
          this.$confirm('您确定要删除吗？').then(() => {
            this.$post('/fcontrol/app/xxxx', {id: data.id}).then(res => {
              if (res.data.code === '1') {
                this.$success('删除成功');
                this.loadTableData();
              }
            }).catch(this.$error);
          });
        }
      },
      saveItem: function () {
        this.$post('/fcontrol/controlGit/saveControlGit', this.editItem).then(res => {
          if (res.data.code === '1') {
            this.$success('保存成功');
            this.editDialogShow = false;
            this.loadTableData();
          } else {
            this.$error('保存失败');
          }
        }).catch(this.$error);
      },
      addItem: function () {
        this.$clear(this.editItem);
        this.editItem.status = 1;
        this.editDialogShow = true;
      },
      reset: function () {
        this.$clear(this.searchItem);
        this.loadTableData();
      },
      loadTableData: function () {
        this.$post('/fcontrol/app/queryApps', this.searchItem).then(res => {
          let dataArr = res.data.data;
          for (let i = 0; i < dataArr.length; i++) {
            dataArr[i]["codeName"] = "[" + dataArr[i].appCode + "]" + dataArr[i].appName;
            if (dataArr[i].status === 1) {
              let msg = JSON.stringify(dataArr[i]);
              this.$ws.send(msg)
              this.$ws.ws.onmessage = this.onmessage;
            }
          }
          this.tableData = dataArr;
        }).catch(this.$error);
      },
// ********************核心代码******************
      onmessage: function (message) {
        console.log(message);
        this.content = this.content +  message.data+"\r";
        // 获取滚动信息  注意是两个codemirror.codemirror
        let sc = this.$refs.codemirror.codemirror.getScrollInfo(); 
        // 滚动 注意是两个codemirror.codemirror
        this.$refs.codemirror.codemirror.scrollTo(sc.left,( sc.height + sc.top));
      },
    }
// ********************核心代码******************
  }
</script>

<style lang="scss" scoped>
  .control_git {
    position: absolute;
    height: 100%;
    width: 100%;
    display: flex;

    .left {
      flex: 3;
      height: 100%;
      border-right: solid 1px #cccccc;
      box-sizing: border-box;
    }

    .right {
      flex: 8;
      height: 100%;
    }
  }
</style>
<style>
  .vue-codemirror, .CodeMirror {
    height: 100% !important;
  }
</style>