<template>
  <div>
    <el-card style="margin: 25px; padding: 12px">
      <div style="float: right; margin-right: 13px">
        <router-link :to="{ path: '/monitor/child/'}"
                     replace>
          <el-button type="primary"
                     size="mini"
                     icon="el-icon-edit"
                     plain>添加触发器</el-button>

        </router-link>
      </div>
      <el-table :data="
          tableData.filter(
            (data) =>
              !search ||
              data.priority.toLowerCase().includes(search.toLowerCase()) ||
              data.triggerid.toLowerCase().includes(search.toLowerCase()) ||
              data.expression.toLowerCase().includes(search.toLowerCase()) ||
              data.description.toLowerCase().includes(search.toLowerCase()) ||
              data.templateid.toLowerCase().includes(search.toLowerCase())
          )
        "
                style="width: 100%"
                stripe>
        <el-table-column label="触发器id"
                         prop="triggerid"
                         align="center">
        </el-table-column>
        <el-table-column label="触发器名称"
                         prop="description"
                         align="center">
        </el-table-column>

        <el-table-column align="center"
                         width="150">
          <template slot="header"
                    slot-scope="scope">
            <el-input v-model="search"
                      size="mini"
                      placeholder="输入关键字搜索" />
          </template>
          <template slot-scope="scope">
            <el-button type="danger"
                       size="mini"
                       icon="el-icon-delete"
                       circle
                       @click="handleDel(scope.$index, scope.row)"></el-button>
          </template>
        </el-table-column>
      </el-table>
      <el-pagination :current-page="param.currentPage"
                     :page-sizes="[5, 10, 15, 20]"
                     :page-size="param.pagesize"
                     layout="total, sizes, prev, pager, next, jumper"
                     :total="total"
                     @size-change="handleSizeChange"
                     @current-change="handleCurrentChange" />
    </el-card>
  </div>
</template>

<script>
import cons from "@/components/constant";

export default {
  data () {
    return {
      tableData: [],
      search: "",
      value: '100',
      param: {
        currentPage: 1, // 当前页
        pagesize: 5, // 默认每页多少张
        hostid: ''
      },
      total: 0, // 共多少页
      join: null,
      forms: ["$form"],
      model: {
        host_name: "",
        host_ip: "",
        host_group: "",
        host_template: "",
      },
      host_group_data: null,
      host_template_data: [
        {
          label: "选项1",
          value: "1",
          disabled: false,
        },
      ],
      submit_loading: false,
    };
  },

  mounted () {
    this.getList()
  },

  methods: {

    //获取基本数据
    getList: function (num) {
      let token = localStorage.token;
      const vm = this;
      vm.param.hostid = sessionStorage.getItem('hostid')
      console.log(vm.param);
      this.$http
        .post(cons.apis + "/get/trigger/", vm.param, {
          responseType: "json",
        })
        .then((res) => {
          if (res.status == 200)
          {
            console.log("!!!!!!!!!!!!!!!!!!!!")
            console.log(res)
            console.log(res.data)
            vm.total = res.data.total;
            vm.tableData = res.data;
          }
        })
        .catch((err) => {
          console.log(err);
        });
    },

    //删除指定内容
    handleDel (index, row) {
      console.log(row.triggerid);
      this.$http
        .get(
          cons.apis + "/del/trigger/?triggerid=" + row.triggerid,
          {
            responseType: "json",
          }
        )
        .then((res) => {
          if (res.data.code == 200)
          {
            // console.log(res.data.data);
            this.getList();
          }
          else
          {
            console.log(res);
            alert("Cannot delete templated trigger")
          }
        })
        .catch((err) => {
          console.log(err);
        });
    },

    //以下两个是分页功能的实现
    handleSizeChange: function (size) {
      const a = this;
      a.param.pagesize = size;
      this.getList();
      console.log(a.param.pagesize); // 每页下拉显示数据
    },
    handleCurrentChange: function (currentPage) {
      const b = this;
      b.param.currentPage = currentPage;
      console.log(this.currentPage); // 点击第几页
      this.getList();
    },

    //添加内容前获取基本信息
    addTrigger () {
      this.$router.push('/')
    },

  },
};
</script>
