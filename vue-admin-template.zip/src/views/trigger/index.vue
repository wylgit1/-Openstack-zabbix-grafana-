<template>
  <div>
       <el-card style="margin: 25px; padding: 12px">

      <div slot="header">
        <div style="float:left">
          <svg t="1635682143547"
               class="icon"
               viewBox="0 0 1141 1024"
               version="1.1"
               xmlns="http://www.w3.org/2000/svg"
               p-id="4261"
               width="30"
               height="30">
            <path d="M1140.483293 937.937675v-715.169869a72.962543 72.962543 0 0 0-65.810845-79.505586 82.472781 82.472781 0 0 0-13.694742 0H613.235719a70.109472 70.109472 0 0 1-41.464636-12.553514s-19.020475-31.573989-54.01815-82.548863c-31.573989-57.061426-73.038625-47.551188-73.038625-47.551188h-346.172649a92.0591 92.0591 0 0 0-98.145652 85.592139 36.861681 36.861681 0 0 0-0.38041 6.466961v838.802959c0 104.612614 79.505587 92.0591 79.505587 92.0591h991.347169c82.548863 0 69.614939-85.592139 69.61494-85.592139zM289.126821 756.482341h-3.804095a58.811309 58.811309 0 0 1-56.681017-60.104701v-4.184505a58.316777 58.316777 0 0 1 60.485112-56.300607 60.294907 60.294907 0 1 1 0 120.589813z m0-225.582836h-3.804095a58.773269 58.773269 0 0 1-56.681017-60.104702 60.485111 60.485111 0 1 1 60.485112 60.104702z m590.775961 222.53956H498.732458a57.25163 57.25163 0 0 1 0-114.503261h381.170324a57.25163 57.25163 0 1 1 0 114.503261z m0-225.582836H498.732458a57.25163 57.25163 0 0 1 0-114.503261h381.170324a57.25163 57.25163 0 1 1 0 114.503261z"
                  fill="#2D9EF4"
                  p-id="4262"></path>
          </svg>
        </div>
      </div>
      <div style="float: right; margin-right: 13px">
        <router-link :to="{ path: '/monitor/child/'}"
                     replace>
          <el-button type="primary"
                     size="mini"
                     icon="el-icon-edit"
                     plain>添加触发器</el-button>

        </router-link>
      </div>
       <el-table :data="table_data"
         ref="filterTable"  
         style="width: 100%">
          <el-table-column type="index"
                         width="50">
        </el-table-column>
        <el-table-column label="触发器id"
                         prop="triggerid"
                         align="center">
        </el-table-column>
        <el-table-column label="触发器名称"
                         prop="description"
                         align="center">
        </el-table-column>

        <el-table-column align="center"
                         width="150">
          <template slot="header"
                    slot-scope="scope">
            <el-input v-model="search"
                      size="mini"
                      placeholder="输入关键字搜索" />
          </template>
          <template slot-scope="scope">
            <el-button type="danger"
                       size="mini"
                       icon="el-icon-delete"
                       circle
                       @click="handleDel(scope.$index, scope.row)"></el-button>
          </template>
        </el-table-column>
      </el-table>
       <el-pagination :current-page="param.currentPage"
                     :page-sizes="[5, 10, 15, 20]"
                     :page-size="param.pagesize"
                     layout="total, sizes, prev, pager, next, jumper"
                     :total="parseInt(total)"
                     @size-change="handleSizeChange"
                     @current-change="handleCurrentChange" />
    </el-card>
  </div>
</template>

<script>
import cons from "@/components/constant";

export default {
  data () {
    return {
      tableData: [],
      search: "",
      value: '100',
      param: {
        currentPage: 1, // 当前页
        pagesize: 5, // 默认每页多少张
        hostid: ''
      },
      total: 0, // 共多少页
      join: null,
      forms: ["$form"],
      model: {
        host_name: "",
        host_ip: "",
        host_group: "",
        host_template: "",
      },
      host_group_data: null,
      host_template_data: [
        {
          label: "选项1",
          value: "1",
          disabled: false,
        },
      ],
      submit_loading: false,
    };
  },

  mounted () {
    this.getList()
  },

  methods: {

    //获取基本数据
    getList: function (num) {
      let token = localStorage.token;
      const vm = this;
      vm.param.hostid = sessionStorage.getItem('hostid')
      console.log("8888888888vm.param8888888888")
      console.log(vm.param);
      this.$http
        .post(cons.apis + "/get/trigger/", vm.param, {
          responseType: "json",
        })
        .then((res) => {
          if (res.status == 200)
          {
            console.log("!!!!!!!!!!!!!!!!!!!!")
            console.log(res)
            console.log(res.data)
            vm.total = res.data.total;
            vm.tableData = res.data;
            console.log("!!!!!!888888!!!!!!!!")
            console.log(this.tableData)
          }
        })
        .catch((err) => {
          console.log(err);
        });
    },

    //删除指定内容
    handleDel (index, row) {
      console.log(row.triggerid);
      this.$http
        .get(
          cons.apis + "/del/trigger/?triggerid=" + row.triggerid,
          {
            responseType: "json",
          }
        )
        .then((res) => {
          if (res.data.code == 200)
          {
            // console.log(res.data.data);
            this.getList();
          }
          else
          {
            console.log(res);
            alert("Cannot delete templated trigger")
          }
        })
        .catch((err) => {
          console.log(err);
        });
    },

    //以下两个是分页功能的实现
    handleSizeChange: function (size) {
      const a = this;
      a.param.pagesize = size;
      this.getList();
      console.log(a.param.pagesize); // 每页下拉显示数据
    },
    handleCurrentChange: function (currentPage) {
      const b = this;
      b.param.currentPage = currentPage;
      console.log(this.currentPage); // 点击第几页
      this.getList();
    },

    //添加内容前获取基本信息
    addTrigger () {
      this.$router.push('/')
    },

  },
  computed: {
  table_data() {
    let search = this.search;
    // 搜索功能
    if (search){
      let list =this.tableData.filter(data => !search || data.nickname.toLowerCase().includes(search.toLowerCase())|| data.VM_name.toLowerCase().includes(search.toLowerCase()));
      let fenye = list.slice((this.param.currentPage-1)*this.param.pagesize,this.param.currentPage*this.param.pagesize);
      // 获取查询的结果，把数组长度赋值给 分页组件中的total
      this.total = fenye.length;
      return list,fenye
    }
    // 分页功能
    else {
     //所有数据的长度  赋值给分页组件中的total
      this.total = this.tableData.length;                        
      let fenye = this.tableData.slice((this.param.currentPage-1)*this.param.pagesize,this.param.currentPage*this.param.pagesize)
      return fenye
    }
  }
}
};
</script>
