<template>
  <div>
    <!-- <el-alert
      title="提示:"
      type="info"
      show-icon
      effect="dark"
      style="margin: 25px; padding: 12px; width: 96%"
    >
    </el-alert> -->

    <el-card style="margin: 25px; padding: 12px">
      <div slot="header">
        <div
          style="margin-left: 30px; width: 97%; height: 30px; line-height: 30px"
        >
          <el-button
            type="primary"
            size="mini"
            icon="el-icon-edit"
            plain
            style="float: left"
            @click="create()"
            >创建快照</el-button
          >
          <el-dialog
            title="提示"
            :visible.sync="createdialogVisible"
            :before-close="handleClose"
          >
            <span>创建快照</span>
            <el-form
              ref="createSSinfo"
              :rules="rulesUpdateVM"
              :model="createSSinfo"
              label-width="100px"
            >
              <el-form-item prop="VM_name" label="主机名">
                <el-select
                  class="VM_name"
                  v-model="createSSinfo.VM_name"
                  placeholder="VM_name"
                >
                  <el-option
                    v-for="(key, value, index) in VM_names"
                    :key="index"
                    :label="key['VM_name']"
                    :value="key['VM_name']"
                  >
                  </el-option>
                </el-select>
              </el-form-item>
              <el-form-item prop="snapshoot_user" label="所属用户">
                <el-select
                  class="snapshoot_user"
                  v-model="createSSinfo.snapshoot_user"
                  placeholder="snapshoot_user"
                >
                  <el-option
                    v-for="(key, value, index) in users"
                    :key="index"
                    :label="key['username']"
                    :value="key['username']"
                  >
                  </el-option>
                </el-select>
              </el-form-item>
              <el-form-item prop="snapshoot_name" label="快照名称">
                <el-input v-model="createSSinfo.snapshoot_name"></el-input>
              </el-form-item>
              <el-form-item prop="snapshoot_describe" label="快照描述">
                <el-input v-model="createSSinfo.snapshoot_describe"></el-input>
              </el-form-item>
              <el-form-item>
                <el-button @click="createdialogVisible = false">取消</el-button>
                <el-button type="primary" @click="createSnapShoot()"
                  >确定</el-button
                >
              </el-form-item>
            </el-form>
            <!-- <span slot="footer" class="dialog-footer">
                <el-button @click="dialogVisible = false">取 消</el-button>
                <el-button type="primary" @click="dialogVisible = false"
                  >确 定</el-button
                >
              </span> -->
          </el-dialog>
        </div>
      </div>
           <el-table :data="table_data"
           @filter-change="HandeleFilterChange"
         ref="filterTable"  style="width: 100%">
        <el-table-column prop="VM_id" label="主机id"> </el-table-column>
        <el-table-column 
        prop="VM_name" 
        label="主机"
        column-key="VM_name"
        :filters="vmnames"
        :filter-method="filterHandler"> </el-table-column>
        <el-table-column 
        prop="snapshoot_name" 
        label="快照名字"
        >
        </el-table-column>
        <el-table-column prop="snapshoot_describe" label="快照描述">
        </el-table-column>
        <el-table-column
          prop="snapshoot_user"
          label="快照用户"
          column-key="snapshoot_user"
          :filters="usernames"
          :filter-method="filterHandler"
        ></el-table-column>
        <!-- <el-table-column align="center"
                         width="100">
          <template slot="header">
            <el-input v-model="search"
                      size="mini"
                      placeholder="输入关键字搜索" />
          </template>
                  </el-table-column> -->

        <el-table-column label="操作">
          <template slot-scope="scope">
            <el-dropdown split-button type="primary" @click="update(scope.$index, scope.row)">
              修改信息
              <el-dropdown-menu slot="dropdown">
                <el-dropdown-item @click.native="update(scope.$index, scope.row)">修改信息</el-dropdown-item>
                <el-dropdown-item  @click.native="restoreSnapShoot(scope.$index, scope.row)">恢复快照</el-dropdown-item>
                <el-dropdown-item @click.native="deleteSnapShoot(scope.$index, scope.row)">删除快照</el-dropdown-item>
              </el-dropdown-menu>
            </el-dropdown>
            <!-- <el-button size="mini" @click="update(scope.$index, scope.row)" type="primary"
              >修改信息</el-button
            > -->
            <el-dialog
              title="提示"
              :visible.sync="dialogVisible"
              :before-close="handleClose"
            >
              <span>请输入需要修改的信息</span>
              <el-form
                ref="updateSSinfo"
                :rules="rulesUpdateVM"
                :model="updateSSinfo"
                label-width="100px"
              >
                <el-form-item prop="snapshoot_name" label="快照名称">
                  <el-input v-model="updateSSinfo.snapshoot_name"></el-input>
                </el-form-item>
                <el-form-item prop="snapshoot_describe" label="快照描述">
                  <el-input
                    v-model="updateSSinfo.snapshoot_describe"
                  ></el-input>
                </el-form-item>
                <el-form-item>
                  <el-button @click="dialogVisible = false">取消</el-button>
                  <el-button type="primary" @click="updateEdit()"
                    >确定</el-button
                  >
                </el-form-item>
              </el-form>
              <!-- <span slot="footer" class="dialog-footer">
                <el-button @click="dialogVisible = false">取 消</el-button>
                <el-button type="primary" @click="dialogVisible = false"
                  >确 定</el-button
                >
              </span> -->
            </el-dialog>
            <!-- <el-button
              size="mini"
              @click="restoreSnapShoot(scope.$index, scope.row)"
              type="primary"
              >恢复快照</el-button
            > -->
            <!-- &nbsp;&nbsp;<el-button
              size="mini"
              @click="deleteSnapShoot(scope.$index, scope.row)"
              type="danger"
              >删除快照</el-button
            > -->
          </template>
        </el-table-column>
      </el-table>
      <el-pagination :current-page="param.currentPage"
                     :page-sizes="[5, 10, 15, 20]"
                     :page-size="param.pagesize"
                     layout="total, sizes,prev, pager, next, jumper"
                     :total="parseInt(total)"
                     @size-change="handleSizeChange"
                     @current-change="handleCurrentChange" />
    </el-card>
  </div>
</template>

<script>
import cons from "@/components/constant";
import { createVM } from "@/api/vm";
import { getVMname,getVM,deleteVM} from "@/api/vmManagement";
import { getMsg } from "@/api/vm_info";
import { getSS, createSS, deleteSS,updateSS,getappointedSS } from "@/api/snapshoot";
import { getUsername } from "@/api/user";

export default {
  data() {
    return {
      //存放所有快照信息用以显示
      SS: [],
      tabledata:[],
      // 存放创建快照提交的信息
      createSSinfo: {
        snapshoot_id: 1,
      },
      // 存放创建时需要显示的所有用户名字
      users: [],
      // 存放创建时需要显示的所有虚拟机名字
      VM_names: [],
      // 修改所需信息
      temp: "", //存放修改时所选的vmid
      designatedSS: [], //存放修改时选定的快照信息
      // 控制创建时的dialog的显示
      createdialogVisible: false,
      dialogVisible: false, //修改时dialog显示
      floatingIp: [], //存放修改时浮动ip可选信息
      flavor: [], //存放修改时flavor可选信息
      // 修改快照时所提交的信息
      updateSSinfo: {
        snapshoot_name: "",
        snapshoot_describe: "",
      }, 
      //恢复快照时指定的快照信息
      appointedSS:{},
      appointedVM:{

      },
      VMlist:[],
      createForm: {
        VM_id:"",
        VM_name: "",
        nickname: "",
        // number: "",
        ip: "",
        // rent_time: null,
        flavor: "",
        image: "",
        image_type: "",
        client_mac: "1",
        floating_ip: "",
        VM_security_group: "",
        sign: "1",
        status: "static",
      },

      //过滤器查询用
      vmnames:[],
      usernames:[],
      selectdata: {VM_name: [], snapshoot_user: []},
      newData: [],
      twoData: [],
      data: [],
      listdata: '',

      /* 分页所需数据*/
      value: '100',
      param: {
        currentPage: 1, // 当前页
        pagesize: 5, // 默认每页多少张
      },
      total: 0, // 共多少页
      join: null,
      currentIndex: '',
			currentPage: 1, //初始页
			pagesize: 5, //    每页的数据

      // 验证规则
      rulesUpdateVM: {
        // username: [
        //   { required: true, message: '请输入用户名', trigger: 'blur' }
        // ],
        // password: [
        //   { required: true, message: '请输入用户密码', trigger: 'blur' }
        // ],
        // email: [
        //   { required: true, message: '请输入邮箱', trigger: 'blur' },
        //   {(
        //     type: 'email',
        //     message: '请输入正确的邮箱地址',
        //     trigger: ['blur', 'change']
        //   }
        // ],
      },
    };
  },
  mounted() {
    this.getVMnames(); //得到创建时需要显示的所有虚拟机名字
    this.fetchData(); // 得到修改所需数据
    this.getUsernames();// 得到创建时需要显示的所有用户名字
    this.getSnapShoot();// 得到所有快照信息展示在页面
    this.getVMMessage();
    // let VM_name = this.$router.params.VM_name;
    // if(VM_name){
    //     console.log("vmname######");
    //     console.log(VM_name);
    //     this.selectdata['nickname'][0]=VM_name;
    //     this.HandeleFilterChange();
    //     // let id = this.$router.params.userId;
    // // if(id){

    // // }
    // }
  },
  methods: {
    //得到路由跳转传过来参数后修改选择数组进行筛选
    getParams(VM_name){
      console.log("##取到路由带过来的参数@@")
      console.log(VM_name);
      console.log(this.selectdata['VM_name']);
	    this.selectdata['VM_name'][0]=VM_name;   // 将数据放在当前组件的数据内
	    this.routerFilterChange(this.selectdata);

    },
    //得到创建时需要显示的所有虚拟机名字
    getVMnames() {
      // let _this = this
      getVMname()
        .then((res) => {
          this.VM_names = res.data;
          console.log("##@@")
          console.log(this.VM_names[0]);
          this.vmnames=res.data;
          console.log(this.vmnames)
          for (let index = 0; index < res.data.length; index++) {
            this.vmnames[index].text = res.data[index].VM_name;
            this.vmnames[index].value = res.data[index].VM_name;
          }
          console.log(this.vmnames)
        })
        .catch((err) => {
          console.log(err);
        });
    },
    // 得到创建时需要显示的所有用户名字
    getUsernames() {
      getUsername()
        .then((res) => {
          this.users = res.data;
          this.usernames=res.data;
          for (let index = 0; index < res.data.length; index++) {
            this.usernames[index].text = res.data[index].username;
            this.usernames[index].value = res.data[index].username;
          }
          console.log(this.usernames)
          console.log(this.users);
        })
        .catch((err) => {
          console.log(err);
        });
    },

    //得到所有快照信息展示在页面
    getSnapShoot() {
      getSS()
        .then((res) => {
          this.SS = res.data;
          this.tabledata=res.data;//过滤器查询用
          console.log("所有数据")
          console.log(this.SS);
          const VM_name = this.$route.query.VM_name;   // 取到路由带过来的参数
          console.log("####VM_name");
          console.log(VM_name);
          //如果获取到跳转传递的数据则进行筛选
          if(VM_name){
          this.getParams(VM_name);
          }
        })
        .catch((err) => {
          console.log(err);
        });
    },

    // 创建 弹出创建快照的dialog
    create() {
      this.createdialogVisible = true;
    },

    //真正进行创建快照
    createSnapShoot() {
      console.log("###@#@$$$$");
      console.log(this.createSSinfo);
      let $this=this
      let loading = this.$loading({
        lock:true,
        text:"创建中，请稍候...",
        background:'rgba(0,0,0,0.5)'
      })
      createSS(this.createSSinfo)
        .then((res) => {
          console.log(res);
          loading.close()
          this.createdialogVisible = false;
          this.$notify({
            title: "创建成功",
            message: "！",
            type: "success",
          });
        })
        .catch((err) => {
          console.log(err);
        });
    },

    // 删除快照
    deleteSnapShoot(index, row) {
      deleteSS(row)
        .then((res) => {
          this.getSnapShoot();
          this.$notify({
            title: "删除成功",
            message: "！",
            type: "success",
          });
        })
        .catch((err) => {
          console.log(err);
        });
    },

    /* 恢复快照*/
    //得到需要恢复的快照信息
     restoreSnapShoot(index,row){
      getappointedSS(row)
          .then((res) => {
            console.log("指定快照信息")
            console.log(res.data);
            this.appointedSS=res.data;
             this.getappointedVM(res.data.VM_id);
          })
          .catch((err) => {
            console.log(err);
          });
    },
    //获得主机列表全部信息
    getVMMessage() {
      getVM()
        .then((res) => {
          this.VMlist = res.data;
          console.log(this.VMlist);
        })
        .catch((err) => {
          console.log(err);
        });
    },
    //根据快照信息中的主机id获得主机信息，删除之前的并且创建新的
    getappointedVM(VM_id){
      for (let index = 0; index < this.VMlist.length; index++) {
        if(this.VMlist[index].VM_id==VM_id){
          this.appointedVM = this.VMlist[index];
          }
      }
      console.log("指定主机信息")
      console.log(this.appointedVM);
      //删除指定主机
      this.destroyVM();
      Reflect.deleteProperty(this.appointedVM,'VM_id');
      this.appointedVM.status="static";
      this.appointedVM.image=this.appointedSS.snapshoot_name;
      console.log(this.appointedVM);
      createVM(this.appointedVM).then(res => {
        console.log(res)
        //前端提示提交成功
         this.$notify({
          title: '恢复快照成功',
          message: '！',
          type: 'success'
        });
        this.$router.push("/vmManagement/index");
        this.recordSecurityGroup(this.appointVM);
      }).catch(err =>{
        console.log(err)
      });
      // appointVM(row)
      //     .then((res) => {

      //       console.log(res.data);
      //       this.appointedVM=res.data;
      //     })
      //     .catch((err) => {
      //       console.log(err);
      //     });
    },
    destroyVM(data){
      deleteVM(data)
        .then((res) => {
          loading.close()         
        })
        .catch((err) => {
          console.log(err);
        });
    },
      // restoreSS(row)
      //   .then((res) => {
      //     this.getSnapShoot();
      //     this.$notify({
      //       title: "恢复快照成功",
      //       message: "！",
      //       type: "success",
      //     });
      //   })
      //   .catch((err) => {
      //     console.log(err);
      //   });
    // },

    // 得到修改所需数据
    fetchData() {
      getMsg()
        .then((res) => {
          console.log(res);
          this.flavor = res["flavor"];
          this.keys = res["key"];
          this.securityGroup = res["security_group"];
          this.network = res["network"];
          this.image = res["host_image"];
          this.floatingIp = res["floating_ip"];
        })
        .catch((err) => {
          this.init = false;
          this.err = true;
        });
    },

    //控制关闭dialog
    handleClose(done) {
      this.$confirm("确定关闭吗")
        .then(() => {
          // function(done)，done 用于关闭 Dialog
          done();

          console.info("点击右上角 'X' ，取消按钮或遮罩层时触发");
        })
        .catch(() => {
          console.log("点击确定时触发");
        });
    },

    // 修改 弹出修改快照dialog
    update(index, row) {
      this.dialogVisible = true;
      console.log(row.id);
      // 存放当前行修改的快照id
      this.temp = row.id;
    },
    // 真正修改快照
     updateEdit() {
      // 循环遍历SS找到修改指定的SS信息
      for (let index = 0; index < this.SS.length; index++) {
        if (this.SS[index].id == this.temp) {
          this.designatedSS = this.SS[index];
        }
      }
      console.log(this.designatedSS);
      // 判断需要修改的字段
      if (this.updateSSinfo.snapshoot_name != "")
        this.designatedSS.snapshoot_name = this.updateSSinfo.snapshoot_name;
      if (this.updateSSinfo.snapshoot_describe != "")
        this.designatedSS.snapshoot_describe = this.updateSSinfo.snapshoot_describe;
      updateSS(this.designatedSS)
        .then((res) => {
          console.log(res);
          this.dialogVisible=false;
          this.$notify({
            title: "修改成功",
            message: "！",
            type: "success",
          });
        })
        .catch((err) => {
          console.log(err);
        });
    },
     /* 分页 */
    handleSizeChange: function(size) {
			this.pagesize = size;
			// console.log(this.pagesize) //每页下拉显示数据
		},
		handleCurrentChange: function(currentPage) {
			this.currentPage = currentPage;
			// console.log(this.currentPage) //点击第几页
		},

    //过滤器
    filterHandler(value, row, column) {
        const property = column['property'];
        return row[property] === value;
      },
     //控制过滤数据
    HandeleFilterChange(filters){
    //调用时重新将全部ss信息给newdata
     this.newData = [];
     for (let p = 0; p < this.tabledata.length; p++) {
              this.newData.push(this.tabledata[p])
     }
      this.selectdata[String(Object.keys(filters))] = filters[String(Object.keys(filters))]
      console.log("选择数组")
     console.log(this.selectdata);
      //循环遍历选择数组
      for (let j = 0; j < Object.keys(this.selectdata).length; j++) {
        //如果筛选条件只有一个
        if (this.selectdata[Object.keys(this.selectdata)[j]].length <= 1) {
          for (let k = 0; k < this.selectdata[Object.keys(this.selectdata)[j]].length; k++) {
            for (let i = 0; i < this.newData.length; i++) {
              if (this.selectdata[Object.keys(this.selectdata)[j]][k] !== this.newData[i][String(Object.keys(this.selectdata)[j])]) {
                this.newData.splice(i, 1)
                i--
              }
            }
          }
        } else {
          // 筛选条件有多个
          this.twoData = []
          for (let k = 0; k < this.selectdata[Object.keys(this.selectdata)[j]].length; k++) {
            for (let i = 0; i < this.newData.length; i++) {
              if (this.selectdata[Object.keys(this.selectdata)[j]][k] === this.newData[i][String(Object.keys(this.selectdata)[j])]) {
                this.twoData.push(this.newData[i])
              }
            }
          }
          if (this.twoData.length !== 0) {
            this.newData = []
            for (let io = 0; io < this.twoData.length; io++) {
              this.newData.push(this.twoData[io])
            }
          }
        }
      }
      console.log("###@@@$")
      console.log(this.newData)
      this.SS = this.newData
    },

    //路由跳转筛选
    routerFilterChange(selectdata){
       this.newData = [];
     for (let p = 0; p < this.tabledata.length; p++) {
              this.newData.push(this.tabledata[p])
     }
    console.log("原始数组")
    console.log(this.newData)
    console.log("选择数组")
    console.log(selectdata);
      //循环遍历选择数组
      for (let j = 0; j < Object.keys(selectdata).length; j++) {
        //如果筛选条件只有一个
        if (selectdata[Object.keys(selectdata)[j]].length <= 1) {
          for (let k = 0; k < selectdata[Object.keys(selectdata)[j]].length; k++) {
            console.log("选择数组长度")
            console.log(selectdata[Object.keys(selectdata)[j]].length)
            for (let i = 0; i < this.newData.length; i++) {
              if (selectdata[Object.keys(selectdata)[j]][k] !== this.newData[i][String(Object.keys(selectdata)[j])]) {
                this.newData.splice(i, 1)
                i--
              }
            }
          }
        } else {
          // 筛选条件有多个
          this.twoData = []
          for (let k = 0; k < selectdata[Object.keys(selectdata)[j]].length; k++) {
            for (let i = 0; i < this.newData.length; i++) {
              if (selectdata[Object.keys(selectdata)[j]][k] === this.newData[i][String(Object.keys(selectdata)[j])]) {
                this.twoData.push(this.newData[i])
              }
            }
          }
          if (this.twoData.length !== 0) {
            this.newData = []
            for (let io = 0; io < this.twoData.length; io++) {
              this.newData.push(this.twoData[io])
            }
          }
        }
      }
      console.log("筛选数据")
      console.log(this.newData)
      this.SS = this.newData
    }
    
    // onAddUser() {
    //   this.$refs.addFormRef.validate(async (valid) => {
    //     if (!valid) return null; // 如果验证失败就不往下继续执行
    //     const { data: res } = await this.$http.post("users", this.addUser);
    //     if (res.meta.status !== 201) return this.$message.error(res.meta.msg);
    //     this.$message.success("添加成功");
    //     this.dialogTableVisible = false; // 关闭弹框
    //     this.$refs.addFormRef.resetFields(); // 清空表单
    //     this.getUserList(); // 重新调用，刷新表单
    //   });
    },
  computed: {
  table_data() {
    let search = this.search;
    // 搜索功能
    if (search){
      let list =this.SS.filter(data => !search || data.snapshoot_user.toLowerCase().includes(search.toLowerCase())|| data.VM_name.toLowerCase().includes(search.toLowerCase()));
      let fenye = list.slice((this.currentPage-1)*this.pagesize,this.currentPage*this.pagesize);
      // 获取查询的结果，把数组长度赋值给 分页组件中的total
      this.total = fenye.length;
      return list,fenye
    }
    // 分页功能
   else {
     //所有数据的长度  赋值给分页组件中的total
      this.total = this.SS.length;                      
      let fenye = this.SS.slice((this.currentPage-1)*this.pagesize,this.currentPage*this.pagesize)
      return fenye
    }
  }
},
//路由跳转自动调用
  watch: {
   '$route': 'getSnapShoot'
 }
};
</script>

<style>
</style>