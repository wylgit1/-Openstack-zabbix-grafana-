<!-- ceshi1 -->
<template>
  <div></div>
</template>

<script>
export default {
  data () {
    return {
    };
  },

  components: {},

  computed: {},

  mounted () {
    this.getList()
  },

  methods: {
    // 获取仓库中所有的数据
    getList () {
      this.$http
        .get('https://gitee.com/api/v5/repos/guoshaosong/scripts/git/trees/master', {
          responseType: "json",
        })
        .then((res) => {
          console.log(res)
        })
        .catch((err) => {
          console.log(err);
        });
    },
  }
}

</script>
<style lang='less' scoped>
</style>