<template>
  <div>
    <el-alert title="提示:您可以在查看解决方案的日志以及执行结果"
              type="info"
              show-icon
              effect="dark"
              style="margin: 25px; padding: 12px;width:96%">
    </el-alert>
    <el-card style="margin: 25px;color:#fff;font-size:28px">
      <div slot="header">
        <div style="float:left;margin:5px 5px">
          <svg t="1636800133918"
               class="icon"
               viewBox="0 0 1024 1024"
               version="1.1"
               xmlns="http://www.w3.org/2000/svg"
               p-id="2555"
               width="30"
               height="30">
            <path d="M1022.976 558.976a463.808 463.808 0 0 1-463.872 463.872H464.896A463.808 463.808 0 0 1 1.024 558.976V464.96A463.872 463.872 0 0 1 464.896 1.088h94.208a463.936 463.936 0 0 1 463.872 463.872v94.016z"
                  fill="#66b1ff"
                  p-id="2556"></path>
            <path d="M728.32 165.12c52.224 0 101.696 40.832 103.616 90.496l0.064 3.072v198.656c-2.304 17.728-11.072 26.624-26.048 26.624-14.272 0-22.912-8-26.112-23.936l-0.512-2.752V259.84c0-22.336-25.088-41.6-48.64-42.88l-2.432-0.064h-439.68a43.072 43.072 0 0 0-43.84 39.424l-0.064 2.368v501.248c0 22.272 17.984 45.632 41.152 47.104l2.368 0.128h130.752c17.344 4.352 25.984 12.736 25.984 25.152 0 11.776-7.68 20.224-23.04 25.6l-2.944 0.96H288.192c-52.224 0-94.464-44.864-96.128-94.72L192 761.024V257.472c0-49.984 41.472-90.688 93.312-92.352H728.32z"
                  fill="#FFFFFF"
                  p-id="2557"></path>
            <path d="M466.432 591.872a26.112 26.112 0 0 1 26.496 25.728 26.048 26.048 0 0 1-26.112 25.984H378.624a26.112 26.112 0 0 1-26.56-25.6 26.112 26.112 0 0 1 26.112-26.112h88.256zM645.696 446.272a25.984 25.984 0 0 1 26.496 25.664 25.984 25.984 0 0 1-26.112 26.048H377.344a26.112 26.112 0 0 1-26.56-25.664 26.112 26.112 0 0 1 26.176-26.048h268.736zM609.6 285.504a26.176 26.176 0 0 1 26.56 25.728 26.24 26.24 0 0 1-26.176 26.112H376.448a26.176 26.176 0 0 1-26.496-25.728 26.112 26.112 0 0 1 26.112-26.112h233.536zM810.944 640.384c-1.92-10.88-15.808-14.72-23.616-7.104l-66.048 65.984a24.32 24.32 0 0 1-34.112 0l-33.92-33.984a23.872 23.872 0 0 1 0-33.984l66.56-66.24c7.808-7.744 4.032-21.632-6.72-23.616a123.328 123.328 0 0 0-110.912 33.792 121.856 121.856 0 0 0-30.912 122.624 19.264 19.264 0 0 1-4.224 19.392l-67.072 66.88a24.064 24.064 0 0 0 0 33.856l34.112 33.856a24.384 24.384 0 0 0 34.24 0l67.584-67.264a19.712 19.712 0 0 1 19.392-4.608 122.816 122.816 0 0 0 122.048-31.104 122.048 122.048 0 0 0 33.6-108.48z"
                  fill="#FFFFFF"
                  p-id="2558"></path>
          </svg>
        </div>
        <div>
          <el-button type="primary"
                     size="mini"
                     style="float:right;margin-top:10px;margin-right:5px"
                     @click="close()">暂停监听</el-button>
          <el-button type="primary"
                     size="mini"
                     style="float:right;margin-top:10px;margin-right:5px"
                     @click="init()">开始监听</el-button>

          <el-select v-model="value"
                     size="mini"
                     style="float:right;margin-right:15px"
                     placeholder="请选择您要查看的日志">
            <el-option v-for="item in options"
                       :key="item.value"
                       :label="item.label"
                       :value="item.value">
            </el-option>
          </el-select>
        </div>
      </div>
      <div class="content">
        {{mess}}
      </div>
    </el-card>
  </div>

</template>
 

<script>
export default {
  data () {
    return {
      path: "ws://192.168.48.10:8000/ws/tailf/",
      socket: "",
      value: '',
      mess: '',
      options: [{
        value: '1',
        label: '解决方案日志',
      },
      {
        value: '2',
        label: '系统运行日志',
      }

      ],
      websock: null,
    }
  },
  mounted () {

  },
  methods: {
    init: function () {
      if (typeof (WebSocket) === "undefined")
      {
        alert("您的浏览器不支持socket")
      } else
      {
        // 实例化socket
        if (this.value == 1 | this.value == 2)
        {
          console.log(this.value)
          this.socket = new WebSocket(this.path  + this.value + '/')
          // 监听socket连接
          this.socket.onopen = this.open
          console.log(this.socket.onopen)
          // 监听socket错误信息
          this.socket.onerror = this.error
          console.log(this.socket.onerror)
          // 监听socket消息
          this.socket.onmessage = this.getMessage
          console.log(this.socket.onmessage)

        }
        else
        {
          alert("请选择要查看的日志信息")
        }
      }
    },
    open: function () {
      console.log("socket连接成功")
    },
    error: function () {
      console.log("连接错误")
    },
    getMessage: function (msg) {
      console.log(msg.data)
      let tmp = JSON.parse(msg.data);
      this.mess = this.mess + tmp['message'] + '\n';
    },
    send: function () {
      this.socket.send("dsaf")
    },
    close: function () {
      this.socket.close()
      console.log("socket已经关闭")
    }
  },
  destroyed () {
    // 销毁监听
    this.socket.onclose = this.close
  }
}
</script>
<style scoped>
/deep/ .el-card__header {
  padding: 0px;
  height: 50px;
  line-height: 50px;
  background-color: #39383d;
  color: #fff;
}
/deep/ .el-card__body {
  padding: 0px;
}

.content {
  font-size: 14px;
  background-color: #1d1f21;
  border: 1px solid #f5f6f7;
  border-radius: 4px;
  padding: 10px;
  height: 600px;
  width: 100%;
  white-space: pre-wrap;
  color: yellow;
  overflow: scroll;
}
</style>