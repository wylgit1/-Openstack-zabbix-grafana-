<template>
  <div>
    <!-- <el-alert
      title="提示:"
      type="info"
      show-icon
      effect="dark"
      style="margin: 25px; padding: 12px; width: 96%"
    >
    </el-alert> -->

    <el-card style="margin: 25px; padding: 12px">
      <div slot="header">
        <div
          style="margin-left: 30px; width: 97%; height: 30px; line-height: 30px"
        >
          <el-button
            type="primary"
            size="mini"
            icon="el-icon-edit"
            plain
            style="float: left"
            @click="create()"
            >创建云盘</el-button
          >
          <el-dialog
            title="提示"
            :visible.sync="createdialogVisible"
            :before-close="handleClose"
          >
            <span>创建云盘</span>
            <el-form
              ref="createCVinfo"
              :rules="rulesUpdateVM"
              :model="createCVinfo"
              label-width="100px"
            >
              <el-form-item prop="cloud_volume_name" label="云盘名称">
                <el-input v-model="createCVinfo.cloud_volume_name"></el-input>
              </el-form-item>
              <el-form-item prop="cloud_volume_type" label="云盘类型">
                <el-input v-model="createCVinfo.cloud_volume_type"></el-input>
              </el-form-item>
              <el-form-item prop="cloud_volume_size" label="云盘大小">
                <el-input v-model="createCVinfo.cloud_volume_size"></el-input>
              </el-form-item>
              <el-form-item>
                <el-button @click="createdialogVisible = false">取消</el-button>
                <el-button type="primary" @click="createCloudVolume()"
                  >确定</el-button
                >
              </el-form-item>
            </el-form>
            <!-- <span slot="footer" class="dialog-footer">
                <el-button @click="dialogVisible = false">取 消</el-button>
                <el-button type="primary" @click="dialogVisible = false"
                  >确 定</el-button
                >
              </span> -->
          </el-dialog>
        </div>
      </div>
           <el-table :data="table_data"
           @filter-change="HandeleFilterChange"
         ref="filterTable"  style="width: 100%">
        <el-table-column prop="cloud_volume_id" label="云盘id"> </el-table-column>
        <el-table-column 
        prop="cloud_volume_name" 
        label="云盘名字"
        column-key="cloud_volume_name"
        :filters="vmnames"
        :filter-method="filterHandler"> </el-table-column>
        <el-table-column 
        prop="cloud_volume_type" 
        label="云盘类型"
        >
        </el-table-column>
        <el-table-column prop="cloud_volume_size" label="云盘大小/G">
        </el-table-column>
        <el-table-column prop="VM_name" label="连接到">
        </el-table-column>
        <el-table-column prop="cloud_volume_status" label="状态">
        </el-table-column>
        <!-- <el-table-column
          prop="snapshoot_user"
          label="快照用户"
          column-key="snapshoot_user"
          :filters="usernames"
          :filter-method="filterHandler"
        ></el-table-column> -->
        <!-- <el-table-column align="center"
                         width="100">
          <template slot="header">
            <el-input v-model="search"
                      size="mini"
                      placeholder="输入关键字搜索" />
          </template>
                  </el-table-column> -->

        <el-table-column label="操作">
          <template slot-scope="scope">
            <el-dropdown split-button type="primary">
              更多菜单
              <el-dropdown-menu slot="dropdown">
                <el-dropdown-item @click.native="getallocate(scope.$index, scope.row)">连接主机</el-dropdown-item>
                <el-dropdown-item @click.native="separate(scope.$index, scope.row)">分离主机</el-dropdown-item>             
                <el-dropdown-item @click.native="getupdate(scope.$index, scope.row)">修改云盘</el-dropdown-item>
                <el-dropdown-item @click.native="deleteCloudVolume(scope.$index, scope.row)">删除云盘</el-dropdown-item>
              </el-dropdown-menu>
            </el-dropdown>
            <!-- <el-button size="mini" @click="update(scope.$index, scope.row)" type="primary"
              >修改信息</el-button
            > -->
            <el-dialog
              title="提示"
              :visible.sync="allocateDialogVisible"
              :before-close="handleClose"
            >
              <span>请选择分配的主机名称</span>
              <el-form
                ref="updateCVinfo"
                :rules="rulesUpdateVM"
                :model="updateCVinfo"
                label-width="100px"
              >
                <el-form-item prop="VM_name" label="主机名">
                <el-select
                  class="VM_name"
                  v-model="updateCVinfo.VM_name"
                  placeholder="VM_name"
                >
                  <el-option
                    v-for="(key, value, index) in VM_names"
                    :key="index"
                    :label="key['VM_name']"
                    :value="key['VM_name']"
                  >
                  </el-option>
                </el-select>
              </el-form-item>
                <el-form-item>
                  <el-button @click="allocateDialogVisible = false">取消</el-button>
                  <el-button type="primary" @click="allocate()"
                    >确定</el-button
                  >
                </el-form-item>
              </el-form>
              <!-- <span slot="footer" class="dialog-footer">
                <el-button @click="dialogVisible = false">取 消</el-button>
                <el-button type="primary" @click="dialogVisible = false"
                  >确 定</el-button
                >
              </span> -->
            </el-dialog>
            <el-dialog
              title="提示"
              :visible.sync="updateDialogVisible"
              :before-close="handleClose"
            >
              <span>请输入需要修改的信息</span>
              <el-form
                ref="updateCVinfo"
                :rules="rulesUpdateVM"
                :model="updateCVinfo"
                label-width="100px"
              >
                <el-form-item prop="cloud_volume_name" label="云盘名称">
                <el-input v-model="updateCVinfo.cloud_volume_name"></el-input>
              </el-form-item>
                <el-form-item>
                  <el-button @click="allocateDialogVisible = false">取消</el-button>
                  <el-button type="primary" @click="updateCloudVolume()"
                    >确定</el-button
                  >
                </el-form-item>
              </el-form>
              <!-- <span slot="footer" class="dialog-footer">
                <el-button @click="dialogVisible = false">取 消</el-button>
                <el-button type="primary" @click="dialogVisible = false"
                  >确 定</el-button
                >
              </span> -->
            </el-dialog>
            <!-- <el-button
              size="mini"
              @click="restoreSnapShoot(scope.$index, scope.row)"
              type="primary"
              >恢复快照</el-button
            > -->
            <!-- &nbsp;&nbsp;<el-button
              size="mini"
              @click="deleteSnapShoot(scope.$index, scope.row)"
              type="danger"
              >删除快照</el-button
            > -->
          </template>
        </el-table-column>
      </el-table>
      <el-pagination :current-page="param.currentPage"
                     :page-sizes="[5, 10, 15, 20]"
                     :page-size="param.pagesize"
                     layout="total, sizes,prev, pager, next, jumper"
                     :total="parseInt(total)"
                     @size-change="handleSizeChange"
                     @current-change="handleCurrentChange" />
    </el-card>
  </div>
</template>

<script>
import cons from "@/components/constant";
import {  createVM } from "@/api/vm";
import {  createCV,getCV,updateCV,allocateVM,separateVM,deleteCV } from "@/api/cloud_volume";
import {  getVMname,getVM,deleteVM} from "@/api/vmManagement";
import { getMsg } from "@/api/vm_info";
import { getSS, createSS, deleteSS,updateSS,getappointedSS } from "@/api/snapshoot";
import { getUsername } from "@/api/user";

export default {
  data() {
    return {

      //存放所有快照信息用以显示
      CV: [],
      tabledata:[],
      // 存放创建云盘提交的信息
      createCVinfo: {
        cloud_volume_id:" ",
        VM_id:" ",
        VM_name:" "
      },
      // 存放创建时需要显示的所有用户名字
      users: [],
      // 存放创建时需要显示的所有虚拟机名字
      VM_names: [],
      // 修改所需信息
      temp: "", //存放修改时所选的vmid
      tag:"",//存放选择标签
      designatedCV: [], //存放修改时选定的快照信息
      // 控制创建时的dialog的显示
      createdialogVisible: false,
      allocateDialogVisible: false, //修改时dialog显示
      updateDialogVisible: false, //修改时dialog显示
      floatingIp: [], //存放修改时浮动ip可选信息
      flavor: [], //存放修改时flavor可选信息
      // 修改快照时所提交的信息
      updateCVinfo: {
        VM_name:"",
        snapshoot_name: "",
        snapshoot_describe: "",
      }, 
      //恢复快照时指定的快照信息
      appointedSS:{},
      appointedVM:{

      },
      VMlist:[],
      createForm: {
        VM_id:"",
        VM_name: "",
        nickname: "",
        // number: "",
        ip: "",
        // rent_time: null,
        flavor: "",
        image: "",
        image_type: "",
        client_mac: "1",
        floating_ip: "",
        VM_security_group: "",
        sign: "1",
        status: "static",
      },

      //过滤器查询用
      vmnames:[],
      usernames:[],
      selectdata: {VM_name: [], snapshoot_user: []},
      newData: [],
      twoData: [],
      data: [],
      listdata: '',

      /* 分页所需数据*/
      value: '100',
      param: {
        currentPage: 1, // 当前页
        pagesize: 5, // 默认每页多少张
      },
      total: 0, // 共多少页
      join: null,
      currentIndex: '',
			currentPage: 1, //初始页
			pagesize: 5, //    每页的数据

      // 验证规则
      rulesUpdateVM: {
        // username: [
        //   { required: true, message: '请输入用户名', trigger: 'blur' }
        // ],
        // password: [
        //   { required: true, message: '请输入用户密码', trigger: 'blur' }
        // ],
        // email: [
        //   { required: true, message: '请输入邮箱', trigger: 'blur' },
        //   {(
        //     type: 'email',
        //     message: '请输入正确的邮箱地址',
        //     trigger: ['blur', 'change']
        //   }
        // ],
      },
    };
  },
  mounted() {
    this.getVMnames(); //得到创建时需要显示的所有虚拟机名字
    this.fetchData(); // 得到修改所需数据
    this.getUsernames();// 得到创建时需要显示的所有用户名字
    this.getCloudVolume();// 得到所有云盘信息展示在页面
    this.getVMMessage();
    // let VM_name = this.$router.params.VM_name;
    // if(VM_name){
    //     console.log("vmname######");
    //     console.log(VM_name);
    //     this.selectdata['nickname'][0]=VM_name;
    //     this.HandeleFilterChange();
    //     // let id = this.$router.params.userId;
    // // if(id){

    // // }
    // }
  },
  methods: {
    //得到路由跳转传过来参数后修改选择数组进行筛选
    getParams(VM_name){
      console.log("##取到路由带过来的参数@@")
      console.log(VM_name);
      console.log(this.selectdata['VM_name']);
	    this.selectdata['VM_name'][0]=VM_name;   // 将数据放在当前组件的数据内
	    this.routerFilterChange(this.selectdata);

    },
    //得到创建时需要显示的所有虚拟机名字
    getVMnames() {
      // let _this = this
      getVMname()
        .then((res) => {
          this.VM_names = res.data;
          console.log("##@@")
          console.log(this.VM_names[0]);
          this.vmnames=res.data;
          console.log(this.vmnames)
          for (let index = 0; index < res.data.length; index++) {
            this.vmnames[index].text = res.data[index].VM_name;
            this.vmnames[index].value = res.data[index].VM_name;
          }
          console.log(this.vmnames)
        })
        .catch((err) => {
          console.log(err);
        });
    },
    // 得到创建时需要显示的所有用户名字
    getUsernames() {
      getUsername()
        .then((res) => {
          this.users = res.data;
          this.usernames=res.data;
          for (let index = 0; index < res.data.length; index++) {
            this.usernames[index].text = res.data[index].username;
            this.usernames[index].value = res.data[index].username;
          }
          console.log(this.usernames)
          console.log(this.users);
        })
        .catch((err) => {
          console.log(err);
        });
    },

    //得到所有快照信息展示在页面
    getCloudVolume() {
      getCV()
        .then((res) => {
          this.CV = res.data;
        })
        .catch((err) => {
          console.log(err);
        });
    },

    // 创建 弹出创建快照的dialog
    create() {
      this.createdialogVisible = true;
    },

    //真正进行创建云盘
    createCloudVolume() {
      console.log("###@#@$$$$");
      console.log(this.createCVinfo);
      let $this=this
      let loading = this.$loading({
        lock:true,
        text:"创建中，请稍候...",
        background:'rgba(0,0,0,0.5)'
      })
      createCV(this.createCVinfo)
        .then((res) => {
          console.log(res);
          loading.close()
          this.createdialogVisible = false;
          this.$notify({
            title: "创建成功",
            message: "！",
            type: "success",
          });
          this.getCloudVolume()
        })
        .catch((err) => {
          console.log(err);
        });
    },

    // 删除快照
    deleteCloudVolume(index, row) {
       let $this=this
      let loading = this.$loading({
        lock:true,
        text:"删除中，请稍候...",
        background:'rgba(0,0,0,0.5)'
      })
      deleteCV(row)
        .then((res) => {
          loading.close();
          this.getCloudVolume();
          this.$notify({
            title: "删除成功",
            message: "！",
            type: "success",
          });
        })
        .catch((err) => {
          console.log(err);
        });
    },

    /* 恢复快照*/
    //得到需要恢复的快照信息
     restoreSnapShoot(index,row){
      getappointedSS(row)
          .then((res) => {
            console.log("指定快照信息")
            console.log(res.data);
            this.appointedSS=res.data;
             this.getappointedVM(res.data.VM_id);
          })
          .catch((err) => {
            console.log(err);
          });
    },
    //获得主机列表全部信息
    getVMMessage() {
      getVM()
        .then((res) => {
          this.VMlist = res.data;
          console.log(this.VMlist);
        })
        .catch((err) => {
          console.log(err);
        });
    },
    destroyVM(data){
      deleteVM(data)
        .then((res) => {
          loading.close()         
        })
        .catch((err) => {
          console.log(err);
        });
    },

    // 得到修改所需数据
    fetchData() {
      getMsg()
        .then((res) => {
          console.log(res);
          this.flavor = res["flavor"];
          this.keys = res["key"];
          this.securityGroup = res["security_group"];
          this.network = res["network"];
          this.image = res["host_image"];
          this.floatingIp = res["floating_ip"];
        })
        .catch((err) => {
          this.init = false;
          this.err = true;
        });
    },

    //控制关闭dialog
    handleClose(done) {
      this.$confirm("确定关闭吗")
        .then(() => {
          // function(done)，done 用于关闭 Dialog
          done();

          console.info("点击右上角 'X' ，取消按钮或遮罩层时触发");
        })
        .catch(() => {
          console.log("点击确定时触发");
        });
    },

    /**                        连接                       */
    //  弹出连接主机dialog
    getallocate(index, row) {
      this.allocateDialogVisible = true;
      console.log(row.id);
      // 存放当前行修改的快照id
      this.temp = row.id;
    },
    allocate(){
      let $this=this
      let loading = this.$loading({
        lock:true,
        text:"连接中，请稍候...",
        background:'rgba(0,0,0,0.5)'
      })
      // this.allocateDialogVisible = true;
      console.log(this.temp);
      // 存放当前行修改的快照id
      // 循环遍历CV找到修改指定的CV信息
      for (let index = 0; index < this.CV.length; index++) {
        if (this.CV[index].id == this.temp) {
          this.designatedCV = this.CV[index];
        }
      }
      if (this.updateCVinfo.VM_name != "")
        this.designatedCV.VM_name = this.updateCVinfo.VM_name;
      console.log(this.designatedCV);
      allocateVM(this.designatedCV)
        .then((res) => {
          console.log(res);
          // this.allocateDialogVisible=false;
          this.updateEdit(res)
          loading.close()
          this.$notify({
            title: "分配成功",
            message: "！",
            type: "success",
          });
        })
        .catch((err) => {
          console.log(err);
        });
    },


    /**                        分离                       */
    //分离主机 弹出确认dialog
    separate(index, row) {
      let $this=this
      let loading = this.$loading({
        lock:true,
        text:"分离中，请稍候...",
        background:'rgba(0,0,0,0.5)'
      })
      // this.allocateDialogVisible = true;
      console.log(row.id);
      // 循环遍历CV找到修改指定的CV信息
      for (let index = 0; index < this.CV.length; index++) {
        if (this.CV[index].id == row.id) {
          this.designatedCV = this.CV[index];
        }
      }
      console.log(this.designatedCV);
      separateVM(this.designatedCV)
        .then((res) => {
          console.log(res);
          loading.close();
          // this.allocateDialogVisible=false;
          this.updateEdit(res)
          this.$notify({
            title: "分离成功",
            message: "！",
            type: "success",
          });
        })
        .catch((err) => {
          console.log(err);
        });
    },

    /**                        修改                       */
    //弹出修改dialog
    getupdate(index, row) {
      this.updateDialogVisible = true;
      console.log(row.id);
      // 存放当前行修改的快照id
      this.temp = row.id;
    },
    //修改云盘信息
    updateCloudVolume(){
      let $this=this
      let loading = this.$loading({
        lock:true,
        text:"修改中，请稍候...",
        background:'rgba(0,0,0,0.5)'
      })
      // 循环遍历CV找到修改指定的CV信息
      for (let index = 0; index < this.CV.length; index++) {
        if (this.CV[index].id == this.temp) {
          this.designatedCV = this.CV[index];
        }
      }
      console.log(this.designatedCV);
      // 修改云盘名字
      if (this.updateCVinfo.cloud_volume_name != "")
        this.designatedCV.cloud_volume_name = this.updateCVinfo.cloud_volume_name;
      updateCV(this.designatedCV)
        .then((res) => {
          console.log(res);
          loading.close();
          this.updateDialogVisible=false;
          this.$notify({
            title: "修改成功",
            message: "！",
            type: "success",
          });
          this.getCloudVolume();
        })
        .catch((err) => {
          console.log(err);
        });
    },

    // 所有操作后进行的修改云盘信息
     updateEdit(data) {
      updateCV(data)
        .then((res) => {
          console.log(res);
          this.allocateDialogVisible=false;
          this.updateDialogVisible=false;
          this.getCloudVolume();
        })
        .catch((err) => {
          console.log(err);
        });
    },
     /* 分页 */
    handleSizeChange: function(size) {
			this.pagesize = size;
			// console.log(this.pagesize) //每页下拉显示数据
		},
		handleCurrentChange: function(currentPage) {
			this.currentPage = currentPage;
			// console.log(this.currentPage) //点击第几页
		},

    //过滤器
    filterHandler(value, row, column) {
        const property = column['property'];
        return row[property] === value;
      },
     //控制过滤数据
    HandeleFilterChange(filters){
    //调用时重新将全部ss信息给newdata
     this.newData = [];
     for (let p = 0; p < this.tabledata.length; p++) {
              this.newData.push(this.tabledata[p])
     }
      this.selectdata[String(Object.keys(filters))] = filters[String(Object.keys(filters))]
      console.log("选择数组")
     console.log(this.selectdata);
      //循环遍历选择数组
      for (let j = 0; j < Object.keys(this.selectdata).length; j++) {
        //如果筛选条件只有一个
        if (this.selectdata[Object.keys(this.selectdata)[j]].length <= 1) {
          for (let k = 0; k < this.selectdata[Object.keys(this.selectdata)[j]].length; k++) {
            for (let i = 0; i < this.newData.length; i++) {
              if (this.selectdata[Object.keys(this.selectdata)[j]][k] !== this.newData[i][String(Object.keys(this.selectdata)[j])]) {
                this.newData.splice(i, 1)
                i--
              }
            }
          }
        } else {
          // 筛选条件有多个
          this.twoData = []
          for (let k = 0; k < this.selectdata[Object.keys(this.selectdata)[j]].length; k++) {
            for (let i = 0; i < this.newData.length; i++) {
              if (this.selectdata[Object.keys(this.selectdata)[j]][k] === this.newData[i][String(Object.keys(this.selectdata)[j])]) {
                this.twoData.push(this.newData[i])
              }
            }
          }
          if (this.twoData.length !== 0) {
            this.newData = []
            for (let io = 0; io < this.twoData.length; io++) {
              this.newData.push(this.twoData[io])
            }
          }
        }
      }
      console.log("###@@@$")
      console.log(this.newData)
      this.SS = this.newData
    },
    //路由跳转筛选
    routerFilterChange(selectdata){
       this.newData = [];
     for (let p = 0; p < this.tabledata.length; p++) {
              this.newData.push(this.tabledata[p])
     }
    console.log("原始数组")
    console.log(this.newData)
    console.log("选择数组")
    console.log(selectdata);
      //循环遍历选择数组
      for (let j = 0; j < Object.keys(selectdata).length; j++) {
        //如果筛选条件只有一个
        if (selectdata[Object.keys(selectdata)[j]].length <= 1) {
          for (let k = 0; k < selectdata[Object.keys(selectdata)[j]].length; k++) {
            console.log("选择数组长度")
            console.log(selectdata[Object.keys(selectdata)[j]].length)
            for (let i = 0; i < this.newData.length; i++) {
              if (selectdata[Object.keys(selectdata)[j]][k] !== this.newData[i][String(Object.keys(selectdata)[j])]) {
                this.newData.splice(i, 1)
                i--
              }
            }
          }
        } else {
          // 筛选条件有多个
          this.twoData = []
          for (let k = 0; k < selectdata[Object.keys(selectdata)[j]].length; k++) {
            for (let i = 0; i < this.newData.length; i++) {
              if (selectdata[Object.keys(selectdata)[j]][k] === this.newData[i][String(Object.keys(selectdata)[j])]) {
                this.twoData.push(this.newData[i])
              }
            }
          }
          if (this.twoData.length !== 0) {
            this.newData = []
            for (let io = 0; io < this.twoData.length; io++) {
              this.newData.push(this.twoData[io])
            }
          }
        }
      }
      console.log("筛选数据")
      console.log(this.newData)
      this.SS = this.newData
    }
    
    // onAddUser() {
    //   this.$refs.addFormRef.validate(async (valid) => {
    //     if (!valid) return null; // 如果验证失败就不往下继续执行
    //     const { data: res } = await this.$http.post("users", this.addUser);
    //     if (res.meta.status !== 201) return this.$message.error(res.meta.msg);
    //     this.$message.success("添加成功");
    //     this.dialogTableVisible = false; // 关闭弹框
    //     this.$refs.addFormRef.resetFields(); // 清空表单
    //     this.getUserList(); // 重新调用，刷新表单
    //   });
    },
    computed: {
  table_data() {
    let search = this.search;
    // 搜索功能
    if (search){
      let list =this.CV.filter(data => !search || data.cloud_volume_name.toLowerCase().includes(search.toLowerCase())|| data.VM_name.toLowerCase().includes(search.toLowerCase()));
      let fenye = list.slice((this.currentPage-1)*this.pagesize,this.currentPage*this.pagesize);
      // 获取查询的结果，把数组长度赋值给 分页组件中的total
      this.total = fenye.length;
      return list,fenye
    }
    // 分页功能
   else {
     //所有数据的长度  赋值给分页组件中的total
      this.total = this.CV.length;                      
      let fenye = this.CV.slice((this.currentPage-1)*this.pagesize,this.currentPage*this.pagesize)
      return fenye
    }
  }
},
//路由跳转自动调用
  watch: {
   '$route': 'getSnapShoot'
 }
};
</script>

<style>
</style>