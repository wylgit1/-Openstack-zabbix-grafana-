<template>
  <el-card style="margin: 25px; padding: 12px">
    <el-table :data="users" style="width: 100%">
      <el-table-column prop="username" label="账号" width="180">
      </el-table-column>
      <el-table-column prop="email" label="邮箱" width="180"> </el-table-column>
      <el-table-column prop="type" label="类型"> </el-table-column>
      <el-table-column
        prop="last_login"
        label="上次登录时间"
        :formatter="formatDate"
      >
      </el-table-column>
      <el-table-column prop="lastLoginBox" label="上次登录云盒子">
      </el-table-column>
      <el-table-column label="操作">
        <template slot-scope="scope">
          <el-button size="mini" @click="update(scope.$index, scope.row)"
            >修改</el-button
          >
          <el-dialog
            title="提示"
            :visible.sync="dialogVisible"
            :before-close="handleClose"
          >
            <span>请输入需要修改的信息</span>
            <el-form
              ref="updateUserinfo"
              :model="updateUserinfo"
              label-width="100px"
            >
              <el-form-item prop="type" label="用户类型">
              <el-select v-model="updateUserinfo.type" placeholder="请选择">
                  <el-option
                    v-for="item in userstype"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value">
                  </el-option>
                </el-select>
                </el-form-item>
              <el-form-item>
                <el-button @click="dialogVisible = false">取消</el-button>
                <el-button type="primary" @click="updateEdit()">确定</el-button>
              </el-form-item>
            </el-form>
            <!-- <span slot="footer" class="dialog-footer">
                <el-button @click="dialogVisible = false">取 消</el-button>
                <el-button type="primary" @click="dialogVisible = false"
                  >确 定</el-button
                >
              </span> -->
          </el-dialog>
        </template>
      </el-table-column>
    </el-table>
  </el-card>
</template>
<script>
import cons from "@/components/constant";
import { getUserMsg,updateUser } from "@/api/user";
export default {
  data() {
    return {
      // 存放修改时选中的当前用户的信息
      designatedUser:{
        type:'',
      },
      // 存放所有用户信息
      users: [
        { name: "", email: "", type: "", last_login: "", lastLoginBox: null },
      ],
      // 存放修改时提交的用户信息
      updateUserinfo: {
        type: "",
      },
      // 用户类型字典
      userstype:[{
          value: 0,
          label: 'admin'
      },{
          value: 1,
          label: 'teacher'
      },{
          value: 2,
          label: 'student'
      },{
          value: 3,
          label: 'general user'
      }
      ],
      // 控制dialog显示
      dialogVisible:false,
    };
  },
  mounted() {
    this.getUserMessage();
  },
  methods: {
    // 得到所有用户信息
    getUserMessage() {
      getUserMsg()
        .then((res) => {
          this.users = res.data;
          this.judgeType(this.users)
          console.log(this.users);
        })
        .catch((err) => {
          console.log(err);
        });
    },
    //修改 弹出修改dialog
    update(index,row) {
      this.dialogVisible = true;
      console.log(row.id);
      this.temp = row.id;
    },
    // 真正修改用户信息
      updateEdit() {
      // 循环遍历用户信息找到修改指定的当前用户所有信息
      for (let index = 0; index < this.users.length; index++) {
        if (this.users[index].id == this.temp) {
          this.designatedUser = this.users[index];
        }
      }
      console.log(this.designatedUser);
      // 判断需要修改的字段
      if (this.updateUserinfo.type != null)
        this.designatedUser.type = this.updateUserinfo.type;
            
      console.log("修改后的类型")
      console.log(this.designatedUser);
      updateUser(this.designatedUser)
        .then((res) => {
          console.log(res);
          this.dialogVisible=false;
          this.$notify({
            title: "修改成功",
            message: "！",
            type: "success",
          });
          this.getUserMessage()
        })
        .catch((err) => {
          console.log(err);
        });
    },
    // 判断用户类型
    judgeType(users) {
      for (let index = 0; index < users.length; index++) {
        const element = users[index];
        if (users[index].type == 0) {
          users[index].type = "admin";
        } else if (users[index].type == 1) {
          users[index].type = "teacher";
        } else if (users[index].type == 2) {
          users[index].type = "student ";
        } else if (users[index].type == 3) {
          users[index].type = "general user";
        } 
      }
    },
    // 设置时间格式
    formatDate(row, column) {
      // 获取单元格数据
      let data = row[column.property];
      if (data == null) {
        return null;
      }
      let dt = new Date(data);
      return (
        dt.getFullYear() +
        "-" +
        (dt.getMonth() + 1) +
        "-" +
        dt.getDate() +
        " " +
        dt.getHours() +
        ":" +
        dt.getMinutes() +
        ":" +
        dt.getSeconds()
      );
    },
    
    //控制关闭dialog
    handleClose(done) {
      this.$confirm("确定关闭吗")
        .then(() => {
          // function(done)，done 用于关闭 Dialog
          done();

          console.info("点击右上角 'X' ，取消按钮或遮罩层时触发");
        })
        .catch(() => {
          console.log("点击确定时触发");
        });
    },
  },
};
</script>

<style>
</style>