<!-- 个人中心页面 -->
<template>
  <div>
    <div v-show="init">
      <el-card style="margin: 25px; padding: 12px">
        <el-tabs v-model="activeName" type="card">
          <!-- <el-tab-pane label="Create云主机" name="first" style="margin: 40px"> -->
          <h3>Create云主机</h3>
          <el-form
            ref="$createForm"
            :model="createForm"
            label-position="left"
            label-width="100px"
            size="small"
          >
            <h4>基础详情</h4>
            <el-button
            type="primary"
            size="mini"
            icon="el-icon-edit"
            plain
            style="float: left"
             @click=jumptovm()
            >上传脚本</el-button
          >
            <el-form-item prop="VM_name" label="云主机名字">
              <el-input
                v-model="createForm.VM_name"
                clearable
                prefix-icon="el-icon-edit"
                style="width: 50%"
                placeholder="VM' NAME"
              ></el-input>
            </el-form-item>
            <!-- <el-form-item prop="number" label="云主机数量">
              <el-input
                v-model="createForm.number"
                placeholder="NUMBER"
                clearable
                prefix-icon="el-icon-edit"
                style="width: 50%"
              ></el-input>
            </el-form-item> -->
            <el-form-item prop="rent_time" label="租期">
              <el-input
                v-model="createForm.rent_time"
                placeholder="TENANCY"
                clearable
                prefix-icon="el-icon-edit"
                style="width: 50%"
              ></el-input>
            </el-form-item>
            <el-form-item label="云主机flavor">
              <el-select
                class="flavor"
                v-model="createForm.flavor"
                placeholder="flavor"
              >
                <el-option
                  v-for="(key, value, index) in flavor"
                  :key="index"
                  :label="key + ''"
                  :value="key"
                >
                </el-option>
              </el-select>
            </el-form-item>
            <el-form-item label="云主机image">
              <el-select
                class="image"
                v-model="createForm.image"
                placeholder="image"
              >
                <el-option
                  v-for="(key, value, index) in image"
                  :key="index"
                  :label="key + ''"
                  :value="key"
                >
                </el-option>
              </el-select>
            </el-form-item>
            <el-form-item label="云主机系统类型">
              <el-select
                class="image_type"
                v-model="createForm.image_type"
                placeholder="image_type"
              >
                <el-option
                  v-for="item in type"
                  :key="item.index"
                  :label="item.value"
                  :value="item.value"
                >
                </el-option>
              </el-select>
            </el-form-item>
            <!-- <el-form-item prop="client_mac" label="请输入你的client_mac">
              <el-input
                v-model="createForm.client_mac"
                clearable
                prefix-icon="el-icon-edit"
                style="width: 50%"
                placeholder="NUMBER"
              ></el-input>
            </el-form-item> -->
            <el-form-item prop="key" label="云主机key">
              <el-select class="key" v-model="createForm.key" placeholder="key">
                <el-option
                  v-for="(key, value, index) in keys"
                  :key="index"
                  :label="key + ''"
                  :value="key"
                >
                </el-option>
              </el-select>
            </el-form-item>

            <el-form-item prop="network" label="云主机network">
              <el-select
                class="network"
                v-model="createForm.ip"
                placeholder="network"
              >
                <el-option
                  v-for="(key, value, index) in network"
                  :key="index"
                  :label="key + ''"
                  :value="key"
                >
                </el-option>
              </el-select>
            </el-form-item>

            <el-form-item label="云主机floating_ip">
              <el-select
                class="floating_ip"
                v-model="createForm.floating_ip"
                placeholder="floating_ip"
              >
                <el-option
                  v-for="(key, value, index) in floatingIp"
                  :key="index"
                  :label="key + ''"
                  :value="key"
                >
                </el-option>
              </el-select>
            </el-form-item>
            <el-form-item label="安全组security_group">
              <el-select
                class="security_group"
                v-model="createForm.VM_security_group"
                placeholder="security_group"
              >
                <el-option
                  v-for="(key, value, index) in securityGroup"
                  :key="index"
                  :label="key + ''"
                  :value="key + ''"
                >
                </el-option>
              </el-select>
            </el-form-item>

            <el-row
              :gutter="20"
              type="flex"
              justify="start"
              align="top"
              tag="div"
            >
              <el-col :span="6" :offset="0" :push="0" :pull="0" tag="div">
                <el-button
                  size="small"
                  type="primary"
                  icon="el-icon-check"
                  @click="submit"
                  >提 交</el-button
                >
              </el-col>
              <el-col :span="6" :offset="0" :push="0" :pull="0" tag="div">
                <el-button
                  size="small"
                  icon="el-icon-refresh-left"
                  @click="forms.forEach((createForm) => $refs[createForm].resetFields())"
                  >重 置</el-button
                >
              </el-col>
            </el-row>
          </el-form>
          <!-- </el-tab-pane> -->
        </el-tabs>
      </el-card>
    </div>
    <div v-show="err">
      <el-card style="margin: 25px; padding: 12px; text-align: center">
        <el-image
          src="https://img95.699pic.com/photo/40025/1806.jpg_wh300.jpg"
        ></el-image>
      </el-card>
    </div>
  </div>
</template>


<script>
import { getMsg } from "@/api/vm_info";
import { createVM } from "@/api/vm";
import { recordSG } from "@/api/security_group"
export default {
  data() {
    return {
      init: true,
      err: false,
      //表单
      forms: ["$createForm"],
      //存放创建的虚拟机的信息
      createForm: {
        VM_id:"",
        VM_name: "",
        nickname: "",
        // number: "",
        ip: "",
        // rent_time: null,
        flavor: "",
        image: "",
        image_type: "",
        client_mac: "1",
        floating_ip: "",
        VM_security_group: "",
        sign: "1",
        status: "static",
      },
      //
      activeName: "first",
      //存放创建虚拟机时显示所需数据
      image: [],
      floatingIp: [],
      flavor: [],
      keys: [],
      network: [],
      securityGroup: [],
      //记录创建虚拟机时存入安全组的相关信息
      recordSG:{
        security_group_id:"null",
        VM_id:"null",
        VM_name:" ",
        security_group_name:"",
        security_group_type:"null",
      },
      //云主机系统类型
      type: [
        {
          label: "name1",
          value: "linux",
        },
        {
          label: "name2",
          value: "windows",
        },
      ],
    };
  },
  mounted() {
    //获得创建主机前端显示所需数据
    this.fetchData();
  },
  methods: {
    // 创建主机
    // submit() {
    //   var data = JSON.parse(window.sessionStorage.getItem("data"));
    //   console.log(data);
    //   this.createForm.nickname = data.username;
    //   // this.createForm.sign = data.is_superuser;
    //   this.$http
    //     .post(cons.apis + "/virtual_machines/", this.createForm, {
    //       responseType: "json",
    //     })
    //     .then((res) => {
    //       if (res.status == 200) {
    //         this.$message("创建成功");
    //         console.log(res.data);
    //         this.tableData = res.data;
    //       }
    //     })
    //     .catch((err) => {
    //       console.log(err);
    //     });
    // },
    jumptovm(){
        this.$router.push({
          path:"/vmManagement",});
    },
    //创建主机 
    submit() {
      let $this=this
      let loading = this.$loading({
        lock:true,
        text:"提交中，请稍候...",
        background:'rgba(0,0,0,0.5)'
      })
      var data = JSON.parse(window.sessionStorage.getItem("data"));
      console.log(data);
      this.createForm.nickname = data.username;
      console.log(this.createForm);
      createVM(this.createForm).then(res => {
        console.log(res)
        loading.close()
        //前端提示提交成功
         this.$notify({
          title: '创建成功',
          message: '！',
          type: 'success'
        });
        this.$router.push("/basic/vmManagement");
        this.recordSecurityGroup(this.createForm);
      }).catch(err =>{
        console.log(err)
      });
    },
    // 获得创建主机前端显示所需数据
    fetchData() {
      getMsg().then((res) => {    
            console.log("返回数据")
            console.log(res);
            this.flavor = res["flavor"];
            this.keys = res["key"];
            this.securityGroup = res["security_group"];
            this.network = res["network"];
            this.image = res["host_image"];
            this.floatingIp = res["floating_ip"];
          }
        )
        .catch((err) => {
          this.init = false;
          this.err = true;
        });
    
    },
    // 记录创建虚拟机时存入安全组的相关信息
    recordSecurityGroup(createData){
        this.recordSG.VM_id=createData.VM_id;
        this.recordSG.VM_name=createData.VM_name;
        this.recordSG.security_group_name=createData.VM_security_group;
        recordSG(this.recordSG).then(res => {
          console.log(res)
        }).catch(err =>{
          console.log(err)
        });
       }
    // getMsg() {
    //   this.$http
    //     .get(cons.apis + "/vminfo/", {
    //       responseType: "json",
    //     })
    //     .then((res) => {
    //       if (res.data["code"] == 200) {
    //         this.msg = res.data;
    //         console.log(this.msg);
    //         this.flavor = this.msg["flavor"];
    //         this.keys = this.msg["key"];
    //         this.securityGroup = this.msg["security_group"];
    //         this.network = this.msg["network"];
    //         this.image = this.msg["host_image"];
    //         this.floatingIp = this.msg["floating_ip"];
    //         console.log(this.flavor);
    //       }
    //     })
    //     .catch((err) => {
    //       console.log(err);
    //       this.init = false;
    //       this.err = true;
    //     });
    // },
  },
};
</script>

<style>
.demo-table-expand {
  font-size: 0;
}
.demo-table-expand label {
  width: 140px;
  color: #99a9bf;
}
.demo-table-expand .el-form-item {
  margin-right: 0;
  margin-bottom: 0;
  width: 50%;
}
</style>