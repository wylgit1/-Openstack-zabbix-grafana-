<template>
<div>
     <el-alert
      title="提示: 告警升级配置"
      type="info"
      show-icon
      effect="dark"
      style="margin: 25px; padding: 12px; width: 96%"
    >
   
    </el-alert>
     <el-card style="margin: 25px; padding: 12px">
<el-form ref="form" :model="form" label-width="170px">
  <el-form-item label="默认操作步骤持续时间
">
    <el-input v-model="form.name"></el-input>
  </el-form-item>
  <!-- <el-form-item label="暂停操作以制止问题
">
   <el-checkbox v-model="checked"></el-checkbox>
  </el-form-item> -->
  <el-form-item label="操作" >
    <div style="border:solid 1px #dcdfe6">
    <el-table
      :data="tableData"
      style="width: 100%;border:none"
      size=small
      height:40px>
      <el-table-column
        prop="date"
        label="步骤"
        width="100">
      </el-table-column>
      <el-table-column
        prop="name"
        label="细节"
        width="400">
      </el-table-column>
      <el-table-column
        prop="address"
        label="开始于"
        width="100">
      </el-table-column>
      <el-table-column
        prop="time"
        label="持续时间"
        width="100">
      </el-table-column>
      <el-table-column
        prop="action"
        label="动作"
        width="100">
         <el-link type="primary">编辑</el-link>&nbsp;<el-link type="primary">移除</el-link>
      </el-table-column>
    </el-table>
    <el-link type="primary" style='width:50px;height:20px;'>添加</el-link>
    </div>
  </el-form-item>
  <el-form-item label="恢复操作">
    <div style="border:solid 1px #dcdfe6">
    <el-table
      :data="recoverdata"
      style="width: 100%;border:none"
      size=small
      height:40px>
      <el-table-column
        prop="detail"
        label="细节"
        width="400">
      </el-table-column>
      <el-table-column
        prop="action"
        label="动作"
        width="100">
         <el-link type="primary">编辑</el-link>&nbsp;<el-link type="primary">移除</el-link>
      </el-table-column>
    </el-table>
    <el-link type="primary" style='width:50px;height:20px;'>添加</el-link>
    </div>
  </el-form-item>
  <!-- <el-form-item label="更新操作">
    <div style="border:solid 1px #dcdfe6">
    <el-table
      :data="updateData"
      style="width: 100%;border:none"
      size=small
      height:40px
      slot="empty">
      <el-table-column
        prop="name"
        label="细节"
        width="400">
      </el-table-column>
      <el-table-column
        prop="action"
        label="动作"
        width="100">
         <el-link type="primary">编辑</el-link>&nbsp;<el-link type="primary">移除</el-link>
      </el-table-column>
    </el-table>
    <el-link type="primary" style='width:50px;height:20px;'>添加</el-link>
    </div>
  </el-form-item> -->
 
  <el-form-item>
    <el-button type="primary" @click="onSubmit">更新</el-button>
    <el-button>取消</el-button>
  </el-form-item>
</el-form>
    </el-card>
</div>
</template>
<script>
export default{
    data() {
      return {
        form: {
          name: '',
          region: '',
          date1: '',
          date2: '',
          delivery: false,
          type: [],
          resource: '',
          desc: ''
        },
        checked: false,
        tableData: [{
            date: '1 - 2',
            name: '发送消息给用户:运维人员(运维人员运维人员)通过所有介质',
            address: '立即地',
            time:'5m',
            action:''
          }, {
            date: '3 - 4',
            name: '发送消息给用户:运维总监(运维总监运维人员)通过所有介质',
            address: '00:15:00',
            time:'1h',
            action:''
          },{
            date: '5',
            name: '发送消息给用户:运维董事长(运维董事长运维董事长)通过所有介质',
            address: '02:15:00',
            time:'默认',
            action:''
          },],
          recoverdata:[{
            detail:'通知所有参与者'
          }]

      }
    },
    methods: {
      onSubmit() {
        console.log('submit!');
      }
    }
  }
</script>
<style>
/* // 去掉所有的横线 */
.el-table th.is-leaf {
  /* 去除上边框 */
    border: none;
    line-height: 40px;
    
}
.el-table__row>td{ border: none; }
.el-table::before { height: 0px; }
/* 设置表头的高度 */
.el-table__header td,.el-table__header th{
padding:0px 0px;
}
</style>