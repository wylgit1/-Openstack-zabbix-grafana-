<template>
  <div>
    <el-alert
      title="提示:"
      type="info"
      show-icon
      effect="dark"
      style="margin: 25px; padding: 12px; width: 96%"
    >
    </el-alert>
    <el-card style="margin: 25px; padding: 12px">
      <div slot="header">
        <div
          style="margin-left: 30px; width: 97%; height: 30px; line-height: 30px"
        >
          <el-button
            type="primary"
            size="mini"
            icon="el-icon-edit"
            plain
            style="float: left"
            @click="getadd()"
            >添加主机</el-button
          >
          <el-dialog
              title="提示"
              :visible.sync="createdialogVisible"
              :before-close="handleClose"
            >
              <el-divider content-position="left">手动添加主机(主机需提前安装好监控客户端)</el-divider>
              <span>请输入添加的主机信息</span>
              <el-form
                ref="createdata"
                :model="createdata"
                label-width="100px"
              >
                <el-form-item prop="host" label="主机">
                  <el-input v-model="createdata.host"></el-input>
                </el-form-item>
                <!-- <el-form-item prop="nickname" label="主机昵称">
                  <el-input v-model="createdata.nickname"></el-input>
                </el-form-item> -->
                <el-form-item prop="host_ip" label="主机ip">
                  <el-input v-model="createdata.host_ip"></el-input>
                </el-form-item>
                <el-form-item prop="group_id" label="组">
                  <el-select
                    class="flavor"
                    v-model="createdata.group_id"
                    placeholder="flavor"
                  >
                    <el-option
                      v-for="(key, value, index) in groups"
                      :key="index"
                      :label="key.name + ''"
                      :value="key.groupid"
                    >
                    </el-option>
                  </el-select>
                </el-form-item>
                <el-form-item prop="template_id" label="模板">
                  <el-select
                    class="template_id"
                    v-model="createdata.template_id"
                    placeholder="template_id"
                  >
                    <el-option
                      v-for="(key, value, index) in templates"
                      :key="index"
                      :label="key.name + ''"
                      :value="key.templateid"
                    >
                    </el-option>
                  </el-select>
                </el-form-item>
                <el-divider content-position="left">自动添加(请配合自动化一起使用)</el-divider>
                    <!-- <el-form-item prop="host_ip"
                                  label="请输入主机ip"
                                  label-width="120px">
                      <el-input v-model="model.host_ip2"
                                placeholder="请输入"
                                clearable></el-input>
                    </el-form-item> -->
                    <!-- 这是穿梭框 -->
                <el-transfer v-model="createdata.rightData"
                            :props="{key: 'value',label: 'label'}"
                            :titles="['所有主机', '预添加的主机']"
                            @change="handleChange"
                            :data="createdata.liftData"></el-transfer>
                <el-form-item>
                  <el-button @click="createdialogVisible = false">取消</el-button>
                  <el-button type="primary" @click="addhosts()"
                    >确定</el-button
                  >
                </el-form-item>
              </el-form>
              <!-- <span slot="footer" class="dialog-footer">
                <el-button @click="dialogVisible = false">取 消</el-button>
                <el-button type="primary" @click="dialogVisible = false"
                  >确 定</el-button
                >
              </span> -->
            </el-dialog>
        </div>
      </div>
      <el-table :data="table_data"
         ref="filterTable"  
         @filter-change="HandeleFilterChange"
         style="width: 100%">
        <el-table-column prop="hostid" label="主机id"> </el-table-column>
        <el-table-column prop="host" label="主机"> </el-table-column>
        <el-table-column 
        prop="interfaces[0].ip" 
        column-key="interfaces[0].ip"
        label="ip地址"
        :filters="IPs"
        :filter-method="filterHandler"
        > </el-table-column> 
        <!-- <el-table-column prop="group_id" label="主机群组"> </el-table-column>
        <el-table-column prop="template_id" label="主机模板"> </el-table-column> -->
        <el-table-column prop="status" label="状态"> </el-table-column>
        <el-table-column label="应用集"
                         prop="hostid"
                         align="center">
          <template slot-scope="scope">
            <el-link type="primary">
              <router-link @click.native="get_trigger(scope.$index, scope.row)"
                           :to="{ path: '/monitor/application/'}"
                           replace>应用集
              </router-link>
            </el-link>
          </template>
        </el-table-column>

        <el-table-column label="监控项"
                         prop="hostid"
                         align="center">
          <template slot-scope="scope">
            <el-link type="success">
              <router-link @click.native="get_trigger(scope.$index, scope.row)"
                           :to="{ path: '/monitor/item/'}"
                           replace>监控项
              </router-link>
            </el-link>
          </template>
        </el-table-column>
        <el-table-column label="触发器"
                         prop="hostid"
                         align="center">
          <template slot-scope="scope">
            <el-link type="warning">
              <router-link @click.native="get_trigger(scope.$index, scope.row)"
                           :to="{ path: '/monitor/trigger/'}"
                           replace>触发器
              </router-link>
            </el-link>
          </template>
        </el-table-column>
        <el-table-column label="操作" width="150">
          <template slot-scope="scope">
             <el-dropdown split-button type="primary">
        更多菜单
            <el-dropdown-menu slot="dropdown">
                 <el-dropdown-item @click.native="update(scope.$index, scope.row)" >修改信息</el-dropdown-item>
                <el-dropdown-item @click.native="getdelete(scope.$index, scope.row)">删除主机</el-dropdown-item>             
                <!-- <el-dropdown-item @click.native="webshellEdit(scope.$index, scope.row)">webshell</el-dropdown-item> -->
                <el-dropdown-item @click.native="jumptoSS(scope.$index, scope.row)">添加群组</el-dropdown-item>       
                <!-- <span v-for="role,index in scope.row.role" :key="index">
                    <el-dropdown-item @click.native="changeMenu(scope.$index, scope.row,role.value)">{{role.value}}</el-dropdown-item>
              </span> -->
    </el-dropdown-menu>
    </el-dropdown>



            <el-dialog
              title="提示"
              :visible.sync="dialogVisible"
              :before-close="handleClose"
            >
              <span>请输入需要修改的信息</span>
              <el-form
                ref="updatehostsinfo"
                :model="updatehostsinfo"
                label-width="100px"
              >
                <el-form-item prop="host" label="主机名">
                  <el-input v-model="updatehostsinfo.host"></el-input>
                </el-form-item>
                <el-form-item prop="host_ip" label="ip地址">
                  <el-input v-model="updatehostsinfo.host_ip"></el-input>
                </el-form-item>
                <!-- <el-form-item prop="rent_time" label="租期">
                  <el-input v-model="updatehostsinfo.rent_time"></el-input>
                </el-form-item> -->
                <el-form-item label="已启用">
                <template>
                   <!-- `checked` 为 true 或 false -->
                <el-checkbox v-model="updatehostsinfo.status">{{updatehostsinfo.status}}</el-checkbox>
                </template>
                </el-form-item>
                <el-form-item>
                  <el-button @click="dialogVisible = false">取消</el-button>
                  <el-button type="primary" @click="updateEdit()"
                    >确定</el-button
                  >
                </el-form-item>
              </el-form>
              <!-- <span slot="footer" class="dialog-footer">
                <el-button @click="dialogVisible = false">取 消</el-button>
                <el-button type="primary" @click="dialogVisible = false"
                  >确 定</el-button
                >
              </span> -->
            </el-dialog>
            <el-dialog
              title="提示"
              :visible.sync="deletedialogVisible"
              :before-close="handleClose"
            >
              <span>请确认是否删除。</span>
              <div 
              style="margin-top:30px;">
                  <el-button @click="deletedialogVisible = false">取消</el-button>
                  <el-button type="primary" @click="deleteEdit()"
                    >确定</el-button
                  >
              </div>
            </el-dialog>
            <el-dialog
              title="提示"
              :visible.sync="allocateDialogVisible"
              :before-close="handleClose"
            >
              

              <div 
              style="margin-top:30px;">
                  <el-button @click="allocateDialogVisible = false">取消</el-button>
                  <el-button type="primary" @click="allocate()"
                    >确定</el-button
                  >
              </div>
            </el-dialog>
          </template>
        </el-table-column>
  <el-table-column align="right"
                         >
          <template slot="header" slot-scope="scope">
            <el-input v-model="search"
                      size="mini"
                      placeholder="输入关键字搜索"
                       />
          </template>
                  </el-table-column>
      </el-table>
      <el-pagination :current-page="param.currentPage"
                     :page-sizes="[5, 10, 15, 20]"
                     :page-size="param.pagesize"
                     layout="total, sizes,prev, pager, next, jumper"
                     :total="parseInt(total)"
                     @size-change="handleSizeChange"
                     @current-change="handleCurrentChange" />
    </el-card>
  </div>
</template>

<script>
import cons from "@/components/constant";
import { deleteHosts, updateHosts, getHosts,createHosts,get_grp_tmp} from "@/api/hosts";
import { getMsg } from "@/api/vm_info";
import { getUsername,login } from "@/api/user";
import {  getServerVolume,getVolumename,getCV,updateCV,allocateVM,separateVM, } from "@/api/cloud_volume";

export default {
  data() {
    return {
      //存放所有主机信息用以显示
      hosts: [],
      tabledata:[],
      //创建所需数据
      createdata:{
        host_ip:"",
        host:"",
        liftData: [], //穿梭框文件id数组
        rightData: [], // 注意:key 的字符类型要一致!!!
      },
      deletedata:{},
      createdialogVisible:false,
      groups:[],
      templates:[],



      /* 修改所需信息 */
      checked: true,
      temp: "", //存放修改时所选的vmid
      designatedhosts: [], //存放修改时所选当前vm信息
      dialogVisible: false, //dialog显示
      network:[],
      floatingIp: [], //存放修改时浮动ip可选信息
      flavor: [], //存放修改时flavor可选信息
      updatehostsinfo: {
        host_id: "",
        host: "",
        nickname: "",
        available: "",
        status: '',//判断主机是否启用 status=0时已启用
        host_ip:"",
      }, //部分修改后提交的主机信息
      // ifstatus:0,//判断主机是否启用 status=0时已启用
      //删除dialog
      deletedialogVisible: false, //dialog显示
      allocateDialogVisible:false,
      CVinfo:{
        cloud_volume_name:"",
      },
      /* 分页所需数据*/
      value: '100',
      param: {
        currentPage: 1, // 当前页
        pagesize: 5, // 默认每页多少张
      },
      total: 0, // 共多少页
      join: null,
      currentIndex: '',
			currentPage: 1, //初始页
			pagesize: 5, //    每页的数据

      /* 过滤器查询所需数据 */
      usernames:[],
      volumenames:[],
      IPs:[{text: 'selfservice', value: 'selfservice'}, {text: 'provider', value: 'provider'}],
      selectdata: {nickname: [], ip: []},
      newData: [],
      twoData: [],
      data: [],
      listdata: '',

      //查询
        search:"",
        
       model: {
        host_name: "",
        host_ip: "",
        host_group: "",
        host_template: "",
        liftData: [], //穿梭框文件id数组
        rightData: [], // 注意:key 的字符类型要一致!!!
      },
        
        
      
      
      //菜单
      roles: [{
          id:1,
          value: '修改主机',
      },{
          id:2,
          value: '删除主机',
      },{
          id:3,
          value: 'webshell',
      },{
          id:4,
          value: '恢复快照',
      }
      ],
      roles1: [{
          id:1,
          value: '修改主机',
      },{
          id:2,
          value: '删除主机',
      },{
          id:3,
          value: 'webshell',
      },{
          id:4,
          value: '恢复快照',
      },{
          id:5,
          value: '分离云盘',
      },
      ],
      roles2: [{
          id:1,
          value: '修改主机',
      },{
          id:2,
          value: '删除主机',
      },{
          id:3,
          value: 'webshell',
      },{
          id:4,
          value: '恢复快照',
      },{
          id:5,
          value: '连接云盘',
      },
      ],

      
    };
  },
  mounted() {
    this.getHostsMessage(); //得到所有主机信息展示在页面
    this.fetchData(); // 得到修改所需数据
    this.getUsernames();
    localStorage.setItem('table', JSON.stringify(this.vm))
    this.getHostsAlready();

  },
  methods: {
    changeMenu(index,row,value){
        if(value=='修改信息'){
          this.update(index,row);
        }else if(value=='删除主机'){
          this.getdelete(index,row);
        }else if(value=='webshell'){
          this.webshellEdit(index,row);
        }else if(value=='恢复快照'){
          this.jumptoSS(index,row)
        }else if(value=='分离云盘'){
          this.separate(index,row)
        }else if(value=='连接云盘'){
          this.getallocate(index,row)
        }
    },
    //得到所有主机信息展示在页面
    getHostsMessage() {
      getHosts()
        .then((res) => {
          this.hosts = res.data;
          this.tabledata=res.data;
          this.total = res.data.length;    
          for (let index = 0; index < res.data.length; index++) {
              if(res.data[index].status==0)
                   this.hosts[index].status = '已启用'
              else
                   this.hosts[index].status = '未启用'
            }

          console.log(this.hosts);
        
    })
        .catch((err) => {
          console.log(err);
        });
    },

    getadd(index, row) {
      this.createdialogVisible = true;
      console.log(row.id);
      this.temp = row.id;
    },

    addhosts(){
        console.log(this.createdata)
        createHosts(this.createdata)
        .then((res) => {
            console.log(res);
            this.createdialogVisible=false;
            this.$notify({
            title: "添加成功",
            message: "！",
            type: "success",
            });
            this.getHostsMessage();
        })
        .catch((err) => {
            console.log(err);
        });
        },


    // 删除主机
    getdelete(index, row){
      this.deletedialogVisible=true;
      this.deletedata = row;
      console.log("@@@@!!!!!!!!!!!@@@@@@@@@@")
      console.log(this.deletedata)
    },
    deleteEdit() {
      let $this=this
      let loading = this.$loading({
        lock:true,
        text:"删除中，请稍候...",
        background:'rgba(0,0,0,0.5)'
      })
      console.log(this.deletedata)
      deleteHosts(this.deletedata)
        .then((res) => {
          loading.close();
          this.getHostsMessage();
          this.deletedialogVisible=false;
          this.$notify({
            title: "删除成功",
            message: "！",
            type: "success",
          });
          
        })
        .catch((err) => {
          console.log(err);
        });
    },
    //webshell
    webshellEdit(index, row) {
      let $this=this
      let loading = this.$loading({
        lock:true,
        text:"请稍候...",
        background:'rgba(0,0,0,0.5)'
      })
      getConsoleurl(row)
        .then((res) => {
          loading.close();
          let url=res.console.url;
          window.open(url, '_blank');
          // let url="http://controller:6080/vnc_auto.html?token="+res+"&title=qwert1(5699fa80-9caa-42fd-8a66-ac091c3a6057)";
          // window.open(url, '_blank');
        })
        .catch((err) => {
          console.log(err);
        });
    },

    
    // 得到创建所需数据
    fetchData() {
      get_grp_tmp()
        .then((res) => {
          console.log(res);
          this.groups = res["group"];
          this.templates = res["template"];
        })
        .catch((err) => {
          this.init = false;
          this.err = true;
        });
    },

    // ###########修改所需方法#############
    // 获得修改时所选vm的id
    update(index, row) {
      this.dialogVisible = true;
      console.log("打印指定修改的主机")
      console.log(row);
      console.log(row.hostid)
      this.changethestatus(row.status);
      this.temp = row;
      console.log(this.temp);
      
    },
    // 获得指定主机信息
    getappointhost(row) {
      appointhost(row)
        .then((res) => {
          this.designatedhosts = res.data;
          console.log("#####");
          console.log(this.designatedhosts);
        })
        .catch((err) => {
          console.log(err);
        });
    },
    // 更新指定主机信息
    updateEdit() {
      // 循环遍历vm找到修改指定的hosts信息
      // for (let index = 0; index < this.hosts.length; index++) {
      //   if (this.hosts[index].hostid == this.temp) {
      //     this.designatedhosts = this.hosts[index];
      //   }
      // }
      this.designatedhosts = this.temp
      console.log(this.designatedhosts);

      console.log("修改信息")
      console.log(this.updatehostsinfo)

      // 判断需要修改的字段
      if (this.updatehostsinfo.host_ip != "")
        this.designatedhosts.host_ip = this.updatehostsinfo.host_ip;
      if (this.updatehostsinfo.host != "")
        this.designatedhosts.host = this.updatehostsinfo.host;
      if (this.updatehostsinfo.status != this.designatedhosts.status)
        this.designatedhosts.status = this.updatehostsinfo.status+0;
      console.log(this.designatedhosts)
      updateHosts(this.designatedhosts)
        .then((res) => {
          console.log(res);
          this.dialogVisible=false;
          this.$notify({
            title: "修改成功",
            message: "！",
            type: "success",
          });
        })
        .catch((err) => {
          console.log(err);
        });
    },
    // 判断是否启用，status等于0时已启用 等于1时停用
    changethestatus(value){
        if(value == '已启用'){
          this.updatehostsinfo.status=true
          console.log("主机状态已启用")
          console.log(this.updatehostsinfo.status)
        }else if(value=='未启用'){
          this.updatehostsinfo.status=false
          console.log("主机状态停用")
          console.log(this.updatehostsinfo.status)
        }
    },
   
    //控制关闭dialog
    handleClose(done) {
      this.$confirm("确定关闭吗")
        .then(() => {
          // function(done)，done 用于关闭 Dialog
          done();

          console.info("点击右上角 'X' ，取消按钮或遮罩层时触发");
        })
        .catch(() => {
          console.log("点击确定时触发");
        });
    },

  /* 查询相关 */
  //获取用户姓名用以过滤器查询
  getUsernames(){
    getUsername()
        .then((res) => {
          console.log("***************#@^%^");
          console.log(res);
          this.usernames=res.data;
          for (let index = 0; index < res.data.length; index++) {
            this.usernames[index].text = res.data[index].username;
            this.usernames[index].value = res.data[index].username;
          }
          console.log(this.usernames)
        })
        .catch((err) => {
          console.log(err);
        });
  },
  //获取IP错误 for循环进不去不知道为什么
  getIP(ips){     
    console.log(Object.keys(ips).length);
    let iplength=Object.keys(ips).length;
    console.log(iplength);
    for (let index = 0; index < iplength; index++) {
      this.IPs[index].text = ips[index+1];
      console.log(ips[index+1]);       
      this.IPs[index].value = ips[index+1];   
    }
    console.log("****");
    console.log(this.IPs);
  },
  /*过滤器*/
  filterHandler(value, row, column) {
        const property = column['property'];
        return row[property] === value;
      },
  //控制过滤数据
  HandeleFilterChange(filters){
    //调用时重新将全部vm信息给newdata
     this.newData = [];
     for (let p = 0; p < this.tabledata.length; p++) {
              this.newData.push(this.tabledata[p])
            }
     console.log("###@@@");
       console.log(this.tabledata)
      this.selectdata[String(Object.keys(filters))] = filters[String(Object.keys(filters))]
      console.log("###@@@1")
     console.log(this.selectdata);
      console.log("###@@@2")
     console.log(this.newData);
      //循环遍历选择数组
      for (let j = 0; j < Object.keys(this.selectdata).length; j++) {
        console.log("选择数组长度")
        console.log(this.selectdata[Object.keys(this.selectdata)[j]].length)
        //如果筛选条件只有一个
        if (this.selectdata[Object.keys(this.selectdata)[j]].length <= 1) {
          for (let k = 0; k < this.selectdata[Object.keys(this.selectdata)[j]].length; k++) {
            for (let i = 0; i < this.newData.length; i++) {
              if (this.selectdata[Object.keys(this.selectdata)[j]][k] !== this.newData[i][String(Object.keys(this.selectdata)[j])]) {
                this.newData.splice(i, 1)
                i--
              }
            }
          }
        } else {
          // 筛选条件有多个
          this.twoData = []
          for (let k = 0; k < this.selectdata[Object.keys(this.selectdata)[j]].length; k++) {
            for (let i = 0; i < this.newData.length; i++) {
              if (this.selectdata[Object.keys(this.selectdata)[j]][k] === this.newData[i][String(Object.keys(this.selectdata)[j])]) {
                this.twoData.push(this.newData[i])
              }
            }
          }
          if (this.twoData.length !== 0) {
            this.newData = []
            for (let io = 0; io < this.twoData.length; io++) {
              this.newData.push(this.twoData[io])
            }
          }
        }
      }
      console.log("###@@@$")
      console.log(this.newData)
      this.vm = this.newData
    },
  
  /* 分页 */
    handleSizeChange: function(size) {
			this.pagesize = size;
			// console.log(this.pagesize) //每页下拉显示数据
		},
		handleCurrentChange: function(currentPage) {
			this.currentPage = currentPage;
			// console.log(this.currentPage) //点击第几页
		},

    // onAddUser() {
    //   this.$refs.addFormRef.validate(async (valid) => {
    //     if (!valid) return null; // 如果验证失败就不往下继续执行
    //     const { data: res } = await this.$http.post("users", this.addUser);
    //     if (res.meta.status !== 201) return this.$message.error(res.meta.msg);
    //     this.$message.success("添加成功");
    //     this.dialogTableVisible = false; // 关闭弹框
    //     this.$refs.addFormRef.resetFields(); // 清空表单
    //     this.getUserList(); // 重新调用，刷新表单
    //   });
    // },
    
    jumptoSS(index,row){
      console.log(row.VM_name)
       this.$router.push({
        path:"/snapshotManagement/index",
        query: { VM_name:row.VM_name}
        });
    },

     // 所有操作后进行的修改云盘信息
    //  updateEdit(data) {
    //   updateCV(data)
    //     .then((res) => {
    //       console.log(res);
    //       this.allocateDialogVisible=false;
    //       this.updateDialogVisible=false;
    //     })
    //     .catch((err) => {
    //       console.log(err);
    //     });
    // },
     //获取穿梭框需要的数据
    getHostsAlready () {
      this.$http
        .get(
          cons.apis + "/get/hosts_already/",
          {
            responseType: "json",
          }
        )
        .then((res) => {
          if (res.data.code == 200)
          {
            console.log("待选主机数据");
            console.log(res.data);
            console.log(res.data.data);
            this.createdata.liftData = res.data.data

          }
        })
        .catch((err) => {
          console.log(err);
        });
    },
  //穿梭框测试
      handleChange (value, direction, movedKeys) {
        console.log(value, direction, movedKeys);
      },
      get_trigger (index, row) {
        console.log("测试中...")
        console.log(row.hostid)
        sessionStorage.setItem('hostid', row.hostid)
      },
  },
  computed: {
  table_data() {
    let search = this.search;
    // 搜索功能
    if (search){
      let list =this.vm.filter(data => !search || data.nickname.toLowerCase().includes(search.toLowerCase())|| data.VM_name.toLowerCase().includes(search.toLowerCase()));
      let fenye = list.slice((this.currentPage-1)*this.pagesize,this.currentPage*this.pagesize);
      // 获取查询的结果，把数组长度赋值给 分页组件中的total
      this.total = fenye.length;
      return list,fenye
    }
    // 分页功能
    else {
     //所有数据的长度  赋值给分页组件中的total
      this.total = this.hosts.length;                        
      let fenye = this.hosts.slice((this.currentPage-1)*this.pagesize,this.currentPage*this.pagesize)
      return fenye
    }
  }
}

};
</script>

<style>
</style>