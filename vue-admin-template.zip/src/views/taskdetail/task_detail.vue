<template>
  <div>
    <el-alert
      title="提示:"
      type="info"
      show-icon
      effect="dark"
      style="margin: 25px; padding: 12px; width: 96%"
    >
    </el-alert>
    <el-card style="margin: 25px; padding: 12px">
      <div slot="header">
        <div
          style="margin-left: 30px; width: 97%; height: 30px; line-height: 30px"
        >
          <!-- <el-button
            type="primary"
            size="mini"
            icon="el-icon-edit"
            plain
            style="float: left"
             @click="centerDialogVisible = true"
            >上传脚本</el-button
          > -->
          <el-select 
          v-model="taskvalue.value" 
          placeholder="请选择任务" 
          @change="getList($event)">
              <el-option
                v-for="item in taskinfo"
                :key="item.value"
                :label="item.label"
                :value="item.value">
              </el-option>
            </el-select>
     <el-button type="primary" size='mini' style="float: right;margin-right:20px"  @click="deletetasklog()">清空当前日志</el-button>

        </div>
      </div>
  	<div id="interfaceCorrection">  
        <yaml-editor  v-model="createdata.playbook" />
	</div>

    </el-card>
  </div>
</template>

<script>
import YamlEditor from '@/components/yamlEditor'
import {getplaybook} from '@/api/playbook'
import {gettasklog,deltasklog} from '@/api/playbook'
const playbook_content = "- hosts: all\n  become: yes\n  become_method: sudo\n  gather_facts: no\n\n  tasks:\n  - name: \"install {{ package_name }}\"\n    package:\n      name: \"{{ package_name }}\"\n      state: \"{{ state | default('present') }}\"";
import cons from "@/components/constant";
export default {
    components: { YamlEditor },
  data(){
    return {
      playbook_content: playbook_content,
      createdata:{
        playbook: playbook_content,
      },
      taskinfo:[],
      taskvalue:{
        value:'',
      },
      tmp:""
    }
  },
  mounted(){
    this.getTaskinfo()
    this.getListrouter()
  },
  methods:{
    getListrouter(){
        const taskid= this.$route.query.id
        console.log(taskid)
        if(taskid){
          this.getList(taskid)
        }
    },
    getList(id){
      this.tmp=id
      console.log(this.tmp)
      gettasklog(id) 
    .then((res) => {
        console.log(res)
        this.createdata.playbook = JSON.stringify(res,null, 2);

        console.log(this.createdata.playbook)         
      })
      .catch((err) => {
        console.log(err);
      });
    },
     /* 查询相关 */
  //获取任务id名称用以过滤器查询
  getTaskinfo(){
    getplaybook()
        .then((res) => {
          console.log("***************#@^%^");
          console.log(res);
          this.taskinfo=res.data;
          for (let index = 0; index < res.data.length; index++) {
            this.taskinfo[index].value = res.data[index].id;
            this.taskinfo[index].label = "任务id: " + res.data[index].id +" - 任务名称："+ res.data[index].funcName;
          }
          console.log(this.usernames)
        })
        .catch((err) => {
          console.log(err);
        });
  },
  deletetasklog(){
    let $this=this
      let loading = this.$loading({
        lock:true,
        text:"删除中，请稍候...",
        background:'rgba(0,0,0,0.5)'
      })
      deltasklog(this.tmp)
      .then((res) => {
        loading.close();
          this.$notify({
            title: "删除成功",
            message: "！",
            type: "success",
          });
          this.getList(this.tmp)
          console.log(res);
      })
      .catch((err) => {
          console.log(err);
        });
  
  },
},
//路由跳转自动调用
  watch: {
   '$route': 'getListrouter'
 }
}

</script>

<style>
.edit-input {
  padding-right: 100px;
}
.cancel-btn {
  position: absolute;
  right: 15px;
  top: 10px;
}
</style>