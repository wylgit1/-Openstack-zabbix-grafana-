
<template>
  <div class="app-container">
    <el-button type="primary" @click="centerDialogVisible = true" icon="el-icon-plus" size="mini" style="margin-bottom: 10px;">添加一个剧本</el-button><br>

    <el-table  :data="playbooklist" border fit highlight-current-row style="width: 100%">
      <el-table-column align="center" label="ID" width="80">
        <template slot-scope="{row}">
          <span>{{ row.id }}</span>
        </template>
      </el-table-column>

      <el-table-column width="360px" align="center" label="nickName">
        <template slot-scope="{row}">
          <span>{{ row.nickName }}</span>
        </template>
      </el-table-column>



      <el-table-column width="200px" label="playbook">
        <template slot-scope="{row}">
          <span>{{ row.playbook }}</span>
        </template>
      </el-table-column>
            <el-table-column width="180px" align="center" label="描述">
        <template slot-scope="{row}">
          <span>{{ row.funcName }}</span>
        </template>
      </el-table-column>
      <el-table-column width="120px" label="编辑">
        <template slot-scope="{row}">
          <el-button type="primary" size="mini" @click="showContent(row)">查看内容</el-button>
          <el-button type="primary" size="mini"  @click="executorVisible = true">执行剧本</el-button>
        </template>
      </el-table-column>
      <!-- <el-table-column width="100px" label="执行">
        <template slot-scope="{row}">
          <el-button type="primary" size="mini" @click="showContent(row)">执行</el-button>
        </template>
      </el-table-column> -->
    </el-table>

    <el-dialog
      title="添加一个 PlayBook"
      :visible.sync="centerDialogVisible"
      width="60%"
      center>

        <el-row class="demo-autocomplete">
          <el-col :span="12">
              <div class="demo-input-suffix" style="padding-bottom: 5px">
                描述PlayBook功能
                </div>
                <el-input v-model="createdata.funcName" style="width:98%"></el-input>
              
          </el-col>
          <el-col :span="12">
              <div class="demo-input-suffix" style="padding-bottom: 5px;">
                PlayBook 文件名
              </div>
                <el-input v-model="createdata.nickName" style="width:98%"></el-input>
          </el-col>
        </el-row><br>
        <div class="demo-input-suffix" style="padding-bottom: 5px;">
          PlayBook 内容
        </div>

        <yaml-editor  v-model="createdata.playbook" />

      <span slot="footer" class="dialog-footer">
        <el-button plain size="small" @click="centerDialogVisible = false">取 消</el-button>
        <el-button type="primary" plain size="small"  @click="submit_playbook">添 加</el-button>
      </span>
    </el-dialog>
    <el-dialog
              title="提示"
              :visible.sync="executorVisible"
              :before-close="handleClose"
            >
              <span>请输入勾选需要执行的主机</span>
              <el-table
                :data="hostlist"
                tooltip-effect="dark"
                style="width: 100%"
                @selection-change="handleSelectionChange">
                <el-table-column
                  type="selection"
                  width="55">
                </el-table-column>
                <el-table-column
                  prop="server"
                  label="主机ip"
                  width="200">
                </el-table-column>
                <el-table-column
                  prop="server_name"
                  label="用户"
                  width="200">
                </el-table-column>
              </el-table>
              <span slot="footer" class="dialog-footer">
                <el-button @click="dialogVisible = false">取 消</el-button>
                <el-button type="primary" @click="dialogVisible = false"
                  >确 定</el-button
                >
              </span>
            </el-dialog>

  </div>
</template>

<script>
import Axios from 'axios'
import {getplaybook,addplaybook} from '@/api/playbook'
import { fetchList, getApi } from '@/api/ansibleui'
import YamlEditor from '@/components/yamlEditor'
const playbook_content = "- hosts: all\n  become: yes\n  become_method: sudo\n  gather_facts: no\n\n  tasks:\n  - name: \"install {{ package_name }}\"\n    package:\n      name: \"{{ package_name }}\"\n      state: \"{{ state | default('present') }}\"";
import cons from "@/components/constant";
export default {
    data() {
    return {
      playbooklist:[],
      hostlist:[],
      createdata:{
        playbook: playbook_content,
      },
      new_playbook_desp: '',
      new_playbook_filename: '',
      playbook_content: playbook_content,
      centerDialogVisible: false,
      executorVisible: false,
      list: null,
      listLoading: true,
      listQuery: {
        page: 1,
        limit: 10
      }
    }
  },
  name: 'InlineEditTable',
  components: { YamlEditor },
  filters: {
    statusFilter(status) {
      const statusMap = {
        published: 'success',
        draft: 'info',
        deleted: 'danger'
      }
      return statusMap[status]
    }
  },

  mounted() {
    this.getList();
    this.gethostList()
  },
  methods: {
    submit_playbook(){
      addplaybook(this.createdata) 
    .then((res) => {
        this.centerDialogVisible=false,
        this.getList();
         this.$notify({
              title: "恭喜你",
              message: "创建剧本成功",
              type: "success",
            });
        console.log(res.data)         
      })
      .catch((err) => {
        console.log(err);
      });
    },
    getList() {
      getplaybook() 
    .then((res) => {
        this.tabledata=res.data;//过滤器查询用
        this.playbooklist = res.data;
        console.log(this.playbooklist)         
      })
      .catch((err) => {
        console.log(err);
      });
    },
    // 获得免密配置过的主机信息
    gethostList () {
      this.$http
        .get(cons.apis + "/server/", {
          responseType: "json",
        })
        .then((res) => {
          if (res.status == 200)
          {
            console.log(res.data);
            this.hostlist = res.data

          }
        })
        .catch((err) => {
          console.log(err);
        });
    },
    playbookExecutor(){
      
    },
    //得到所选中的虚拟机信息
    handleSelectionChange(val) {
        this.multipleSelection = val;
        console.log(val)

      },
    //dialog控制关闭
    handleClose(done) {
      this.$confirm("确定关闭吗")
        .then(() => {
          // function(done)，done 用于关闭 Dialog
          done();
          console.info("点击右上角 'X' ，取消按钮或遮罩层时触发");
        })
        .catch(() => {
          console.log("点击确定时触发");
        });
    },
    cancelEdit(row) {
      row.title = row.originalTitle
      row.edit = false
      this.$message({
        message: 'The title has been restored to the original value',
        type: 'warning'
      })
    },
    showContent(row) {
      console.log(row)
      this.playbook_content = ""
      Axios.get(this.$root.baseUrl+'/playbook/content/'+ row.id +'/').then(resp => {
      this.playbook_content = resp.data.content
      this.centerDialogVisible = true
        })
      // var data = getApi('/')
    }
  }
}
</script>

<style scoped>
.edit-input {
  padding-right: 100px;
}
.cancel-btn {
  position: absolute;
  right: 15px;
  top: 10px;
}
</style>
