<template>
  <div>

    <el-alert title="提示:您可以在添加,查看，删除主机监控项"
              type="info"
              show-icon
              effect="dark"
              style="margin: 25px; padding: 12px;width:96%">
    </el-alert>
    <el-card style="margin: 25px; padding: 12px">

      <div slot="header">
        <div style="float:left">
          <svg t="1635682143547"
               class="icon"
               viewBox="0 0 1141 1024"
               version="1.1"
               xmlns="http://www.w3.org/2000/svg"
               p-id="4261"
               width="30"
               height="30">
            <path d="M1140.483293 937.937675v-715.169869a72.962543 72.962543 0 0 0-65.810845-79.505586 82.472781 82.472781 0 0 0-13.694742 0H613.235719a70.109472 70.109472 0 0 1-41.464636-12.553514s-19.020475-31.573989-54.01815-82.548863c-31.573989-57.061426-73.038625-47.551188-73.038625-47.551188h-346.172649a92.0591 92.0591 0 0 0-98.145652 85.592139 36.861681 36.861681 0 0 0-0.38041 6.466961v838.802959c0 104.612614 79.505587 92.0591 79.505587 92.0591h991.347169c82.548863 0 69.614939-85.592139 69.61494-85.592139zM289.126821 756.482341h-3.804095a58.811309 58.811309 0 0 1-56.681017-60.104701v-4.184505a58.316777 58.316777 0 0 1 60.485112-56.300607 60.294907 60.294907 0 1 1 0 120.589813z m0-225.582836h-3.804095a58.773269 58.773269 0 0 1-56.681017-60.104702 60.485111 60.485111 0 1 1 60.485112 60.104702z m590.775961 222.53956H498.732458a57.25163 57.25163 0 0 1 0-114.503261h381.170324a57.25163 57.25163 0 1 1 0 114.503261z m0-225.582836H498.732458a57.25163 57.25163 0 0 1 0-114.503261h381.170324a57.25163 57.25163 0 1 1 0 114.503261z"
                  fill="#2D9EF4"
                  p-id="4262"></path>
          </svg>
        </div>
        <div style="margin-left:30px;width:97%;height:30px;line-height:30px">
          <el-button type="primary"
                     size="mini"
                     icon="el-icon-edit"
                     plain
                     style="float:right"
                     @click="getDate()">添加监控项</el-button>
        </div>
      </div>
     <el-table :data="table_data"
         ref="filterTable"  
         @filter-change="HandeleFilterChange"
         style="width: 100%">
        <el-table-column type="index"
                         width="50">
        </el-table-column>
        <el-table-column label="监控项id"
                         prop="itemid"
                         align="center">
        </el-table-column>
        <el-table-column label="监控项名称"
                         prop="name"
                         align="center">
        </el-table-column>
        <el-table-column label="监控项key"
                         prop="key_"
                         align="center">
        </el-table-column>
        <el-table-column align="center"
                         width="150">
          <template slot="header"
                    slot-scope="scope">
            <el-input v-model="search"
                      size="mini"
                      placeholder="输入关键字搜索" />
          </template>
          <template slot-scope="scope">
            <el-button type="danger"
                       size="mini"
                       icon="el-icon-delete"
                       circle
                       @click="getdelete(scope.$index, scope.row)"></el-button>
          </template>
        </el-table-column>
      </el-table>
      <el-pagination :current-page="param.currentPage"
                     :page-sizes="[5, 10, 15, 20]"
                     :page-size="param.pagesize"
                     layout="total, sizes, prev, pager, next, jumper"
                     :total="parseInt(total)"
                     @size-change="handleSizeChange"
                     @current-change="handleCurrentChange" />
    </el-card>
    <el-dialog title="添加监控项"
               :visible.sync="dialogVisible"
               width="50%">

      <el-form ref="$form"
               :model="model"
               label-position="left"
               label-width="100px"
              >
        <el-form-item label="监控项名称:"
                      label-width="120px">
          <el-input v-model="model.item_name"
                    placeholder="请输入"
                    style="width:250px;
                    "
                    clearable></el-input>
        </el-form-item>
        <el-form-item label="监控项键值:"
                      label-width="120px">
          <el-input type="textarea"
                    style="width:250px;"
                    v-model="model.item_key"></el-input>

          <el-upload class="upload-demo"
                     action="http://192.168.1.2:8000/get/file/"
                     :on-preview="handlePreview"
                     :on-remove="handleRemove"
                     :before-remove="beforeRemove"
                     multiple
                     :limit="3"
                     :on-exceed="handleExceed"
                     style="float:right">

            <el-button 
                       type="primary">点击上传</el-button>
            <div slot="tip" 
                 >如果需要脚本，请上传。上传脚本文件，支持多个，只能在同级目录调用</div>
          </el-upload>

        </el-form-item>
        <el-form-item label="监控项信息类型:"
                      label-width="120px">
          <el-select v-model="model.item_data_type"
                     placeholder="信息类型"
                     style="width:180px">
            <el-option v-for="(item, $index) in value_type"
                       :key="item.value"
                       :label="item.label"
                       :value="item.value"
                       :disabled="!!item.disabled"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="监控项数据类型:"
                      label-width="120px">
          <el-select v-model="model.item_shuju_type"
                     placeholder="数据类型"
                     style="width:180px;">
            <el-option v-for="(item, $index) in data_type"
                       :key="item.value"
                       :label="item.label"
                       :value="item.value"
                       :disabled="!!item.disabled"></el-option>
          </el-select>
        </el-form-item>
          <el-form-item label="监控项单位:"
                      label-width="120px">
          <el-input v-model="model.unit"
                    placeholder="监控项单位"
                    style="width:180px;"
                    clearable></el-input>
        </el-form-item>
        <el-form-item label="监控项应用集:"
                      label-width="120px">
          <el-select v-model="model.item_application"
                     placeholder="请选择"
                     multiple
                     style="width:250px;">
            <el-option v-for="(item, $index) in application_data"
                       :key="item.applicationid"
                       :label="item.name"
                       :value="item.applicationid"
                       :disabled="!!item.disabled"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item 
                      label="描述:"
                      label-width="120px">
          <el-input type="textarea"
                    v-model="model.item_desc"></el-input>
        </el-form-item>
      </el-form>
      <span slot="footer"
            class="dialog-footer">
        <el-button @click="dialogVisible = false">取 消</el-button>
        <el-button type="primary"
                   @click="createitem()">确 定</el-button>
      </span>
    </el-dialog>
    <el-dialog
              title="提示"
              :visible.sync="deletedialogVisible"
              :before-close="handleClose"
            >
              <span>请确认是否删除。</span>
              <div 
              style="margin-top:30px;">
                  <el-button @click="deletedialogVisible = false">取消</el-button>
                  <el-button type="primary" @click="deleteEdit()"
                    >确定</el-button
                  >
              </div>
            </el-dialog>
  </div>
</template>

<script>
import cons from "@/components/constant";
import {getitemdata,deleteitem} from "@/api/item.js"
import {getapplication} from "@/api/application.js"
export default {
  data () {
    return {
      tabledata: [],
      dialogVisible: false,
      search: "",
      value: '100',

      //删除dialog
      deletedialogVisible: false, //dialog显示
      temp2:"",//记录所选中的数据id
      param: {
        currentPage: 1, // 当前页
        pagesize: 5, // 默认每页多少张
        hostid: ''
      },
      total: 0, // 共多少页
      join: null,
      forms: ["$form"],
      model: {
        'unit':''
      },
      value_type: [{
        value: 0,
        label: "numeric float"
      }, {
        value: 1,
        label: "character"
      }, {
        value: 2,
        label: "log"
      }, {
        value: 3,
        label: "numeric unsigned"
      }, {
        value: 4,
        label: "text"
      }
      ],
      data_type: [{
        value: 0, label: "decimal(default)"
      },
      { value: 1, label: "octal" },
      { value: 2, label: "hexadecimal" },
      { value: 3, label: "boolean" }

      ],
      application_data: null,
      submit_loading: false,
    };
  },

  mounted () {
    this.getList()
    console.log(localStorage.token)
  },

  methods: {

    //获取基本数据                                                                                                                                             
    getList(){
      let token = localStorage.token;
      const vm = this;
      vm.param.hostid = sessionStorage.getItem('hostid')
      console.log("item数据")
      console.log(vm.param);
      console.log(vm.param.hostid);
      getitemdata(this.param.hostid)
        .then((res) => {
            console.log(res)
            console.log(res.data);
            vm.total = res.data.length;
            vm.tabledata = res.data;
          
        })
        .catch((err) => {
          console.log(err);
        });
    },

    //删除指定内容
    // 删除主机
    getdelete(index, row){
      this.deletedialogVisible=true;
      this.temp2 = row.itemid;
      console.log(row.itemid)
    },
    deleteEdit() {
      let $this=this
      let loading = this.$loading({
        lock:true,
        text:"删除中，请稍候...",
        background:'rgba(0,0,0,0.5)'
      })
      deleteitem(this.temp2)
        .then((res) => {
          loading.close();
          this.getList();
          this.deletedialogVisible=false;
          this.$notify({
            title: "删除成功",
            message: "！",
            type: "success",
          });
          
        })
        .catch((err) => {
          console.log(err);
        });
    },
    //以下两个是分页功能的实现
    handleSizeChange: function (size) {
      const a = this;
      a.param.pagesize = size;
      this.getList();
      console.log(a.param.pagesize); // 每页下拉显示数据
    },
    handleCurrentChange: function (currentPage) {
      const b = this;
      b.param.currentPage = currentPage;
      console.log(this.param.currentPage); // 点击第几页
      this.getList();
    },

    //添加内容前获取基本信息
    getDate () {
      this.dialogVisible = true;
      let vm = this;
      getapplication(sessionStorage.getItem('hostid'), {
          responseType: "json",
        })
        .then((res) => {
            console.log("应用集")
            console.log(res.data);
            console.log(res);
            vm.application_data = res.data;
            // vm.host_template_data = res.data.data[1];
          
        })
        .catch((err) => {
          console.log(err);
          vm.$message.error("又出错了");
        });
    },
    handleRemove (file, fileList) {
      console.log(file, fileList);
    },
    handlePreview (file) {
      console.log(file);
    },
    //文件上传相关
    handleExceed (files, fileList) {
      this.$message.warning(`当前限制选择 1 个文件，本次选择了 ${files.length} 个文件，共选择了 ${files.length + fileList.length} 个文件`);
    },
    beforeRemove (file, fileList) {
      return this.$confirm(`确定移除 ${file.name}？`);
    },

    onBeforeUploadImage (file, fileList) {

      if (this.formData.length == 0)
      {
        this.formData = new FormData();
      }

      this.formData.append('file', file.file);
    },

    //创建监控项
    createitem () {
      this.dialogVisible = false;
      const vm = this;
      vm.model.hostid = sessionStorage.getItem('hostid')
      console.log(this.model);
      this.$http
        .post(cons.apis + "/create/item/", vm.model, {
          responseType: "json",
        })
        .then((res) => {
          if (res.data.code == 200)
          {
            // console.log(res.data.data);
            this.$notify({
              title: "恭喜你",
              message: "创建成功",
              type: "success",
            });
          }
        })
        .catch((err) => {
          console.log(err);
          this.$notify({
            title: "失败",
            message: "创建主机失败",
            type: "error",
          });
        });
    },

     /*过滤器*/
  filterHandler(value, row, column) {
        const property = column['property'];
        return row[property] === value;
      },
  //控制过滤数据
  HandeleFilterChange(filters){
    //调用时重新将全部vm信息给newdata
     this.newData = [];
     for (let p = 0; p < this.tabledata.length; p++) {
              this.newData.push(this.tabledata[p])
            }
     console.log("###@@@");
       console.log(this.tabledata)
      this.selectdata[String(Object.keys(filters))] = filters[String(Object.keys(filters))]
      console.log("###@@@1")
     console.log(this.selectdata);
      console.log("###@@@2")
     console.log(this.newData);
      //循环遍历选择数组
      for (let j = 0; j < Object.keys(this.selectdata).length; j++) {
        console.log("选择数组长度")
        console.log(this.selectdata[Object.keys(this.selectdata)[j]].length)
        //如果筛选条件只有一个
        if (this.selectdata[Object.keys(this.selectdata)[j]].length <= 1) {
          for (let k = 0; k < this.selectdata[Object.keys(this.selectdata)[j]].length; k++) {
            for (let i = 0; i < this.newData.length; i++) {
              if (this.selectdata[Object.keys(this.selectdata)[j]][k] !== this.newData[i][String(Object.keys(this.selectdata)[j])]) {
                this.newData.splice(i, 1)
                i--
              }
            }
          }
        } else {
          // 筛选条件有多个
          this.twoData = []
          for (let k = 0; k < this.selectdata[Object.keys(this.selectdata)[j]].length; k++) {
            for (let i = 0; i < this.newData.length; i++) {
              if (this.selectdata[Object.keys(this.selectdata)[j]][k] === this.newData[i][String(Object.keys(this.selectdata)[j])]) {
                this.twoData.push(this.newData[i])
              }
            }
          }
          if (this.twoData.length !== 0) {
            this.newData = []
            for (let io = 0; io < this.twoData.length; io++) {
              this.newData.push(this.twoData[io])
            }
          }
        }
      }
      console.log("###@@@$")
      console.log(this.newData)
      this.vm = this.newData
    },
    //控制关闭dialog
    handleClose(done) {
      this.$confirm("确定关闭吗")
        .then(() => {
          // function(done)，done 用于关闭 Dialog
          done();

          console.info("点击右上角 'X' ，取消按钮或遮罩层时触发");
        })
        .catch(() => {
          console.log("点击确定时触发");
        });
    },


  },
  computed: {
  table_data() {
    let search = this.search;
    // 搜索功能
    if (search){
      let list =this.tabledata.filter(data => !search || data.nickname.toLowerCase().includes(search.toLowerCase())|| data.VM_name.toLowerCase().includes(search.toLowerCase()));
      let fenye = list.slice((this.param.currentPage-1)*this.param.pagesize,this.param.currentPage*this.param.pagesize);
      // 获取查询的结果，把数组长度赋值给 分页组件中的total
      this.total = fenye.length;
      return list,fenye
    }
    // 分页功能
    else {
     //所有数据的长度  赋值给分页组件中的total
      this.total = this.tabledata.length;                        
      let fenye = this.tabledata.slice((this.param.currentPage-1)*this.param.pagesize,this.param.currentPage*this.param.pagesize)
      return fenye
    }
  }
}
};
</script>