<!-- 个人中心页面 -->
<template>
  <div>
  <el-alert title="提示:您可以在此添加触发器"
              type="info"
              show-icon
              effect="dark"
              style="margin: 25px; padding: 12px;width:96%">
    </el-alert>
    <el-card style="margin: 25px; padding: 12px">
      <el-tabs v-model="activeName" type="card" @tab-click="handleClick">
        
          <el-form
            ref="$form"
            :model="model"
            label-position="left"
            label-width="100px"
          >
            <!--触发器名称-->
            <el-form-item label="触发器名称">
              <el-input
                v-model="formData.triggername"
                placeholder="请输入"
                clearable
                prefix-icon="el-icon-user-solid"
                style="width: 50%"
              ></el-input>
            </el-form-item>

            <el-form-item label="Operational data">
              <el-input
                v-model="formData.operationaldata"
                placeholder="请输入"
                clearable
                prefix-icon="el-icon-user"
                style="width: 50%"
              ></el-input>
            </el-form-item>

            <el-form-item label="严重性">     
              <el-select v-model="formData.field101" placeholder="请选择" clearable :style="{width: '50%'}">
                <el-option v-for="(item, index) in field101Options" :key="index" :label="item.label"
                  :value="item.value" 
                  ></el-option>
              </el-select>
            </el-form-item>
              
              <el-form-item label="表达式" prop="expression">
                <el-input v-model="formData.expression" type="textarea" placeholder="请输入多行文本"
                  :autosize="{minRows: 4, maxRows: 4}" :style="{width: '50%'}"></el-input>

                <el-button
                  size="small"
                  type="primary"
                  icon="el-icon-edit-outline"
                  @click="dialogVisible=true"
                  >添 加</el-button>

              </el-form-item>

            <el-form-item prop="password" label="描述">
              <el-input v-model="formData.description" type="textarea" placeholder="请输入多行文本"
                  :autosize="{minRows: 4, maxRows: 4}" :style="{width: '50%'}"></el-input>
            </el-form-item>

            <el-row
              :gutter="20"
              type="flex"
              justify="start"
              align="top"
              tag="div"
            >
              <el-col :span="6" :offset="0" :push="0" :pull="0" tag="div">
                <el-button
                  size="small"
                  type="primary"
                  icon="el-icon-check"
                  @click="create_trigger"
                  >提 交</el-button>
                  <el-button
                  size="small"
                  icon="el-icon-refresh-left"
                  @click="forms.forEach((form) => $refs[form].resetFields())"
                  >重 置</el-button>
              </el-col>
            </el-row>
          </el-form>
        
</el-tabs>
    </el-card>

<el-dialog :visible.sync="Edit_returnData"
               title="用户详细信息">
      <el-form ref="elForm"
               :model="formData"
               :rules="rules"
               size="medium"
               label-width="200px">
        <el-form-item label="用户名称"
                      prop="username">
          <el-input v-model="formData.username"
                    clearable
                    :style="{width: '100%'}"></el-input>
        </el-form-item>
        <el-form-item label="密码"
                      prop="password">
          <el-input v-model="formData.password"
                    clearable
                    :style="{width: '100%'}"></el-input>
        </el-form-item>
        <el-form-item label="注册时间"
                      prop="enroll_time">
          <el-input v-model="formData.enroll_time"
                    clearable
                    :style="{width: '100%'}">
          </el-input>
        </el-form-item>
        <el-form-item label="邮箱"
                      prop="email">
          <el-input v-model="formData.email"
                    clearable
                    :style="{width: '100%'}"></el-input>
        </el-form-item>
        <el-form-item label="手机号码"
                      prop="phone">
          <el-input v-model="formData.phone"
                    clearable
                    :style="{width: '100%'}"></el-input>
        </el-form-item>
        <el-form-item label="备注"
                      prop="remark">
          <el-input v-model="formData.remark"
                    type="textarea"
                    :autosize="{minRows: 4, maxRows: 4}"
                    :style="{width: '100%'}"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer">
        <el-button @click="Edit_returnData = false">取消</el-button>
        <el-button type="primary"
                   @click="addserver">确定</el-button>
      </div>
    </el-dialog>
<!--新添加的关于弹窗-->
<el-dialog title="条件"
               :visible.sync="dialogVisible"
               width="40%">
      <el-form ref="$form"
               :model="model"
               label-position="left"
               label-width="100px"
               size="small">
        <el-form-item label="监控项"
                      label-width="120px">
              <el-input v-model="host_name" 
              :style="{width: '85%'}" readonly></el-input>
              <el-button @click="choice_trigger()" :style="{width: '15%'}">选择</el-button>
        </el-form-item>

        <el-form-item label="功能"
                      label-width="120px">
              <el-select v-model="item_func" placeholder="请选择" clearable :style="{width: '100%'}" >
                <el-option v-for="(item, index) in func_item" :key="index" :label="item.label"
                  :value="item.value"></el-option>
              </el-select>
        </el-form-item>

        <el-form-item prop="hostgroup_name"
                      label="结果"
                      label-width="120px">
              <el-select v-model="formData.func_choice" placeholder="请选择" clearable :style="{width: '30%'}" >
                <el-option v-for="(item, index) in resOptions" :key="index" :label="item.label"
                  :value="item.value" :disabled="item.disabled"></el-option>
              </el-select>

          <el-input v-model="model.result" 
                    clearable :style="{width: '70%'}"></el-input>

        </el-form-item>
      </el-form>
      <span slot="footer"
            class="dialog-footer">
            <el-button type="primary"
                   @click="trigger_insert()">插 入</el-button>
        <el-button @click="dialogVisible = false">取 消</el-button>
      </span>
    </el-dialog>
<!--条件里面的选择-->
<el-dialog :visible.sync="monitor_item_Visible"
               title="监控项"
               width="56%">
      <el-form ref="$form"
               :model="model"
               label-position="right"
               label-width="100px"
               size="small">         
      <el-row>
        <el-col :span="10">
          <el-form-item prop="hostgroup_name" label="群组" style="float:right">
              <el-select v-model="formData.choice_group"  clearable :style="{width: '100%'}">
                <el-option v-for="(item, index) in host_group" :key="index" :label="item.name"
                  :value="item.groupid" @click.native="group_click(item)"></el-option>
              </el-select>
        </el-form-item>   
        </el-col>
        <el-col :span="10">
          <el-form-item prop="hostgroup_name" label="主机" style="float:right">
              <el-select v-model="formData.choice_host"  clearable :style="{width: '100%'}" >
                <el-option v-for="(item, index) in host_bygroup" :key="index" :label="item.name"
                  :value="item.groupid" @click.native="host_click(item)"></el-option>
              </el-select>
        </el-form-item>  
        </el-col>
      </el-row>           
        </el-form>     
      <el-table :data="
          tableData.filter(
            (data) =>
              !search ||
              data.name.toLowerCase().includes(search.toLowerCase()) ||
              data.key_.toLowerCase().includes(search.toLowerCase()) ||
              data.state.toLowerCase().includes(search.toLowerCase())
          )
        "
                style="width: 100%"
                stripe @cell-click="hellotest">
        <el-table-column type="index"
                         width="50">
        </el-table-column>
        <el-table-column label="名称"
                         prop="name"
                         align="center">
        </el-table-column>
        <el-table-column label="键值"
                         prop="key_"
                         align="center">
        </el-table-column>

        <el-table-column label="状态"
                         prop="state"
                         align="center">
        </el-table-column>

      </el-table>
      <div slot="footer">
        <el-button @click="monitor_item_Visible = false">取消</el-button>
      </div>
    </el-dialog>
  </div>
</template>


<script>
import cons from "@/components/constant";
import store from "@/store";
import echarts from "echarts";
export default {
  data() {
    return {
      //条件里面的监控项选择按钮
      monitor_item_Visible: false,
      //新添加的
      dialogVisible: false,
      activeName: "first",
      //条件里面的监控项
      host_name: "",
      host_key: "",
      //条件里面的功能
      item_func: "last()",
      hosttmp: "",
      forms: ["$form"],
      model: {
        avatar: "",
        username: "",
        password: "",
        join_time: "",
        tel: "",
        //添加触发器那个表达式框边上的添加按钮，会弹出来弹框，然后里面有个结果的项，这个就是记录那个的
        result: 0,
      },
      value1: true,
      tableData: [],
      myScripts: [],
      search: "",
      join: null,
      status: true,
      visable: false,
      chartLine: null,
      Edit_returnData:false,
      formData:{
        username:"",
        password:"",
        email:"",
        phone:"",
        remark:"",
        enroll_time:"",
        //新添加的关于下拉框的
        field101: 1,
        expression: undefined,
        description: undefined,
        res_choice: 1,
        func_choice:1,
        //条件里面的监控项选择主机的默认值，为了方便给它直接设置了值
        choice_group:"",
        choice_host:"",
        //监控项的默认值，可更改
        monitor_items_value:1,
        triggername: "",
        operationaldata: ""
      },


      field101Options: [{
        "label": "未分类",
        "value": 1
      }, {
        "label": "信息",
        "value": 2
      },{
        "label":"警告",
        "value": 3
      },{
        "label":"一般严重",
        "value": 4
      },{
        "label":"严重",
        "value": 5
      },{
        "label":"灾难",
        "value": 6
      }],

      monitor_items: [{
        "label": "监控项一",
        "value": 1
      }, {
        "label": "监控项二",
        "value": 2
      },{
        "label":"监控项三",
        "value": 3
      },{
        "label":"监控项四",
        "value": 4
      },{
        "label":"监控项五",
        "value": 5
      },{
        "label":"监控项六",
        "value": 6
      }],

      resOptions: [{
        "label": "=",
        "value": 1
      }, {
        "label": "<>",
        "value": 2
      },{
        "label":">",
        "value": 3
      },{
        "label":"<",
        "value": 4
      },{
        "label":">=",
        "value": 5
      },{
        "label":"<=",
        "value": 6
      }],

      func_item:[{
        "label": "abschange()-后一个值与前一个值变动的绝对值。",
        "value": "abschange()"
      },{
        "label": "avg()-周期T内的平均值",
        "value": "avg()"
      },{
        "label":"band()-将最近的T值和掩码进行按位与运算",
        "value": "band()"
      },{
        "label": "change()-最新值和前一个值的差异",
        "value": "change()"
      },{
        "label": "count()-对于周期T，成功检索的值V（其满足运算符 O）的数量",
        "value": "count()"
      },{
        "label": "data()-当前周期",
        "value": "data()"
      },{
        "label": "dayofmonth()-当前是本月的第几天",
        "value": "dayofmonth()"
      },{
        "label": "dayofweek()-当前是本周的第几天",
        "value": "dayofweek()"
      },{
        "label": "delta()-周期内的MAX和MIN值之间的差异",
        "value": "delta()"
      },{
        "label": "diff()-最后一个值和前一个值之间的差异（1-true，0-false）",
        "value": "diff()"
      },{
        "label": "forecast()-基于周期T预测下一个t秒",
        "value": "forecast()"
      },{
        "label":"fuzzytime()-监控项值的时间戳和zabbix服务器时间戳之间的差异小于或等于T秒（1-true，0-false）",
        "value": "fuzzytime()"
      },{
        "label": "iregexp()-周期T内，最后的值与正则表达式V匹配（不区分大小写，1-匹配，0-不匹配）",
        "value": "iregexp()"
      },{
        "label": "last()-最后（最近）的T值",
        "value": "last()"
      },{
        "label": "logeventid()-与正则表达式T匹配的最后一个日志条目的时间ID(1-匹配，0-不匹配)",
        "value": "logeventid()"
      },{
        "label": "logseverity()-最后一个日志条目的日志严重性",
        "value": "logseverity()"
      },{
        "label": "logsource()-最后一个日志条目匹配参数T的日志源（1-匹配，0-不匹配）",
        "value": "logsource()"
      },{
        "label": "max()-周期T内的最大值",
        "value": "max()"
      },{
        "label": "min()-周期T内的最小值",
        "value": "min()"
      },{
        "label": "nodata()-在周期T内没有收到数据（1-true，0-false）",
        "value": "nodata()"
      },{
        "label": "now()-UNIX时间",
        "value": "now()"
      },{
        "label": "percentile()-周期T内的百分位数P",
        "value": "percentile()"
      },{
        "label": "prev()-前一个值",
        "value": "prev()"
      },{
        "label": "regexp()-在周期T内，将最后的值与正则表达式V匹配（1-匹配，0-不匹配）",
        "value": "regexp()"
      },{
        "label": "str()-在最后（最近）值中找到字符串V(1-找到，0-未找到)",
        "value": "str()"
      },{
        "label": "strlen()-最后一个（最近的）T值的长度（以字符为单位）",
        "value": "strlen()"
      },{
        "label": "sum()-周期T内的值之和",
        "value": "sum()"
      },{
        "label": "time()-当前时间",
        "value": "time()"
      },{
        "label": "timeleft()-基于周期T内达到阈值的时间估计",
        "value": "timeleft()"
      }],
      host_group: [],
      host_bygroup: [],

      rules: {

        expression: [{
          required: true,
          message: '请输入多行文本',
          trigger: 'blur'
        }],

        field101: [{
          required: true,
          message: '请选择下拉选择',
          trigger: 'change'
        }],

        ip: [{
          required: true,
          message: '请输入ip地址',
          trigger: 'blur'
        }],
        port: [{
          required: true,
          message: '请输入端口号',
          trigger: 'blur'
        }],
        master: [{
          required: true,
          message: '请输入用户名',
          trigger: 'blur'
        }],
        remark: [{
          required: true,
          message: '请输入备注',
          trigger: 'blur'
        }],
        server_name: [{
          required: true,
          message: '请输入用户名',
          trigger: 'blur'
        }],
        passwd: [{
          required: true,
          message: '请输入密码',
          trigger: 'blur'
        }],
        owner: [],
        backend: [],
      },

    };
  },
  mounted() {
    // 获取用户个人信息
    var data = JSON.parse(window.sessionStorage.getItem("data"));
    this.model.username = data.username;
    this.model.tel = data.mobile;
    this.model.join_time = data.date_joined;
    this.model.avatar = data.avatar;
    if (data.is_superuser === true) {
      this.visable = true;
    }
  },
  methods: {
    //添加的方法
    create_trigger() {
        this.$http.post(cons.apis + "/create/trigger/?triggername=" + this.formData.triggername + "&operationaldata=" +
        this.formData.operationaldata + "&severity=" + this.field101Options[this.formData.field101-1].label + "&expression=" +
        this.formData.expression + "&description=" + this.formData.description,{
        headers: {
            //Authorization: "JWT " + token,
          },
          responseType: "json",
      }).then((res) => {
        console.log(1788)
          console.log(res)
          this.$router.push({ path: this.redirect || "/monitor/trigger/" });
      }).catch((err) => {
          console.log(9885)
      })
    },
    hellotest(row) {
      console.log(row)
      this.hosttmp = this.host_name
      this.host_name = this.host_name + ":" + row.name
      this.host_key = row.key_
      this.monitor_item_Visible = false
    },
    trigger_insert(){
      console.log("helll")
      console.log(this.formData.func_choice)
      this.formData.expression = "{" + this.hosttmp + ":" + this.host_key + "." + this.item_func + "}" + this.resOptions[this.formData.func_choice-1]['label'] + this.model.result
      this.dialogVisible = false
    },
    choice_trigger() {
      //let token = localStorage.token;
      //console.log(token)
      this.$http
        .get(cons.apis + "/get_groups/",{
          headers: {
            //Authorization: "JWT " + token,
          },
          responseType: "json",
        }).then((res) => {
          this.host_group = res.data.data,
          this.monitor_item_Visible = true
        }).catch((err) => {
          console.log(err)
        })
    },
    group_click(item){
      console.log(item.groupid)
      this.$http.get(cons.apis + "/get_hosts/?groupid=" + item.groupid,{
        headers: {
            //Authorization: "JWT " + token,
          },
          responseType: "json",
      }).then((res) => {
          console.log(res.data.data)
          this.host_bygroup = res.data.data
      }).catch((err) => {

      })
    },
    host_click(item) {
      this.host_name = item.host
      this.$http.get(cons.apis + "/get_childtriggers/?hostname=" + item.host,{
        headers: {
            //Authorization: "JWT " + token,
          },
          responseType: "json",
      }).then((res) => {
          this.tableData=res.data.data
      }).catch((err) => {

      })
    },
    submitForm() {
      this.$refs['elForm'].validate(valid => {
        if (!valid) return
        // TODO 提交表单
      })
    },
    resetForm() {
      this.$refs['elForm'].resetFields()
    },


    returnData(index,row){
      this.Edit_returnData = true
      this.formData.username=row.username
      this.formData.password=row.password
      this.formData.enroll_time=row.enroll_time
      this.formData.email=row.email
      this.formData.phone=row.phone
      this.formData.remark=row.remark
      console.log(row.username)
    },
    addserver(){},
    handleClick(tab) {
      // console.log(tab);
      console.log(tab.name);
      if (tab.name === "forth") {
        console.log(4);
        this.getList();
      } else if (tab.name === "second") {
        var data = JSON.parse(window.sessionStorage.getItem("data"));
        console.log(data.user_id);
        this.myScripts = data.user_id;
      } else if (tab.name === "third") {
        this.drawLineChart();
      }
    },

    submit() {
      Promise.all(this.forms.map((form) => this.$refs[form].validate())).then(
        () => {
          this.submit_loading = true;
          // TODO demo
          console.log(this.model);
          setTimeout(() => {
            this.submit_loading = false;
          }, 3000);
        }
      );
      var data = JSON.parse(window.sessionStorage.getItem("data"));
      var id = data.id;
      let vm = this;
      this.$http
        .put(cons.apis + "/users/" + id + "/", vm.model, {
          responseType: "json",
        })
        .then((res) => {
          // console.log(res);
          if (res.status == 200) {
            this.getList();
            this.status = true;
            this.$notify({
              title: "恭喜你",
              message: "个人信息修改成功",
              type: "success",
            });
          }
        })
        .catch((err) => err);
    },
    handleEdit(index, row) {
      
    },
    // 删除用户
    //cons.apis是192.168.43.135:8000
    //scope.$index, scope.row
    //scope.row是拿到当前行的行对象
    //scope.index是拿到当前行的id，第一个是0第二个是1...
    handleDel(index, row) {
      const vm = this;
      this.$http
        .delete(cons.apis + "/users/" + row.id + "/", {
          responseType: "json",
        })
        .then((res) => {
          // console.log(res);
          if (res.status == 204) {
            this.getList();
            this.status = true;
            this.$notify({
              title: "恭喜你",
              message: "删除用户成功",
              type: "success",
            });
          }
        })
        .catch((err) => {
          console.log(err);
        });
    },
    // 修改用户
    editUser(data) {
      const vm = this;
      this.$http
        .put(
          cons.apis + "/users/" + data.id + "/",
          {
            username: data.username,
            is_superuser: data.is_superuser,
          },
          {
            responseType: "json",
          }
        )
        .then((res) => {
          if (res.status == 200) {
            // console.log(res.data);
            this.status = true;
            this.$notify({
              title: "恭喜你",
              message: "修改用户权限成功",
              type: "success",
            });
          }
        })
        .catch((err) => {
          console.log(err);
        });
    },
    //获取数据的
    getList: function () {
      let token = localStorage.token;
      const vm = this;
      this.$http
        .get(cons.apis + "/users/", {
          headers: {
            Authorization: "JWT " + token,
          },
          responseType: "json",
        })
        .then((res) => {
          if (res.status == 200) {
            console.log("asdsad");
            console.log(res.data[0].password);
            console.log("adqad");
            // vm.total = res.data.total;
            vm.tableData = res.data;
          }
        })
        .catch((err) => {
          console.log(err);
        });
    },

    // 修改脚本共享状态
    edit_share_status(row) {
      console.log(row.is_show);
      this.$http
        .put(cons.apis + "/intelligent/" + row.id + "/", row, {
          responseType: "json",
        })
        .then((res) => {
          console.log(res);
          if (res.status == 200) {
            this.status = !this.status;
            this.$notify({
              title: "恭喜你",
              message: "修改用户权限成功",
              type: "success",
            });
          }
        })
        .catch((err) => {
          console.log(err);
        });
    },

    // 绘制图表
    drawLineChart() {
      this.chartLine = echarts.init(document.getElementById("chartLine"));
      this.chartLine.setOption({
        title: {
          text: "Line Chart",
        },
        tooltip: {
          trigger: "axis",
        },
        legend: {
          data: ["邮件营销", "联盟广告", "搜索引擎"],
        },
        grid: {
          left: "3%",
          right: "4%",
          bottom: "3%",
          containLabel: true,
        },
        xAxis: {
          type: "category",
          boundaryGap: false,
          data: ["周一", "周二", "周三", "周四", "周五", "周六", "周日"],
        },
        yAxis: {
          type: "value",
        },
        series: [
          {
            name: "邮件营销",
            type: "line",
            stack: "总量",
            data: [120, 132, 101, 134, 90, 230, 210],
          },
          {
            name: "联盟广告",
            type: "line",
            stack: "总量",
            data: [220, 182, 191, 234, 290, 330, 310],
          },
          {
            name: "搜索引擎",
            type: "line",
            stack: "总量",
            data: [820, 932, 901, 934, 1290, 1330, 1320],
          },
        ],
      });
    },
  },
};
</script>

<style>
.demo-table-expand {
  font-size: 0;
}
.demo-table-expand label {
  width: 140px;
  color: #99a9bf;
}
.demo-table-expand .el-form-item {
  margin-right: 0;
  margin-bottom: 0;
  width: 50%;
}
</style>




