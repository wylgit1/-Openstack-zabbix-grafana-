<template>
  <div>
    <el-alert
      title="提示:"
      type="info"
      show-icon
      effect="dark"
      style="margin: 25px; padding: 12px; width: 96%"
    >
    </el-alert>
    <el-card style="margin: 25px; padding: 12px">
      <el-table :data="table_data"
         ref="filterTable"  style="width: 100%">
        <el-table-column prop="VM_id" label="主机id"> </el-table-column>
        <el-table-column prop="VM_name" label="主机"> </el-table-column>
        <el-table-column 
        prop="nickname" 
        label="用户"
        :filters="usernames"
        :filter-method="filterHandler"
        > </el-table-column>
        <el-table-column 
        prop="ip" 
        label="ip地址"
        :filters="IPs"
        :filter-method="filterHandler"
        > </el-table-column> 
        <el-table-column
          prop="floating_ip"
          label="floating_ip"
        ></el-table-column>
        <el-table-column prop="image" label="镜像名称"> </el-table-column>
        <el-table-column prop="key" label="键值"> </el-table-column>
      

        <el-table-column label="操作">
          <template slot-scope="scope">
            <el-button size="mini" @click="update(scope.$index, scope.row)" type="primary"
              >修改</el-button>
            <el-dialog
              title="提示"
              :visible.sync="dialogVisible"
              :before-close="handleClose"
            >
              <span>请输入需要修改的信息</span>
              <el-form
                ref="updateVMinfo"
                :rules="rulesUpdateVM"
                :model="updateVMinfo"
                label-width="100px"
              >
                <el-form-item prop="VM_name" label="主机名">
                  <el-input v-model="updateVMinfo.VM_name"></el-input>
                </el-form-item>
                <el-form-item prop="volume" label="volume">
                  <el-input v-model="updateVMinfo.volume"></el-input>
                </el-form-item>
                <el-form-item prop="rent_time" label="租期">
                  <el-input v-model="updateVMinfo.rent_time"></el-input>
                </el-form-item>
                <el-form-item prop="flavor" label="云主机flavor">
                  <el-select
                    class="flavor"
                    v-model="updateVMinfo.flavor"
                    placeholder="flavor"
                  >
                    <el-option
                      v-for="(key, value, index) in flavor"
                      :key="index"
                      :label="key + ''"
                      :value="key"
                    >
                    </el-option>
                  </el-select>
                </el-form-item>
                <el-form-item prop="floating_ip" label="floating_ip">
                  <el-select
                    class="floating_ip"
                    v-model="updateVMinfo.floating_ip"
                    placeholder="floating_ip"
                  >
                    <el-option
                      v-for="(key, value, index) in floatingIp"
                      :key="index"
                      :label="key + ''"
                      :value="key"
                    >
                    </el-option>
                  </el-select>
                </el-form-item>
                <el-form-item>
                  <el-button @click="dialogVisible = false">取消</el-button>
                  <el-button type="primary" @click="updateEdit()"
                    >确定</el-button
                  >
                </el-form-item>
              </el-form>
              <!-- <span slot="footer" class="dialog-footer">
                <el-button @click="dialogVisible = false">取 消</el-button>
                <el-button type="primary" @click="dialogVisible = false"
                  >确 定</el-button
                >
              </span> -->
            </el-dialog>
            &nbsp;&nbsp;<el-button size="mini" @click="deleteEdit(scope.$index, scope.row)" type="danger"
              >删除</el-button
            >
          </template>
        </el-table-column>
  <el-table-column align="right"
                         >
          <template slot="header" slot-scope="scope">
            <el-input v-model="search"
                      size="mini"
                      placeholder="输入关键字搜索"
                       />
          </template>
                  </el-table-column>
      </el-table>
      <el-pagination :current-page="param.currentPage"
                     :page-sizes="[5, 10, 15, 20]"
                     :page-size="param.pagesize"
                     layout="total, sizes,prev, pager, next, jumper"
                     :total="parseInt(total)"
                     @size-change="handleSizeChange"
                     @current-change="handleCurrentChange" />
    </el-card>
  </div>
</template>

<script>
import cons from "@/components/constant";
import { deleteVM, updateVM, getVM, appointVM } from "@/api/vmManagement";
import { getMsg } from "@/api/vm_info";
import { getUsername } from "@/api/user";

export default {
  data() {
    return {
      //存放所有主机信息用以显示
      vm: [],

      /* 修改所需信息 */
      temp: "", //存放修改时所选的vmid
      designatedVM: [], //存放修改时所选当前vm信息
      dialogVisible: false, //dialog显示
      network:[],
      floatingIp: [], //存放修改时浮动ip可选信息
      flavor: [], //存放修改时flavor可选信息
      updateVMinfo: {
        VM_name: "",
        volume: "",
        rent_time: "",
        floating_ip: "",
        flavor: "",
      }, //部分修改后提交的主机信息

      /* 分页所需数据*/
      value: '100',
      param: {
        currentPage: 1, // 当前页
        pagesize: 5, // 默认每页多少张
      },
      total: 0, // 共多少页
      join: null,
      currentIndex: '',
			currentPage: 1, //初始页
			pagesize: 5, //    每页的数据

      /* 过滤器查询所需数据 */
      usernames:[],
      IPs:[{text: 'selfservice', value: 'selfservice'}, {text: 'provider', value: 'provider'}],
      // 验证规则
      rulesUpdateVM: {
        // username: [
        //   { required: true, message: '请输入用户名', trigger: 'blur' }
        // ],
        // password: [
        //   { required: true, message: '请输入用户密码', trigger: 'blur' }
        // ],
        // email: [
        //   { required: true, message: '请输入邮箱', trigger: 'blur' },
        //   {
        //     type: 'email',
        //     message: '请输入正确的邮箱地址',
        //     trigger: ['blur', 'change']
        //   }
        // ],
        
        
      },
      //查询
        search:"",
    };
  },
  mounted() {
    this.getVMMessage(); //得到所有主机信息展示在页面
    this.fetchData(); // 得到修改所需数据
    this.getUsernames();
  },
  methods: {
    //得到所有主机信息展示在页面
    getVMMessage() {
      getVM()
        .then((res) => {
          this.vm = res.data;
          this.total = res.data.length;
          console.log("######");
          console.log(res.data.length);
          console.log(this.vm);
        })
        .catch((err) => {
          console.log(err);
        });
    },

    // 删除主机
    deleteEdit(index, row) {
      let $this=this
      let loading = this.$loading({
        lock:true,
        text:"删除中，请稍候...",
        background:'rgba(0,0,0,0.5)'
      })
      deleteVM(row)
        .then((res) => {
          loading.close()
          this.getVMMessage();
          this.$notify({
            title: "删除成功",
            message: "！",
            type: "success",
          });
        })
        .catch((err) => {
          console.log(err);
        });
    },

    // ###########修改所需方法#############
    // 获得修改时所选vm的id
    update(index, row) {
      this.dialogVisible = true;
      console.log(row.id);
      this.temp = row.id;
    },
    // 获得指定主机信息
    getappointVM(row) {
      appointVM(row)
        .then((res) => {
          this.designatedVM = res.data;
          console.log("#####");
          console.log(this.designatedVM);
        })
        .catch((err) => {
          console.log(err);
        });
    },
    // 更新指定主机信息
    updateEdit() {
      // 循环遍历vm找到修改指定的vm信息
      for (let index = 0; index < this.vm.length; index++) {
        if (this.vm[index].id == this.temp) {
          this.designatedVM = this.vm[index];
        }
      }
      console.log(this.designatedVM);
      // 判断需要修改的字段
      if (this.updateVMinfo.VM_name != "")
        this.designatedVM.VM_name = this.updateVMinfo.VM_name;
      if (this.updateVMinfo.rent_time != "")
        this.designatedVM.rent_time = this.updateVMinfo.rent_time;
      if (this.updateVMinfo.flavor != "")
        this.designatedVM.flavor = this.updateVMinfo.flavor;
      if (this.updateVMinfo.floating_ip != "")
        this.designatedVM.floating_ip = this.updateVMinfo.floating_ip;
      updateVM(this.designatedVM)
        .then((res) => {
          console.log(res);
          this.dialogVisible=false;
          this.$notify({
            title: "修改成功",
            message: "！",
            type: "success",
          });
        })
        .catch((err) => {
          console.log(err);
        });
    },
    // 得到修改所需数据
    fetchData() {
      getMsg()
        .then((res) => {
          console.log(res);
          this.flavor = res["flavor"];
          this.keys = res["key"];
          this.securityGroup = res["security_group"];
          this.network = res["network"];
          this.image = res["host_image"];
          this.floatingIp = res["floating_ip"];
          //获取ip地址(network)用以过滤器查询
          this.getIP(res["network"]);
        })
        .catch((err) => {
          this.init = false;
          this.err = true;
        });
    },
    //控制关闭dialog
    handleClose(done) {
      this.$confirm("确定关闭吗")
        .then(() => {
          // function(done)，done 用于关闭 Dialog
          done();

          console.info("点击右上角 'X' ，取消按钮或遮罩层时触发");
        })
        .catch(() => {
          console.log("点击确定时触发");
        });
    },

  /* 查询相关 */
  //获取用户姓名用以过滤器查询
  getUsernames(){
    getUsername()
        .then((res) => {
          console.log("***************#@^%^");
          console.log(res);
          this.usernames=res.data;
          for (let index = 0; index < res.data.length; index++) {
            this.usernames[index].text = res.data[index].username;
            this.usernames[index].value = res.data[index].username;
          }
          console.log(this.usernames)
        })
        .catch((err) => {
          console.log(err);
        });
  },
  //获取IP错误 for循环进不去不知道为什么
  getIP(ips){     
    console.log(Object.keys(ips).length);
    let iplength=Object.keys(ips).length;
    console.log(iplength);
    for (let index = 0; index < iplength; index++) {
      this.IPs[index].text = ips[index+1];
      console.log(ips[index+1]);       
      this.IPs[index].value = ips[index+1];   
    }
    console.log("****");
    console.log(this.IPs);
  },
  /* 分页 */
    handleSizeChange: function(size) {
			this.pagesize = size;
			// console.log(this.pagesize) //每页下拉显示数据
		},
		handleCurrentChange: function(currentPage) {
			this.currentPage = currentPage;
			// console.log(this.currentPage) //点击第几页
		},

    // onAddUser() {
    //   this.$refs.addFormRef.validate(async (valid) => {
    //     if (!valid) return null; // 如果验证失败就不往下继续执行
    //     const { data: res } = await this.$http.post("users", this.addUser);
    //     if (res.meta.status !== 201) return this.$message.error(res.meta.msg);
    //     this.$message.success("添加成功");
    //     this.dialogTableVisible = false; // 关闭弹框
    //     this.$refs.addFormRef.resetFields(); // 清空表单
    //     this.getUserList(); // 重新调用，刷新表单
    //   });
    // },
     filterHandler(value, row, column) {
        const property = column['property'];
        return row[property] === value;
      }
  },
  computed: {
  table_data() {
    let search = this.search;
    // 搜索功能
    if (search){
      let list =this.vm.filter(data => !search || data.nickname.toLowerCase().includes(search.toLowerCase())|| data.VM_name.toLowerCase().includes(search.toLowerCase()));
      let fenye = list.slice((this.currentPage-1)*this.pagesize,this.currentPage*this.pagesize);
      // 获取查询的结果，把数组长度赋值给 分页组件中的total
      this.total = fenye.length;
      return list,fenye
    }
    // 分页功能
   else {
     //所有数据的长度  赋值给分页组件中的total
      this.total = this.vm.length;
                                    
      let fenye = this.vm.slice((this.currentPage-1)*this.pagesize,this.currentPage*this.pagesize)
      return fenye
    }
  }
}

};
</script>

<style>
</style>