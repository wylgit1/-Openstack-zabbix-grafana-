<template>
  <div>
    <el-alert
      title="提示:"
      type="info"
      show-icon
      effect="dark"
      style="margin: 25px; padding: 12px; width: 96%"
    >
    </el-alert>
    <el-card style="margin: 25px; padding: 12px">
      <el-table :data="table_data"
         ref="filterTable"  
         @filter-change="HandeleFilterChange"
         style="width: 100%">
      <!-- <el-table :data="securityGroup" style="width: 100%"> -->
        <el-table-column prop="VM_id" label="主机id" width="180"> </el-table-column>
        <el-table-column 
        prop="VM_name" 
        label="主机" 
        column-key="VM_name"
        :filters="vmnames"
        width="180"> </el-table-column>
        <el-table-column prop="security_group_id" label="安全组id" width="180"> </el-table-column>
        <el-table-column prop="security_group_name" label="安全组名字" width="180"> </el-table-column>
        <el-table-column prop="security_group_type" label="安全组类型" width="180"></el-table-column>
        <!-- <el-table-column align="center"
                         width="100">
          <template slot="header">
            <el-input v-model="search"
                      size="mini"
                      placeholder="输入关键字搜索" />
          </template>
                  </el-table-column> -->

        <el-table-column label="操作">
          <template slot-scope="scope">
            <el-button size="mini" @click="dialogVisible = true"
              >修改</el-button
            >

            <el-dialog
              title="提示"
              :visible.sync="dialogVisible"
              :before-close="handleClose"
            >
              <span>请输入需要修改的信息</span>
              <el-form
                ref="addFormRef"
                :rules="rulesUpdateVM"
                :model="updateVM"
                label-width="100px"
              >
                <el-form-item prop="VM_name" label="主机名">
                  <el-input v-model="updateVM.VM_name"></el-input>
                </el-form-item>
                <el-form-item prop="volume" label="volume">
                  <el-input v-model="updateVM.volume"></el-input>
                </el-form-item>
                <el-form-item prop="rent_time" label="租期">
                  <el-input v-model="updateVM.rent_time"></el-input>
                </el-form-item>
                <el-form-item prop="flavor" label="flavor">
                  <el-input v-model="updateVM.flavor"></el-input>
                </el-form-item>
                 <el-form-item prop="floating_ip" label="浮动ip">
                  <el-input v-model="updateVM.floating_ip"></el-input>
                </el-form-item>
                <el-form-item>
                  <el-button @click="dialogVisible = false">取消</el-button>
                  <el-button type="primary" @click="onAddUser">确定</el-button>
                </el-form-item>
              </el-form>
              <!-- <span slot="footer" class="dialog-footer">
                <el-button @click="dialogVisible = false">取 消</el-button>
                <el-button type="primary" @click="dialogVisible = false"
                  >确 定</el-button
                >
              </span> -->
            </el-dialog>
            
            <el-button size="mini" @click="deleteEdit(scope.$index, scope.row)"
              >删除</el-button
            >
          </template>
        </el-table-column>
        <el-table-column align="right"
                         >
          <template slot="header" slot-scope="scope">
            <el-input v-model="search"
                      size="mini"
                      placeholder="输入关键字搜索"
                       />
          </template>
                  </el-table-column>
      </el-table>
      <el-pagination :current-page="param.currentPage"
                     :page-sizes="[5, 10, 15, 20]"
                     :page-size="param.pagesize"
                     layout="total, sizes,prev, pager, next, jumper"
                     :total="parseInt(total)"
                     @size-change="handleSizeChange"
                     @current-change="handleCurrentChange" />
    </el-card>
  </div>
</template>

<script>
import cons from "@/components/constant";
import { getSG , deleteSG } from "@/api/security_group"
import {  getVMname } from "@/api/vmManagement";

export default {
  data() {
    return {
      dialogVisible: false,
      // 存放所有安全组信息用以显示
      securityGroup: {
        security_group_id:"",
        VM_id:"",
        VM_name:"",
        security_group_name:"",
        security_group_type:"",
      },
      tabledata:[],
      // 换成安全组的修改 无用
      updateVM: {
        volume: "",
        rent_time:"",
        VM_name: "",
        floating_ip: "",
        flavor: "",
      },
      //查询
      search:"",
      /* 分页所需数据*/
      value: '100',
      param: {
        currentPage: 1, // 当前页
        pagesize: 5, // 默认每页多少张
      },
      total: 0, // 共多少页
      join: null,
      currentIndex: '',
			currentPage: 1, //初始页
			pagesize: 5, //    每页的数据

      /* 过滤器查询所需数据 */
      vmnames:[],
      // 验证规则
      rulesUpdateVM: {
        // username: [
        //   { required: true, message: '请输入用户名', trigger: 'blur' }
        // ],
        // password: [
        //   { required: true, message: '请输入用户密码', trigger: 'blur' }
        // ],
        // email: [
        //   { required: true, message: '请输入邮箱', trigger: 'blur' },
        //   {
        //     type: 'email',
        //     message: '请输入正确的邮箱地址',
        //     trigger: ['blur', 'change']
        //   }
        // ],
      },
    };
  },
  mounted() {
    this.getSGMessage();
    this.getVMnames(); //得到创建时需要显示的所有虚拟机名字
  },
  methods: {
    // 得到所有安全组信息
    getSGMessage() {
          getSG()
        .then((res) => {
          this.tabledata=res.data;//过滤器查询用
          this.securityGroup = res.data;         
        })
        .catch((err) => {
          console.log(err);
        });
    },
    // dialog控制关闭
    handleClose(done) {
      this.$confirm("确定关闭吗")
        .then(() => {
          // function(done)，done 用于关闭 Dialog
          done();

          console.info("点击右上角 'X' ，取消按钮或遮罩层时触发");
        })
        .catch(() => {
          console.log("点击确定时触发");
        });
    },
    //删除安全组
    deleteEdit(index, row) {
      let $this=this
      let loading = this.$loading({
        lock:true,
        text:"删除中，请稍候...",
        background:'rgba(0,0,0,0.5)'
      })
      deleteSG(row)
        .then((res) => {
          loading.close();
          this.getSGMessage();
          // this.deletedialogVisible=false;
          this.$notify({
            title: "删除成功",
            message: "！",
            type: "success",
          });
          
        })
        .catch((err) => {
          console.log(err);
        });
    },
    //得到所有虚拟机名字
    getVMnames() {
      // let _this = this
      getVMname()
        .then((res) => {
          let VM_names = res.data;
          console.log("##@@")
          console.log(VM_names[0]);
          this.vmnames=res.data;
          console.log(this.vmnames)
          for (let index = 0; index < res.data.length; index++) {
            this.vmnames[index].text = res.data[index].VM_name;
            this.vmnames[index].value = res.data[index].VM_name;
          }
          console.log(this.vmnames)
        })
        .catch((err) => {
          console.log(err);
        });
    },

     /* 分页 */
    handleSizeChange: function(size) {
			this.pagesize = size;
			// console.log(this.pagesize) //每页下拉显示数据
		},
		handleCurrentChange: function(currentPage) {
			this.currentPage = currentPage;
			// console.log(this.currentPage) //点击第几页
		},

    //过滤器
    filterHandler(value, row, column) {
        const property = column['property'];
        return row[property] === value;
      },
     //控制过滤数据
    HandeleFilterChange(filters){
    //调用时重新将全部ss信息给newdata
     this.newData = [];
     for (let p = 0; p < this.tabledata.length; p++) {
              this.newData.push(this.tabledata[p])
     }
      this.selectdata[String(Object.keys(filters))] = filters[String(Object.keys(filters))]
      console.log("选择数组")
     console.log(this.selectdata);
      //循环遍历选择数组
      for (let j = 0; j < Object.keys(this.selectdata).length; j++) {
        //如果筛选条件只有一个
        if (this.selectdata[Object.keys(this.selectdata)[j]].length <= 1) {
          for (let k = 0; k < this.selectdata[Object.keys(this.selectdata)[j]].length; k++) {
            for (let i = 0; i < this.newData.length; i++) {
              if (this.selectdata[Object.keys(this.selectdata)[j]][k] !== this.newData[i][String(Object.keys(this.selectdata)[j])]) {
                this.newData.splice(i, 1)
                i--
              }
            }
          }
        } else {
          // 筛选条件有多个
          this.twoData = []
          for (let k = 0; k < this.selectdata[Object.keys(this.selectdata)[j]].length; k++) {
            for (let i = 0; i < this.newData.length; i++) {
              if (this.selectdata[Object.keys(this.selectdata)[j]][k] === this.newData[i][String(Object.keys(this.selectdata)[j])]) {
                this.twoData.push(this.newData[i])
              }
            }
          }
          if (this.twoData.length !== 0) {
            this.newData = []
            for (let io = 0; io < this.twoData.length; io++) {
              this.newData.push(this.twoData[io])
            }
          }
        }
      }
      console.log("###@@@$")
      console.log(this.newData)
      this.SS = this.newData
    },



    onAddUser() {
      this.$refs.addFormRef.validate(async (valid) => {
        if (!valid) return null; // 如果验证失败就不往下继续执行
        const { data: res } = await this.$http.post("users", this.addUser);
        if (res.meta.status !== 201) return this.$message.error(res.meta.msg);
        this.$message.success("添加成功");
        this.dialogTableVisible = false; // 关闭弹框
        this.$refs.addFormRef.resetFields(); // 清空表单
        this.getUserList(); // 重新调用，刷新表单
      });
    },
    
  },
  computed: {
  table_data() {
    let search = this.search;
    // 搜索功能
    if (search){
      let list =this.tabledata.filter(data => !search || data.security_group_name.toLowerCase().includes(search.toLowerCase())|| data.VM_name.toLowerCase().includes(search.toLowerCase()));
      let fenye = list.slice((this.currentPage-1)*this.pagesize,this.currentPage*this.pagesize);
      // 获取查询的结果，把数组长度赋值给 分页组件中的total
      this.total = fenye.length;
      return list,fenye
    }
    // 分页功能
   else {
     //所有数据的长度  赋值给分页组件中的total
      this.total = this.tabledata.length;                      
      let fenye = this.tabledata.slice((this.currentPage-1)*this.pagesize,this.currentPage*this.pagesize)
      return fenye
    }
  }
},
};
</script>

<style>
</style>