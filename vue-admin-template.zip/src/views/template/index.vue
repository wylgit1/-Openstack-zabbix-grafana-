<template>
  <div>
    <el-alert
      title="提示:"
      type="info"
      show-icon
      effect="dark"
      style="margin: 25px; padding: 12px; width: 96%"
    >
    </el-alert>
    <el-card style="margin: 25px; padding: 12px">
      <div slot="header">
        <div
          style="margin-left: 30px; width: 97%; height: 30px; line-height: 30px"
        >
          <el-button
            type="primary"
            size="mini"
            icon="el-icon-edit"
            plain
            style="float: left"
            @click="getadd()"
            >添加主机模板</el-button
          >
          <el-dialog
              title="提示"
              :visible.sync="createdialogVisible"
              :before-close="handleClose"
            >
              <span>请输入添加的主机模板信息</span>
              <el-form
                ref="createdata"
                :rules="rulesUpdateVM"
                :model="createdata"
                label-width="150px"
              >
                <el-form-item prop="host_template_name" label="请输入主机模板名">
                  <el-input v-model="createdata.host_template_name"></el-input>
                </el-form-item>
                <el-form-item prop="value" label="请选择主机群组">
                <el-select v-model="createdata.value"
                 clearable
                 placeholder="请选择主机群组">
                <el-option v-for="item in groups"
                   :key="item.groupid"
                   :label="item.name"
                   :value="item.groupid">
                </el-option>
                </el-select>
                </el-form-item>
            
                <!-- <el-form-item prop="group_id" label="组">
                  <el-select
                    class="flavor"
                    v-model="createdata.group_id"
                    placeholder="flavor"
                  >
                    <el-option
                      v-for="(key, value, index) in groups"
                      :key="index"
                      :label="key.name + ''"
                      :value="key.groupid"
                    >
                    </el-option>
                  </el-select>
                </el-form-item> -->
                <!-- <el-form-item prop="template_id" label="模板">
                  <el-select
                    class="template_id"
                    v-model="createdata.template_id"
                    placeholder="template_id"
                  >
                    <el-option
                      v-for="(key, value, index) in templates"
                      :key="index"
                      :label="key.name + ''"
                      :value="key.templateid"
                    >
                    </el-option>
                  </el-select>
                </el-form-item> -->
                <el-form-item>
                  <el-button @click="createdialogVisible = false">取消</el-button>
                  <el-button type="primary" @click="addTheTemplate()"
                    >确定</el-button
                  >
                </el-form-item>
              </el-form>
              <!-- <span slot="footer" class="dialog-footer">
                <el-button @click="dialogVisible = false">取 消</el-button>
                <el-button type="primary" @click="dialogVisible = false"
                  >确 定</el-button
                >
              </span> -->
            </el-dialog>
        </div>
      </div>
      <el-table :data="table_data"
         ref="filterTable"  
         @filter-change="HandeleFilterChange"
         style="width: 100%">
        <el-table-column prop="templateid" label="主机模板id"> </el-table-column>
        <el-table-column prop="name" label="主机模板名称"> </el-table-column>
        <el-table-column label="操作" width="150">
          <template slot-scope="scope">
             <el-dropdown split-button type="primary">
        更多菜单
            <el-dropdown-menu slot="dropdown">
                 <el-dropdown-item @click.native="update(scope.$index, scope.row)" >修改信息</el-dropdown-item>
                <el-dropdown-item @click.native="getdelete(scope.$index, scope.row)">删除模板</el-dropdown-item>             
                <!-- <el-dropdown-item @click.native="webshellEdit(scope.$index, scope.row)">webshell</el-dropdown-item> -->
                <!-- <span v-for="role,index in scope.row.role" :key="index">
                    <el-dropdown-item @click.native="changeMenu(scope.$index, scope.row,role.value)">{{role.value}}</el-dropdown-item>
              </span> -->
    </el-dropdown-menu>
    </el-dropdown>



            <el-dialog
              title="提示"
              :visible.sync="dialogVisible"
              :before-close="handleClose"
            >
              <span>请输入需要修改的信息</span>
              <el-form
                ref="updatehostsinfo"
                :rules="rulesUpdateVM"
                :model="updatehostsinfo"
                label-width="100px"
              >
                <el-form-item prop="host" label="主机名">
                  <el-input v-model="updatehostsinfo.host"></el-input>
                </el-form-item>
                <el-form-item prop="host_ip" label="ip地址">
                  <el-input v-model="updatehostsinfo.host_id"></el-input>
                </el-form-item>
                <el-form-item label="已启用">
                <template>
                   <!-- `checked` 为 true 或 false -->
                <el-checkbox v-model="updatehostsinfo.status">{{updatehostsinfo.status}}</el-checkbox>
                </template>
                </el-form-item>
                <el-form-item>
                  <el-button @click="dialogVisible = false">取消</el-button>
                  <el-button type="primary" @click="updateEdit()"
                    >确定</el-button
                  >
                </el-form-item>
              </el-form>
              <!-- <span slot="footer" class="dialog-footer">
                <el-button @click="dialogVisible = false">取 消</el-button>
                <el-button type="primary" @click="dialogVisible = false"
                  >确 定</el-button
                >
              </span> -->
            </el-dialog>
            <el-dialog
              title="提示"
              :visible.sync="deletedialogVisible"
              :before-close="handleClose"
            >
              <span>请确认是否删除。</span>
              <div 
              style="margin-top:30px;">
                  <el-button @click="deletedialogVisible = false">取消</el-button>
                  <el-button type="primary" @click="deleteEdit()"
                    >确定</el-button
                  >
              </div>
            </el-dialog>
            <el-dialog
              title="提示"
              :visible.sync="allocateDialogVisible"
              :before-close="handleClose"
            >
              <span>请选择给主机分配的云盘</span>
              <el-form
                ref="CVinfo"
                :rules="rulesUpdateVM"
                :model="CVinfo"
                label-width="100px"
              >
              <el-form-item prop="cloud_volume_name" label="云盘名称">
                  <el-select
                    class="cloud_volume_name"
                    v-model="CVinfo.cloud_volume_name"
                    placeholder="cloud_volume_name"
                  >
                    <el-option
                      v-for="(key, value, index) in volumenames"
                      :key="index"
                      :label="key.text"
                      :value="key.text"
                    >
                    </el-option>
                  </el-select>
                </el-form-item>
              </el-form>

              <div 
              style="margin-top:30px;">
                  <el-button @click="allocateDialogVisible = false">取消</el-button>
                  <el-button type="primary" @click="allocate()"
                    >确定</el-button
                  >
              </div>
            </el-dialog>
          </template>
        </el-table-column>
  <el-table-column align="right"
                         >
          <template slot="header" slot-scope="scope">
            <el-input v-model="search"
                      size="mini"
                      placeholder="输入关键字搜索"
                       />
          </template>
                  </el-table-column>
      </el-table>
      <el-pagination :current-page="param.currentPage"
                     :page-sizes="[5, 10, 15, 20]"
                     :page-size="param.pagesize"
                     layout="total, sizes,prev, pager, next, jumper"
                     :total="parseInt(total)"
                     @size-change="handleSizeChange"
                     @current-change="handleCurrentChange" />
    </el-card>
  </div>
</template>

<script>
import cons from "@/components/constant";
import { gettemplate,addtemplate,deletetemplate} from "@/api/template";
import {get_grp_tmp} from "@/api/hosts"
import { getMsg } from "@/api/vm_info";
import { getUsername,login } from "@/api/user";
import {  getServerVolume,getVolumename,getCV,updateCV,allocateVM,separateVM, } from "@/api/cloud_volume";

export default {
  data() {
    return {
      //存放所有主机信息用以显示
      templates: [],
      tabledata:[],
      //创建所需数据
      createdata:{
        host_template_name: null,
        value: '',
      },
      createdialogVisible:false,
      groups:[],
      templates:[],



      /* 修改所需信息 */
      checked: true,
      temp: "", //存放修改时所选的vmid
      designatedhosts: [], //存放修改时所选当前vm信息
      dialogVisible: false, //dialog显示
      network:[],
      floatingIp: [], //存放修改时浮动ip可选信息
      flavor: [], //存放修改时flavor可选信息
      updatehostsinfo: {
        host_id: "",
        host: "",
        nickname: "",
        available: "",
        status: 0,//判断主机是否启用 status=0时已启用
        host_ip:"",
      }, //部分修改后提交的主机信息
      // ifstatus:0,//判断主机是否启用 status=0时已启用
      //删除dialog
      deletedialogVisible: false, //dialog显示
      allocateDialogVisible:false,
      CVinfo:{
        cloud_volume_name:"",
      },
      /* 分页所需数据*/
      value: '100',
      param: {
        currentPage: 1, // 当前页
        pagesize: 5, // 默认每页多少张
      },
      total: 0, // 共多少页
      join: null,
      currentIndex: '',
			currentPage: 1, //初始页
			pagesize: 5, //    每页的数据

      /* 过滤器查询所需数据 */
      usernames:[],
      volumenames:[],
      IPs:[{text: 'selfservice', value: 'selfservice'}, {text: 'provider', value: 'provider'}],
      selectdata: {nickname: [], ip: []},
      newData: [],
      twoData: [],
      data: [],
      listdata: '',

      //查询
        search:"",
        
      // 验证规则
      rulesUpdateVM: {
        // username: [
        //   { required: true, message: '请输入用户名', trigger: 'blur' }
        // ],
        // password: [
        //   { required: true, message: '请输入用户密码', trigger: 'blur' }
        // ],
        // email: [
        //   { required: true, message: '请输入邮箱', trigger: 'blur' },
        //   {
        //     type: 'email',
        //     message: '请输入正确的邮箱地址',
        //     trigger: ['blur', 'change']
        //   }
        // ],
        
        
      },
      
      //菜单
      roles: [{
          id:1,
          value: '修改主机',
      },{
          id:2,
          value: '删除主机',
      },{
          id:3,
          value: 'webshell',
      },{
          id:4,
          value: '恢复快照',
      }
      ],
      roles1: [{
          id:1,
          value: '修改主机',
      },{
          id:2,
          value: '删除主机',
      },{
          id:3,
          value: 'webshell',
      },{
          id:4,
          value: '恢复快照',
      },{
          id:5,
          value: '分离云盘',
      },
      ],
      roles2: [{
          id:1,
          value: '修改主机',
      },{
          id:2,
          value: '删除主机',
      },{
          id:3,
          value: 'webshell',
      },{
          id:4,
          value: '恢复快照',
      },{
          id:5,
          value: '连接云盘',
      },
      ],

      
    };
  },
  mounted() {
    this.getTemplateMessage(); //得到所有主机模板信息展示在页面
    this.fetchData(); // 得到修改所需数据
    this.getUsernames();
    this.getVolumenames();
    this.getCloudVolume();
    localStorage.setItem('table', JSON.stringify(this.vm))
  },
  methods: {
    changeMenu(index,row,value){
        if(value=='修改'){
          this.update(index,row);
        }else if(value=='删除主机'){
          this.getdelete(index,row);
        }else if(value=='webshell'){
          this.webshellEdit(index,row);
        }else if(value=='恢复快照'){
          this.jumptoSS(index,row)
        }else if(value=='分离云盘'){
          this.separate(index,row)
        }else if(value=='连接云盘'){
          this.getallocate(index,row)
        }
    },
    //得到所有主机模板信息展示在页面
    getTemplateMessage() {
      gettemplate()
        .then((res) => {
          this.templates = res.data;
          this.tabledata=res.data;
          this.total = res.data.length;    
          // if(this.hosts.status==0){
          //   this.hosts.status="已启用";
          // }else if(this.hosts.status==1){
          //   this.hosts.status="已启用";
          // }


          console.log(this.templates);
        
    })
        .catch((err) => {
          console.log(err);
        });
    },

    getadd(index, row) {
      this.createdialogVisible = true;
      // console.log(row.id);
      // this.temp = row.id;
    },

    addTheTemplate(){
        console.log(this.createdata)
        addtemplate(this.createdata)
        .then((res) => {
            console.log(res);
            this.createdialogVisible=false;
            this.$notify({
            title: "添加成功",
            message: "！",
            type: "success",
            });
            this.getHostsMessage();
        })
        .catch((err) => {
            console.log(err);
        });
        },


    // 删除主机
    getdelete(index, row){
      this.deletedialogVisible=true;
      this.temp2 = row.templateid;
      console.log(row.templateid)
    },
    deleteEdit() {
      let $this=this
      let loading = this.$loading({
        lock:true,
        text:"删除中，请稍候...",
        background:'rgba(0,0,0,0.5)'
      })
      deletetemplate(this.temp2)
        .then((res) => {
          loading.close();
          this.getTemplateMessage();
          this.deletedialogVisible=false;
          this.$notify({
            title: "删除成功",
            message: "！",
            type: "success",
          });
          
        })
        .catch((err) => {
          console.log(err);
        });
    },
    //webshell
    webshellEdit(index, row) {
      let $this=this
      let loading = this.$loading({
        lock:true,
        text:"请稍候...",
        background:'rgba(0,0,0,0.5)'
      })
      getConsoleurl(row)
        .then((res) => {
          loading.close();
          let url=res.console.url;
          window.open(url, '_blank');
          // let url="http://controller:6080/vnc_auto.html?token="+res+"&title=qwert1(5699fa80-9caa-42fd-8a66-ac091c3a6057)";
          // window.open(url, '_blank');
        })
        .catch((err) => {
          console.log(err);
        });
    },

    
    // 得到创建所需数据
    fetchData() {
      get_grp_tmp()
        .then((res) => {
          console.log(res);
          this.groups = res["group"];
          this.templates = res["template"];
        })
        .catch((err) => {
          this.init = false;
          this.err = true;
        });
    },

    // ###########修改所需方法#############
    // 获得修改时所选vm的id
    update(index, row) {
      this.dialogVisible = true;
      console.log("打印指定修改的主机")
      console.log(row);
      console.log(row.id)
      this.temp = row.id;
      this.changethestatus(row.status);
    },
    // 获得指定主机信息
    getappointVM(row) {
      appointVM(row)
        .then((res) => {
          this.designatedhosts = res.data;
          console.log("#####");
          console.log(this.designatedhosts);
        })
        .catch((err) => {
          console.log(err);
        });
    },
    // 更新指定主机信息
    updateEdit() {
      // 循环遍历vm找到修改指定的hosts信息
      console.log(this.hosts)
      console.log(this.hosts[0].id)

      for (let index = 0; index < this.hosts.length; index++) {
        if (this.hosts[index].id == this.temp) {
          this.designatedhosts = this.hosts[index];
        }
      }
      console.log(this.designatedhosts);

      console.log("修改信息")
      console.log(this.updatehostsinfo)

      // 判断需要修改的字段
      if (this.updatehostsinfo.host_ip != "")
        this.designatedhosts.host_ip = this.updatehostsinfo.host_ip;
      if (this.updatehostsinfo.host != "")
        this.designatedhosts.host = this.updatehostsinfo.host;
      if (this.updatehostsinfo.status != this.designatedhosts.status)
        this.designatedhosts.status = this.updatehostsinfo.status + 0;
      console.log(this.designatedhosts)
      updateHosts(this.designatedhosts)
        .then((res) => {
          console.log(res);
          this.dialogVisible=false;
          this.$notify({
            title: "修改成功",
            message: "！",
            type: "success",
          });
        })
        .catch((err) => {
          console.log(err);
        });
    },
    // 判断是否启用，status等于0时已启用 等于1时停用
    changethestatus(value){
        if(value == 1){
          this.updatehostsinfo.status=true
          console.log("主机状态已启用")
          console.log(this.updatehostsinfo.status)
        }else if(value==0){
          this.updatehostsinfo.status=false
          console.log("主机状态停用")
          console.log(this.updatehostsinfo.status)
        }
    },
   
    //控制关闭dialog
    handleClose(done) {
      this.$confirm("确定关闭吗")
        .then(() => {
          // function(done)，done 用于关闭 Dialog
          done();

          console.info("点击右上角 'X' ，取消按钮或遮罩层时触发");
        })
        .catch(() => {
          console.log("点击确定时触发");
        });
    },

  /* 查询相关 */
  //获取用户姓名用以过滤器查询
  getUsernames(){
    getUsername()
        .then((res) => {
          console.log("***************#@^%^");
          console.log(res);
          this.usernames=res.data;
          for (let index = 0; index < res.data.length; index++) {
            this.usernames[index].text = res.data[index].username;
            this.usernames[index].value = res.data[index].username;
          }
          console.log(this.usernames)
        })
        .catch((err) => {
          console.log(err);
        });
  },
  //获取IP错误 for循环进不去不知道为什么
  getIP(ips){     
    console.log(Object.keys(ips).length);
    let iplength=Object.keys(ips).length;
    console.log(iplength);
    for (let index = 0; index < iplength; index++) {
      this.IPs[index].text = ips[index+1];
      console.log(ips[index+1]);       
      this.IPs[index].value = ips[index+1];   
    }
    console.log("****");
    console.log(this.IPs);
  },
  /*过滤器*/
  filterHandler(value, row, column) {
        const property = column['property'];
        return row[property] === value;
      },
  //控制过滤数据
  HandeleFilterChange(filters){
    //调用时重新将全部vm信息给newdata
     this.newData = [];
     for (let p = 0; p < this.tabledata.length; p++) {
              this.newData.push(this.tabledata[p])
            }
     console.log("###@@@");
       console.log(this.tabledata)
      this.selectdata[String(Object.keys(filters))] = filters[String(Object.keys(filters))]
      console.log("###@@@1")
     console.log(this.selectdata);
      console.log("###@@@2")
     console.log(this.newData);
      //循环遍历选择数组
      for (let j = 0; j < Object.keys(this.selectdata).length; j++) {
        console.log("选择数组长度")
        console.log(this.selectdata[Object.keys(this.selectdata)[j]].length)
        //如果筛选条件只有一个
        if (this.selectdata[Object.keys(this.selectdata)[j]].length <= 1) {
          for (let k = 0; k < this.selectdata[Object.keys(this.selectdata)[j]].length; k++) {
            for (let i = 0; i < this.newData.length; i++) {
              if (this.selectdata[Object.keys(this.selectdata)[j]][k] !== this.newData[i][String(Object.keys(this.selectdata)[j])]) {
                this.newData.splice(i, 1)
                i--
              }
            }
          }
        } else {
          // 筛选条件有多个
          this.twoData = []
          for (let k = 0; k < this.selectdata[Object.keys(this.selectdata)[j]].length; k++) {
            for (let i = 0; i < this.newData.length; i++) {
              if (this.selectdata[Object.keys(this.selectdata)[j]][k] === this.newData[i][String(Object.keys(this.selectdata)[j])]) {
                this.twoData.push(this.newData[i])
              }
            }
          }
          if (this.twoData.length !== 0) {
            this.newData = []
            for (let io = 0; io < this.twoData.length; io++) {
              this.newData.push(this.twoData[io])
            }
          }
        }
      }
      console.log("###@@@$")
      console.log(this.newData)
      this.vm = this.newData
    },
  
  /* 分页 */
    handleSizeChange: function(size) {
			this.pagesize = size;
			// console.log(this.pagesize) //每页下拉显示数据
		},
		handleCurrentChange: function(currentPage) {
			this.currentPage = currentPage;
			// console.log(this.currentPage) //点击第几页
		},

    // onAddUser() {
    //   this.$refs.addFormRef.validate(async (valid) => {
    //     if (!valid) return null; // 如果验证失败就不往下继续执行
    //     const { data: res } = await this.$http.post("users", this.addUser);
    //     if (res.meta.status !== 201) return this.$message.error(res.meta.msg);
    //     this.$message.success("添加成功");
    //     this.dialogTableVisible = false; // 关闭弹框
    //     this.$refs.addFormRef.resetFields(); // 清空表单
    //     this.getUserList(); // 重新调用，刷新表单
    //   });
    // },
    
    jumptoSS(index,row){
      console.log(row.VM_name)
       this.$router.push({
        path:"/snapshotManagement/index",
        query: { VM_name:row.VM_name}
        });
    },
    //得到所有快照信息展示在页面
    getCloudVolume() {
      getCV()
        .then((res) => {
          this.CV = res.data;
        })
        .catch((err) => {
          console.log(err);
        });
    },

     /**                        连接                       */
    //  弹出连接主机dialog
    getallocate(index, row) {
      this.allocateDialogVisible = true;
      console.log(row.VM_name);
      // 存放当前行修改的id
      this.temp = row.VM_name;
    },
    allocate(){
      let $this=this
      let loading = this.$loading({
        lock:true,
        text:"连接中，请稍候...",
        background:'rgba(0,0,0,0.5)'
      })
      // this.allocateDialogVisible = true;
      console.log(this.CVinfo.cloud_volume_name);
      // 存放当前行修改的快照id
      // 循环遍历CV找到修改指定的CV信息
      for (let index = 0; index < this.CV.length; index++) {
        if (this.CV[index].cloud_volume_name == this.CVinfo.cloud_volume_name) {
          this.designatedCV = this.CV[index];
        }
      }
      this.designatedCV.VM_name=this.temp;
      console.log(this.designatedCV);
      allocateVM(this.designatedCV)
        .then((res) => {
          console.log(res);
          // this.allocateDialogVisible=false;
          this.updateEdit(res)
          loading.close()
          this.$notify({
            title: "分配成功",
            message: "！",
            type: "success",
          });
        })
        .catch((err) => {
          console.log(err);
        });
    },

     //获取用户姓名用以过滤器查询
  getVolumenames(){
    getVolumename()
        .then((res) => {
          console.log("***************#@^%^");
          console.log(res);
          // this.volumenames=res.data;
          let volumenames=[]
          let count=0;
          console.log(this.CV);
          for (let index = 0; index < res.data.length; index++) {
            if(this.CV[index].cloud_volume_status=="available"){
            // this.volumenames[count].text = res.data[index].cloud_volume_name;
            // this.volumenames[count].value = res.data[index].cloud_volume_name;
            let name=res.data[index].cloud_volume_name
            let dict={text:name,value:name}
            this.volumenames.push(dict)
            }
          }
          console.log("***()")
          console.log(this.volumenames)
        })
        .catch((err) => {
          console.log(err);
        });
  },

    /**                        分离                       */
    //分离主机 弹出确认dialog
    separate(index, row) {
      let $this=this
      let loading = this.$loading({
        lock:true,
        text:"分离中，请稍候...",
        background:'rgba(0,0,0,0.5)'
      })
      // this.allocateDialogVisible = true;
      console.log(row.VM_name);
      // 循环遍历CV找到修改指定的CV信息
      for (let index = 0; index < this.CV.length; index++) {
        if (this.CV[index].VM_name == row.VM_name) {
          this.designatedCV = this.CV[index];
        }
      }
      console.log(this.designatedCV);
      separateVM(this.designatedCV)
        .then((res) => {
          console.log(res);
          loading.close();
          // this.allocateDialogVisible=false;
          this.updateEdit(res)
          this.$notify({
            title: "分离成功",
            message: "！",
            type: "success",
          });
        })
        .catch((err) => {
          console.log(err);
        });
    },
     // 所有操作后进行的修改云盘信息
    //  updateEdit(data) {
    //   updateCV(data)
    //     .then((res) => {
    //       console.log(res);
    //       this.allocateDialogVisible=false;
    //       this.updateDialogVisible=false;
    //     })
    //     .catch((err) => {
    //       console.log(err);
    //     });
    // },

  },
  computed: {
  table_data() {
    let search = this.search;
    // 搜索功能
    if (search){
      let list =this.vm.filter(data => !search || data.nickname.toLowerCase().includes(search.toLowerCase())|| data.VM_name.toLowerCase().includes(search.toLowerCase()));
      let fenye = list.slice((this.currentPage-1)*this.pagesize,this.currentPage*this.pagesize);
      // 获取查询的结果，把数组长度赋值给 分页组件中的total
      this.total = fenye.length;
      return list,fenye
    }
    // 分页功能
    else {
     //所有数据的长度  赋值给分页组件中的total
      this.total = this.templates.length;                        
      let fenye = this.templates.slice((this.currentPage-1)*this.pagesize,this.currentPage*this.pagesize)
      return fenye
    }
  }
}

};
</script>

<style>
</style>