<template>
  <div>
    <el-alert title="提示:您可以在添加解决方案"
              type="info"
              show-icon
              effect="dark"
              style="margin: 25px; padding: 12px;width:96%">
    </el-alert>
    <el-card style="margin: 25px; padding: 12px">
      <div slot="header">
        <div style="float:left">
          <svg t="1636694329654"
               class="icon"
               viewBox="0 0 1024 1024"
               version="1.1"
               xmlns="http://www.w3.org/2000/svg"
               p-id="3206"
               width="30"
               height="30">
            <path d="M512 512m-512 0a512 512 0 1 0 1024 0 512 512 0 1 0-1024 0Z"
                  fill="#1D75B0"
                  p-id="3207"></path>
            <path d="M713.216 462.336H310.784c-27.648 0-49.664 22.528-49.664 49.664s22.528 49.664 49.664 49.664h402.432c27.648 0 49.664-22.528 49.664-49.664s-22.528-49.664-49.664-49.664z"
                  fill="#FFFFFF"
                  p-id="3208"></path>
            <path d="M462.336 310.784v402.432c0 27.648 22.528 49.664 49.664 49.664s49.664-22.528 49.664-49.664V310.784c0-27.648-22.528-49.664-49.664-49.664s-49.664 22.528-49.664 49.664z"
                  fill="#FFFFFF"
                  p-id="3209"></path>
          </svg>
        </div>
        <div style="margin-left:30px;width:97%;height:30px;line-height:30px">
          <router-link :to="{ path: '/monitor/lead_action/'}"
                       replace>
            <el-button type="primary"
                       size="mini"
                       icon="el-icon-edit"
                       style="float:right;margin-left:5px"
                       plain>导入解决方案</el-button>
          </router-link>
        </div>
      </div>
      <iframe :src='url'
              frameborder="0"
              scrolling="auto"
              id="show-iframe"></iframe>
    </el-card>
  </div>

</template>
 
<script>
export default {
  data () {
    return {
      data: '',
      backend_url: 'http://192.168.48.10:8000/add_action/',
      url: ''
    }
  },

  mounted () {
    /**
      * iframe-宽高自适应显示
      */
    this.data = sessionStorage.getItem('data')
    this.data = JSON.parse(this.data);
    // console.log(this.data['username'])
    this.data = this.data['username']
    console.log("#@#@#@#")
    console.log(this.data)
    this.url = this.backend_url + '?username=' + this.data
    console.log(this.url)
    const oIframe = document.getElementById('show-iframe');
    const deviceWidth = document.documentElement.clientWidth;
    const deviceHeight = document.documentElement.clientHeight;
    oIframe.style.width = deviceWidth + 'px';
    oIframe.style.height = deviceHeight + 'px';
  }
}


</script>
 
<style scoped>
</style>