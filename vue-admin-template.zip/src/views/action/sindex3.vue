<!-- 动作 -->
<template>
  <div>
    <el-alert title="提示:您可以在导入解决方案"
              type="info"
              show-icon
              effect="dark"
              style="margin: 25px; padding: 12px;width:96%">
    </el-alert>
    <el-card style="margin: 25px">
      <el-menu :default-active="activeIndex"
               class="el-menu-demo"
               mode="horizontal"
               @select="handleSelect">
        <el-menu-item index="1">Action</el-menu-item>
        <el-menu-item index="2">Operations</el-menu-item>
        <!-- 恢复操作默认发送邮件通知 -->
        <!-- <el-menu-item index="3">Recovery operations</el-menu-item> -->
      </el-menu>

      <el-row :gutter="15"
              style="margin-top: 25px"
              v-show="card1">
        <el-form ref="elForm"
                 :model="formData"
                 size="medium"
                 label-width="100px">
          <el-col :span="24">
            <el-form-item label="名称"
                          prop="name">
              <el-input v-model="formData.name"
                        placeholder="请输入名称"
                        clearable
                        :style="{ width: '60%' }"></el-input>
            </el-form-item>
          </el-col>

          <el-col :span="24">
            <el-form-item label="选择主机">
              <el-select v-model="formData.host"
                         placeholder="请选择"
                         clearable
                         :style="{ width: '60%' }"
                         @change="get_trigger()">
                <el-option v-for="(item, index) in hostOptions"
                           :key="index"
                           :label="item.host"
                           :value="item.hostid"
                           :disabled="item.disabled"></el-option>
              </el-select>
            </el-form-item>
          </el-col>

          <el-col :span="5">
            <el-form-item label="条件">
              <el-input value="触发器"
                        placeholder="请输入条件"
                        readonly
                        clearable
                        :style="{ width: '100%' }">
              </el-input>
            </el-form-item>
          </el-col>
          <el-col :span="3">
            <el-form-item label-width="0">
              <el-input value="="
                        placeholder="请输入条件"
                        readonly
                        clearable
                        :style="{ width: '100%' }">
              </el-input>
            </el-form-item>
          </el-col>
          <el-col :span="5">
            <el-form-item label-width="0">
              <el-select v-model="formData.field103"
                         placeholder="请选择"
                         clearable
                         :style="{ width: '100%' }">
                <el-option v-for="(item, index) in field103Options"
                           :key="index"
                           :label="item.description"
                           :value="item.triggerid"
                           ></el-option>
                                <!-- :disabled="item.status" -->
              </el-select>
            </el-form-item>
          </el-col>
        </el-form>
      </el-row>

      <el-form ref="elForm"
               :model="formData"
               :rules="rules2"
               size="medium"
               label-width="200px"
               v-show="card2"
               style="margin-top: 30px">
        <el-form-item label="默认操作步骤持续时间"
                      prop="opt_time">
          <el-input v-model="formData.opt_time"
                    clearable
                    :style="{ width: '60%' }">
            <template slot="append">最少60s</template>
          </el-input>
        </el-form-item>
        <el-form-item label="默认接收人"
                      prop="field102">
          <el-input value="{TRIGGER.STATUS}: {TRIGGER.NAME}"
                    placeholder="请输入默认接收人"
                    readonly
                    clearable
                    :style="{ width: '60%' }">
          </el-input>
        </el-form-item>
        <el-form-item label="默认信息"
                      prop="field103">
          <el-input value='{ "Trigger status": "{TRIGGER.STATUS}", "Trigger name": "{TRIGGER.NAME}", "Trigger severity": "{TRIGGER.SEVERITY}", "Action name": "{ACTION.NAME}", "Event ID": "{EVENT.ID}", "Event value": "{EVENT.VALUE}", "Event status": "{EVENT.STATUS}",  "Event time": "{EVENT.TIME}", "Event date": "{EVENT.DATE}", "Event age": "{EVENT.AGE}", "Event acknowledgement": "{EVENT.ACK.STATUS}", "Event acknowledgement history": "{EVENT.ACK.HISTORY}", "Item values": "{ITEM.NAME1} ({HOST.NAME1}:{ITEM.KEY1}): {ITEM.VALUE1}", "Original event ID": "{EVENT.ID}}"'
                    type="textarea"
                    placeholder="请输入默认信息"
                    readonly
                    :autosize="{ minRows: 4, maxRows: 4 }"
                    :style="{ width: '60%' }"></el-input>
        </el-form-item>

        <el-form-item label="操作">
          <el-row>
            <el-col :span="5">
              <div>
                <el-button type="primary"
                           plain
                           @click="send_mess">发邮件</el-button>
              </div>
            </el-col>
            <el-col :span="5">
              <div>
                <el-button type="primary"
                           plain
                           @click="desc">具体流程</el-button>
              </div>
            </el-col>
          </el-row>
        </el-form-item>

        <!-- 发送消息的卡片 -->
        <div v-show="mess_card">
          <el-card style="margin: 35px; width: 70%">
            <div slot="header"
                 class="clearfix">
              <span>{{ action_type }}</span>
              <el-button style="float: right; padding: 3px 0"
                         type="text"
                         @click="mess_add">增加</el-button>
            </div>

            <div v-for="(item, index) in mess_list"
                 :key="index">
              <el-button style="float: right; padding: 3px 0"
                         type="text"
                         @click="mess_del">删除</el-button>

              <el-form-item label="步骤"
                            style="padding: 15px; width: 800px">
                <el-input v-model="item.step"
                          placeholder="请输入步骤"
                          clearable
                          :style="{ width: '40%' }">
                </el-input>
              </el-form-item>

              <el-form-item label="步骤持续时间"
                            style="padding: 15px; width: 800px">
                <el-input v-model="item.time"
                          placeholder="(minimum 60 seconds)"
                          clearable
                          :style="{ width: '40%' }">
                </el-input>
              </el-form-item>

              <el-form-item label="报警媒介类型"
                            style="padding: 15px; width: 800px">
                <el-select value="邮件报警"
                           v-model="item.mediatype"
                           placeholder="请选择下拉选择报警媒介类型"
                           clearable
                           :style="{ width: '40%' }">
                           <el-option
                            v-for="item in mediatypes"
                            :key="item.value"
                            :label="item.label"
                            :value="item.value">
                          </el-option>
                </el-select>
              </el-form-item>

              <el-divider><i class="el-icon-monitor"></i></el-divider>
            </div>
          </el-card>
        </div>
        <!-- 具体操作的卡片 -->
        <div v-show="desc_card">
          <el-card style="margin: 35px; width: 70%">
            <div slot="header"
                 class="clearfix">
              <span>{{ action_type }}</span>
              <el-button style="float: right; padding: 3px 0"
                         type="text"
                         @click="desc_add">增加</el-button>
            </div>

            <div v-for="(item, index) in desc_list"
                 :key="index">
              <el-button style="float: right; padding: 3px 0"
                         type="text"
                         @click="desc_del">删除</el-button>

              <el-form-item label="步骤"
                            style="padding: 15px; width: 800px">
                <el-input v-model="item.step"
                          placeholder="请输入步骤"
                          clearable
                          :style="{ width: '100%' }"></el-input>
              </el-form-item>

              <el-form-item label="步骤持续时间"
                            style="padding: 15px; width: 800px">
                <el-input v-model="item.time"
                          placeholder="(minimum 60 seconds, 0 - use action default)"
                          clearable
                          :style="{ width: '100%' }">
                </el-input>
              </el-form-item>

              <el-form-item label="目标主机"
                            style="padding: 15px; width: 800px">
                <el-select v-model="item.host"
                           placeholder="请选择主机"
                           clearable
                           :style="{ width: '100%' }"
                           @blur="get_script()">
                  <el-option v-for="(item, index) in hostOptions"
                             :key="index"
                             :label="item.host"
                             :value="item.interfaces[0].ip"
                             :disabled="item.disabled"></el-option>
                </el-select>
              </el-form-item>

              <!-- <el-form-item
                label="选择脚本"
                prop="script"
                style="padding: 15px; width: 800px"
              >
                <el-select
                  v-model="item.script"
                  placeholder="请选择下拉选择选择脚本"
                  clearable
                  :style="{ width: '70%' }"
                >
                  <el-option
                    v-for="(item, index) in scriptOptions"
                    :key="index"
                    :label="item.name"
                    :value="item.name"
                    :disabled="item.disabled"
                  ></el-option>
                </el-select>
                <el-button
                  style="margin-left: 40px"
                  @click="dialogVisible = true"
                  >编辑脚本</el-button
                >
              </el-form-item> -->

              <el-form-item label="命令"
                            style="padding: 15px; width: 800px">
                <el-input v-model="item.com"
                          placeholder="请输入命令"
                          clearable
                          type="textarea"
                          :style="{ width: '100%' }">
                </el-input>
              </el-form-item>
              <el-divider><i class="el-icon-monitor"></i></el-divider>
            </div>
          </el-card>
        </div>
        <el-row style="margin-top: 25px">
          <el-col :span="5">
            <el-form-item label=""
                          prop="submit">
              <el-button type="success"
                         size="medium"
                         @click="submitForm">
                提交
              </el-button>
            </el-form-item>
          </el-col>
          <el-col :span="5">
            <el-form-item label=""
                          prop="clear">
              <el-button type="danger"
                         size="medium"
                         @click="resetForm">
                重置
              </el-button>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
    </el-card>
    <!-- 脚本编辑 -->
    <el-dialog title="请在此粘贴秘钥"
               :visible.sync="dialogVisible"
               width="50%"
               :before-close="handleClose">
      <el-form ref="elForm3"
               :model="formData_script"
               size="medium"
               label-width="200px"
               label-position="left">
        <el-form-item label="秘钥"
                      prop="script_text">
          <el-input v-model="formData_script.script_text"
                    type="textarea"
                    placeholder="使用ctrl+v粘贴好友分享给你的秘钥"
                    :autosize="{ minRows: 4, maxRows: 4 }"
                    :style="{ width: '100%' }"></el-input>
        </el-form-item>
      </el-form>

      <span slot="footer"
            class="dialog-footer">
        <el-button @click="dialogVisible = false">取 消</el-button>
        <el-button type="primary"
                   @click="
            dialogVisible = false;
            fuzhi();
          ">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
import { getHosts} from "@/api/hosts";
import {gettrigger} from "@/api/trigger"
import cons from "@/components/constant";
import store from "@/store";
import Utils from '@/utils/crypto.js'
export default {
  data () {
    return {
      activeIndex: "1",
      formData: {
        name: undefined,
        host: undefined,
        opt_time: 120,
      },
      // 脚本
      dialogVisible: false,
      scriptOptions: null,
      formData_script: {},
      // 具体操作之消息
      mess_list: [
        {
          step: "",
          time: "",
          type: "",
        },
      ],

      // 具体操作之远程
      desc_list: [
        {
          step: "",
          time: "",
          host: "",
          script: "",
          com: "",
        },
      ],
      hostOptions: null,
      rules2: {
        opt_time: [
          {
            required: true,
            message: "",
            trigger: "blur",
          },
        ],
      },
      field103Options: null,
      card1: true,
      card2: false,
      mess_card: false,
      desc_card: false,
      action_type: "",
      sublist: {},
      mediatypes: [{
          value: '0',
          label: '所有'
        }, {
          value: '1',
          label: '邮件'
        }]
    };
  },
  components: {},

  computed: {},

  mounted () {
    this.gethost();
  },

  methods: {
    // 获取主机
    gethost () {
      let vm = this;
      getHosts()
        .then((res) => {
          // this.hosts = res.data;

          vm.hostOptions=res.data;
          // this.total = res.data.length;  
      }) 
      .catch((err) => {
            console.log(err);
          });
      },

    //获取对应主机的触发器
    get_trigger () {
      let vm = this;
      // console.log(vm.formData.host);
      gettrigger(vm.formData.host)
        .then((res) => {
          console.log("触发器数据")
          console.log(res)
          vm.field103Options=res;
          console.log(vm.field103Options);
      }) 
      .catch((err) => {
            console.log(err);
          });
      
    },

    // 菜单栏的切换
    handleSelect (key, keyPath) {
      console.log(key, keyPath);
      if (key == 1)
      {
        this.card1 = true;
        this.card2 = false;
      }
      if (key == 2)
      {
        this.card2 = true;
        this.card1 = false;
      }
    },
    // 表单提交验证
    submitForm () {
      this.$refs["elForm"].validate((valid) => {
        if (!valid) return;
        // TODO 提交表单
      });
      // 获取页面上所有的数据，全部
      this.sublist.action = this.formData;
      this.sublist.mess = this.mess_list;
      this.sublist.desc = this.desc_list;
      this.sublist.script = this.formData_script;
      // alert(this.sublist);
      let vm = this;
      let token = store.getters.token;
      this.$http
        .post(
          cons.apis + "/add/action/",
          {
            data: vm.sublist,
          },
          {
            headers: {
              Authorization: "JWT " + token,
            },
          }
        )
        .then((res) => {
          if (res.status == 200) this.$message.success("添加成功");
        })
        .catch((err) => err);
    },
    // 表单重置
    resetForm () {
      this.$refs["elForm"].resetFields();
    },
    // 发送消息卡片的展示
    send_mess () {
      this.action_type = "发送邮件";
      this.mess_card = true;
      this.desc_card = false;
    },
    // 远程命令卡片的展示
    desc () {
      this.action_type = "远程命令";
      this.desc_card = true;
      this.mess_card = false;
    },
    //发送多个通知
    mess_add () {
      this.mess_list.push({
        step: "",
        time: "",
      });
      // console.log(this.mess_list)
    },
    //删除通知
    mess_del () {
      this.mess_list.splice(-1, 1);
      // console.log(this.mess_list.length);
      if (this.mess_list.length == 0) this.mess_card = false;
    },
    //多个步骤
    desc_add () {
      this.desc_list.push({
        step: "",
        time: "",
        host: "",
        script: "",
        com: "",
      });
      console.log(this.desc_list);
    },
    //删除步骤
    desc_del () {
      this.desc_list.splice(-1, 1);
      if (this.desc_list.length == 0) this.desc_card = false;
    },
    




    
    // 关闭脚本弹窗
    handleClose (done) {
      this.$confirm("确认关闭？")
        .then((_) => {
          done();
        })
        .catch((_) => { });
    },
    //解密秘钥,给form赋予初始值
    fuzhi () {
      // 获取脚本名称，内容传递给后端
      var jiemi = Utils.decrypt(this.formData_script.script_text);
      console.log(jiemi)
      this.$http
        .get(cons.apis + "/share/jiemi/?jiemi=" + jiemi)
        .then((res) => {
          if (res.status == 200) this.$message.success("添加成功");
        })
        .catch((err) => err);
    },
    get_script () {
      let vm = this;
      this.$http
        .get(cons.apis + "/get/script/")
        .then((res) => {
          // console.log(res.data.file_list);
          vm.scriptOptions = res.data.file_list;
        })
        .catch((err) => err);
    },
  },
};
</script>
<style lang='less' scoped>
</style>