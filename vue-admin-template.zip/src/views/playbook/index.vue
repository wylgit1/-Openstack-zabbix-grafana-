<template>
  <div>
    <el-alert
      title="提示:"
      type="info"
      show-icon
      effect="dark"
      style="margin: 25px; padding: 12px; width: 96%"
    >
    </el-alert>
    <el-card style="margin: 25px; padding: 12px">
      <div slot="header">
        <div
          style="margin-left: 30px; width: 97%; height: 30px; line-height: 30px"
        >
          <el-button
            type="primary"
            size="mini"
            icon="el-icon-edit"
            plain
            style="float: left"
             @click="centerDialogVisible = true"
            >上传脚本</el-button
          >
    <el-dialog
      title="添加一个 PlayBook"
      :visible.sync="centerDialogVisible"
      width="60%"
      center>

        <el-row class="demo-autocomplete">
          <el-col :span="12">
              <div class="demo-input-suffix" style="padding-bottom: 5px">
                描述PlayBook功能
                </div>
                <el-input v-model="createdata.funcName" style="width:98%"></el-input>
              
          </el-col>
          <el-col :span="12">
              <div class="demo-input-suffix" style="padding-bottom: 5px;">
                PlayBook 文件名
              </div>
                <el-input v-model="createdata.nickName" style="width:98%"></el-input>
          </el-col>
        </el-row><br>
        <div class="demo-input-suffix" style="padding-bottom: 5px;">
          PlayBook 内容
        </div>

        <yaml-editor  v-model="createdata.playbook" />

      <span slot="footer" class="dialog-footer">
        <el-button plain size="small" @click="centerDialogVisible = false">取 消</el-button>
        <el-button type="primary" plain size="small"  @click="submit_playbook">添 加</el-button>
      </span>
    </el-dialog>
    <el-dialog
              title="提示"
              :visible.sync="selecthostdialogVisible"
              :before-close="handleClose"
            >
              <span>请输入勾选需要执行的主机</span>
              <el-table
                :data="hostlist"
                tooltip-effect="dark"
                style="width: 100%"
                @selection-change="handleSelectionChange">
                <el-table-column
                  type="selection"
                  width="65">
                </el-table-column>
                <el-table-column
                  prop="server"
                  label="主机ip"
                  width="200">
                </el-table-column>
                <el-table-column
                  prop="server_name"
                  label="用户"
                  width="200">
                </el-table-column>
              </el-table>
              <span slot="footer" class="dialog-footer">
                <el-button @click="dialogVisible = false">取 消</el-button>
                <el-button type="primary" @click="playbookexecutor()"
                  >确 定</el-button
                >
              </span>
            </el-dialog>
        </div>
      </div>
      <el-table :data="table_data"
         ref="filterTable"  
         @filter-change="HandeleFilterChange"
         style="width: 100%">
        <el-table-column prop="id" label="脚本id"> </el-table-column>
        <el-table-column prop="nickName" label="脚本名称"> </el-table-column>
        <el-table-column prop="playbook" label="playbook内容"> </el-table-column>
        <el-table-column prop="funcName" label="脚本描述"> </el-table-column>
        <el-table-column label="操作" width="150">
          <template slot-scope="scope">
             <el-dropdown split-button type="primary">
        更多菜单
            <el-dropdown-menu slot="dropdown">
                 <el-dropdown-item @click.native="showcontent(scope.$index, scope.row)" >查看内容</el-dropdown-item>
                <el-dropdown-item @click.native="getselecthost(scope.$index, scope.row)">选择主机</el-dropdown-item>             
                <!-- <el-dropdown-item @click.native="webshellEdit(scope.$index, scope.row)">webshell</el-dropdown-item> -->
                <!-- <span v-for="role,index in scope.row.role" :key="index">
                    <el-dropdown-item @click.native="changeMenu(scope.$index, scope.row,role.value)">{{role.value}}</el-dropdown-item>
              </span> -->
    </el-dropdown-menu>
    </el-dropdown>
          
            <el-dialog
              title="提示"
              :visible.sync="deletedialogVisible"
              :before-close="handleClose"
            >
              <span>请确认是否删除。</span>
              <div 
              style="margin-top:30px;">
                  <el-button @click="deletedialogVisible = false">取消</el-button>
                  <el-button type="primary" @click="deleteEdit()"
                    >确定</el-button
                  >
              </div>
            </el-dialog>
            <el-dialog
              title="提示"
              :visible.sync="allocateDialogVisible"
              :before-close="handleClose"
            >
              

              <div 
              style="margin-top:30px;">
                  <el-button @click="allocateDialogVisible = false">取消</el-button>
                  <el-button type="primary" @click="allocate()"
                    >确定</el-button
                  >
              </div>
            </el-dialog>
             <el-dialog
      title="查看PlayBook内容"
      :visible.sync="checkDialogVisible"
      width="60%"
      center>
        <div class="demo-input-suffix" style="padding-bottom: 5px;">
          PlayBook 内容
        </div>
        <yaml-editor  v-model="selectdata.playbook" />

      <span slot="footer" class="dialog-footer">
        <el-button plain size="small" @click="centerDialogVisible = false">取 消</el-button>
      </span>
    </el-dialog>
          </template>
        </el-table-column>
  <el-table-column align="right"
                         >
          <template slot="header" slot-scope="scope">
            <el-input v-model="search"
                      size="mini"
                      placeholder="输入关键字搜索"
                       />
          </template>
                  </el-table-column>
      </el-table>
      <el-pagination :current-page="param.currentPage"
                     :page-sizes="[5, 10, 15, 20]"
                     :page-size="param.pagesize"
                     layout="total, sizes,prev, pager, next, jumper"
                     :total="parseInt(total)"
                     @size-change="handleSizeChange"
                     @current-change="handleCurrentChange" />
    </el-card>
  </div>
</template>

<script>
import Axios from 'axios'
import {getplaybook,addplaybook,executeplaybook} from '@/api/playbook'
import { fetchList, getApi } from '@/api/ansibleui'
import YamlEditor from '@/components/yamlEditor'
const playbook_content = "- hosts: all\n  become: yes\n  become_method: sudo\n  gather_facts: no\n\n  tasks:\n  - name: \"install {{ package_name }}\"\n    package:\n      name: \"{{ package_name }}\"\n      state: \"{{ state | default('present') }}\"";
import cons from "@/components/constant";
export default {
  name: 'InlineEditTable',
  components: { YamlEditor },
  filters: {
      statusFilter(status) {
        const statusMap = {
          published: 'success',
          draft: 'info',
          deleted: 'danger'
        }
        return statusMap[status]
      }
    },
  data() {
    return {
      tabledata:[],
      playbooklist:[],
      hostlist:[],
      createdata:{
        playbook: playbook_content,
      },
      playbookexcutordata:{
        temp:[],
        multipleSelection:[],

      },
      selectdata:{
        playbook:''
      },
      new_playbook_desp: '',
      new_playbook_filename: '',
      playbook_content: playbook_content,
      centerDialogVisible: false,
      executorVisible: false,
      list: null,
      listLoading: true,
      listQuery: {
        page: 1,
        limit: 10
      },
     
      /* 修改所需信息 */
      checked: true,
      temp: "", //存放修改时所选的vmid
      designatedhosts: [], //存放修改时所选当前vm信息
      dialogVisible: false, //dialog显示
      network:[],
      floatingIp: [], //存放修改时浮动ip可选信息
      flavor: [], //存放修改时flavor可选信息
      updatehostsinfo: {
        host_id: "",
        host: "",
        nickname: "",
        available: "",
        status: 0,//判断主机是否启用 status=0时已启用
        host_ip:"",
      }, //部分修改后提交的主机信息
      // ifstatus:0,//判断主机是否启用 status=0时已启用
      //删除dialog
      deletedialogVisible: false, //dialog显示
      allocateDialogVisible:false,
      centerDialogVisible:false,
      selecthostdialogVisible:false,
      checkDialogVisible:false, //查看playbook内容
      /* 分页所需数据*/
      value: '100',
      param: {
        currentPage: 1, // 当前页
        pagesize: 5, // 默认每页多少张
      },
      total: 0, // 共多少页
      join: null,
      currentIndex: '',
			currentPage: 1, //初始页
			pagesize: 5, //    每页的数据

      //查询
        search:"",

      /* 过滤器查询所需数据 */
      usernames:[],
      volumenames:[],
      IPs:[{text: 'selfservice', value: 'selfservice'}, {text: 'provider', value: 'provider'}],
      selectdata: {nickname: [], ip: []},
      newData: [],
      twoData: [],
      data: [],
      listdata: '',
      
      //菜单
      roles: [{
          id:1,
          value: '修改主机',
      },{
          id:2,
          value: '删除脚本',
      },{
          id:3,
          value: 'webshell',
      },{
          id:4,
          value: '恢复快照',
      }
      ],
    };
  },
  mounted() {
    this.getList();
    this.gethostList()

  },
  methods: {
    // jumptolog(){
    //   this.$router.push({
    //     path:"/auto/taskdetail",
    //     // query: { VM_name:row.VM_name}
    //     });
    // },
    changeMenu(index,row,value){
        if(value=='选择主机'){
          this.selecthost(index,row);
        }else if(value=='删除脚本'){
          this.getdelete(index,row);
        }else if(value=='webshell'){
          this.webshellEdit(index,row);
        }else if(value=='恢复快照'){
          this.jumptoSS(index,row)
        }else if(value=='分离云盘'){
          this.separate(index,row)
        }else if(value=='连接云盘'){
          this.getallocate(index,row)
        }
    },
    submit_playbook(){
      addplaybook(this.createdata) 
    .then((res) => {
        this.centerDialogVisible=false,
        this.getList();
         this.$notify({
              title: "恭喜你",
              message: "创建剧本成功",
              type: "success",
            });
        console.log(res.data)         
      })
      .catch((err) => {
        console.log(err);
      });
    },
    getList() {
      getplaybook() 
    .then((res) => {
        this.tabledata=res.data;//过滤器查询用
        this.playbooklist = res.data;
        console.log(this.playbooklist)         
      })
      .catch((err) => {
        console.log(err);
      });
    },
    // 获得免密配置过的主机信息
    gethostList () {
      this.$http
        .get(cons.apis + "/server/", {
          responseType: "json",
        })
        .then((res) => {
          if (res.status == 200)
          {
            console.log(res.data);
            this.hostlist = res.data

          }
        })
        .catch((err) => {
          console.log(err);
        });
    },
   getselecthost(index,row){
        this.selecthostdialogVisible=true
        this.temp=row
        let $this=this
      
   },
   playbookexecutor(){
    let loading = this.$loading({
        lock:true,
        text:"执行中，请稍候...",
        background:'rgba(0,0,0,0.5)'
      })
    console.log("获得对应剧本信息")
    console.log(this.temp)
    console.log(this.multipleSelection)
    this.playbookexcutordata.temp=this.temp
    this.playbookexcutordata.multipleSelection=this.multipleSelection
    console.log(this.playbookexcutordata)
    executeplaybook(this.playbookexcutordata)
    .then((res) => {
        loading.close();
        console.log(res)   
        this.selecthostdialogVisible=false
        this.$notify({
            title: "执行成功",
            message: "！",
            type: "success",
          });
        console.log("---任务id---")
        console.log(this.temp.id)
        this.$router.push({
        path:"/log/taskdetail",
        query: { id:this.temp.id}
        });
        
      })
      .catch((err) => {
        console.log(err);
      });
   },
   //得到所选中的虚拟机信息
    handleSelectionChange(val) {
        this.multipleSelection = val;
        console.log(val)

      },

    showcontent(index,row){
      this.checkDialogVisible = true;
      console.log(row)
      this.selectdata.playbook=row.playbook;
    },
    //控制关闭dialog
    handleClose(done) {
      this.$confirm("确定关闭吗")
        .then(() => {
          // function(done)，done 用于关闭 Dialog
          done();

          console.info("点击右上角 'X' ，取消按钮或遮罩层时触发");
        })
        .catch(() => {
          console.log("点击确定时触发");
        });
    },

  
 
  /*过滤器*/
  filterHandler(value, row, column) {
        const property = column['property'];
        return row[property] === value;
      },
  //控制过滤数据
  HandeleFilterChange(filters){
    //调用时重新将全部vm信息给newdata
     this.newData = [];
     for (let p = 0; p < this.tabledata.length; p++) {
              this.newData.push(this.tabledata[p])
            }
     console.log("###@@@");
       console.log(this.tabledata)
      this.selectdata[String(Object.keys(filters))] = filters[String(Object.keys(filters))]
      console.log("###@@@1")
     console.log(this.selectdata);
      console.log("###@@@2")
     console.log(this.newData);
      //循环遍历选择数组
      for (let j = 0; j < Object.keys(this.selectdata).length; j++) {
        console.log("选择数组长度")
        console.log(this.selectdata[Object.keys(this.selectdata)[j]].length)
        //如果筛选条件只有一个
        if (this.selectdata[Object.keys(this.selectdata)[j]].length <= 1) {
          for (let k = 0; k < this.selectdata[Object.keys(this.selectdata)[j]].length; k++) {
            for (let i = 0; i < this.newData.length; i++) {
              if (this.selectdata[Object.keys(this.selectdata)[j]][k] !== this.newData[i][String(Object.keys(this.selectdata)[j])]) {
                this.newData.splice(i, 1)
                i--
              }
            }
          }
        } else {
          // 筛选条件有多个
          this.twoData = []
          for (let k = 0; k < this.selectdata[Object.keys(this.selectdata)[j]].length; k++) {
            for (let i = 0; i < this.newData.length; i++) {
              if (this.selectdata[Object.keys(this.selectdata)[j]][k] === this.newData[i][String(Object.keys(this.selectdata)[j])]) {
                this.twoData.push(this.newData[i])
              }
            }
          }
          if (this.twoData.length !== 0) {
            this.newData = []
            for (let io = 0; io < this.twoData.length; io++) {
              this.newData.push(this.twoData[io])
            }
          }
        }
      }
      console.log("###@@@$")
      console.log(this.newData)
      this.vm = this.newData
    },
  
  /* 分页 */
    handleSizeChange: function(size) {
			this.pagesize = size;
			// console.log(this.pagesize) //每页下拉显示数据
		},
		handleCurrentChange: function(currentPage) {
			this.currentPage = currentPage;
			// console.log(this.currentPage) //点击第几页
		},
  },
  computed: {
  table_data() {
    let search = this.search;
    // 搜索功能
    if (search){
      let list =this.playbooklist.filter(data => !search || data.nickname.toLowerCase().includes(search.toLowerCase())|| data.VM_name.toLowerCase().includes(search.toLowerCase()));
      let fenye = list.slice((this.currentPage-1)*this.pagesize,this.currentPage*this.pagesize);
      // 获取查询的结果，把数组长度赋值给 分页组件中的total
      this.total = fenye.length;
      return list,fenye
    }
    // 分页功能
    else {
     //所有数据的长度  赋值给分页组件中的total
      this.total = this.playbooklist.length;                        
      let fenye = this.playbooklist.slice((this.currentPage-1)*this.pagesize,this.currentPage*this.pagesize)
      return fenye
    }
  }
}

};
</script>

<style>
.edit-input {
  padding-right: 100px;
}
.cancel-btn {
  position: absolute;
  right: 15px;
  top: 10px;
}
</style>