import request from '@/utils/request'
import { Row } from 'element-ui'

export function deleteVM(row) {
    return request({
        url: 'virtual_machines/' + row.id + '/',
        method: 'delete',
    })
}
export function updateVM(data) {
    return request({
        url: 'virtual_machines/' + data.id + '/',
        method: 'put',
        data
    })
}
export function appointVM(row) {
    return request({
        url: 'virtual_machines/' + row.id + '/',
        method: 'get',
    })
}
export function getVM() {
    return request({
        url: 'virtual_machines/',
        method: 'get',
    })
}
export function getVMall() {
    return request({
        url: 'virtual_machines/',
        method: 'get',
    })
}
export function getVMname() {
    return request({
        url: 'virtual_machines/'+'?fields=VM_name',
        method: 'get',
    })
}

export function getConsoleurl(data) {
    return request({
        url: 'consoleurl/',
        method: 'post',
        data
    })
}



