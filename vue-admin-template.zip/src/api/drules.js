import request from '@/utils/request'
import { Row } from 'element-ui'

export function getdrules() {
    return request({
        url: 'get/drules/',
        method: 'get',
    })
}

export function adddrules(data) {
    return request({
        url: 'add/drules/',
        method: 'post',
        data
    })
}
export function deletedrules(data) {
    return request({
        url: 'delete/drules/',
        method: 'post',
        data
    })
}
export function updateHosts(data) {
    return request({
        url: 'hosts/' + data.id + '/',
        method: 'put',
        data
    })
}

export function get_grp_tmp() {
    return request({
        url: 'hostsinfo/',
        method: 'get',
    })
}





