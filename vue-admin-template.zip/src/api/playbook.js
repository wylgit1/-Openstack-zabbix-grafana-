import request from '@/utils/request'
import { Row } from 'element-ui'

export function getplaybook(row) {
    return request({
        url: 'playbook/',
        method: 'get',
    })
}
export function addplaybook(data) {
    return request({
        url: 'addplaybook/',
        method: 'post',
        data
    })
}
export function executeplaybook(data) {
    return request({
        url: 'executeplaybook/',
        method: 'post',
        data
    })
}
export function appointVM(row) {
    return request({
        url: 'virtual_machines/' + row.id + '/',
        method: 'get',
    })
}
export function deleteScripts(row) {
    return request({
        url: 'scripts/' + row.id + '/',
        method: 'delete',
    })
}



export function gettasklog(id) {
    return request({
        url: 'adhoclog?taskid='+ id,
        method: 'get',
    })
}

export function deltasklog(id) {
    return request({
        url: 'deletelog?taskid='+ id,
        method: 'delete',
    })
}