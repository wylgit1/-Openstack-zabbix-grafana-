import request from '@/utils/request'
import { Row } from 'element-ui'

export function getaction() {
    return request({
        url: 'get/action/',
        method: 'get',
    })
}

export function addaction(data) {
    return request({
        url: 'add/action/',
        method: 'post',
        data
    })
}
export function delaction(data) {
    return request({
        url: 'delete/action/',
        method: 'post',
        data
    })
}

export function get_grp_tmp() {
    return request({
        url: 'hostsinfo/',
        method: 'get',
    })
}





