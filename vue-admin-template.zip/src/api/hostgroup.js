import request from '@/utils/request'
import { Row } from 'element-ui'

export function getgroup() {
    return request({
        url: 'get/group/',
        method: 'get',
    })
}

export function addgroup(data) {
    return request({
        url: 'add/group/',
        method: 'post',
        data
    })
}
export function deletegroup(data) {
    return request({
        url: 'delete/group/',
        method: 'post',
        data
    })
}
export function updategroup(data) {
    return request({
        url: 'hosts/' + data.id + '/',
        method: 'put',
        data
    })
}




