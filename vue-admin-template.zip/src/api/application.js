import request from '@/utils/request'
import { Row } from 'element-ui'

export function getapplication(data) {
    return request({
        url: 'get/application/',
        method: 'post',
        data
    })
}

export function addapplication(data) {
    return request({
        url: 'add/application/',
        method: 'post',
        data
    })
}
export function deleteapplication(data) {
    return request({
        url: 'delete/application/',
        method: 'post',
        data
    })
}
export function updateHosts(data) {
    return request({
        url: 'hosts/' + data.id + '/',
        method: 'put',
        data
    })
}

export function get_grp_tmp() {
    return request({
        url: 'hostsinfo/',
        method: 'get',
    })
}





