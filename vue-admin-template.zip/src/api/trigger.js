import request from '@/utils/request'
import { Row } from 'element-ui'

//通过主机id得到主机相关的触发器
export function gettrigger(data) {
    return request({
        url: 'get/trigger/',
        method: 'post',
        data
    })
}

export function addaction(data) {
    return request({
        url: 'add/action/',
        method: 'post',
        data
    })
}
export function delaction(data) {
    return request({
        url: 'delete/action/',
        method: 'post',
        data
    })
}

export function get_grp_tmp() {
    return request({
        url: 'hostsinfo/',
        method: 'get',
    })
}





