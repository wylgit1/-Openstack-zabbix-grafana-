import request from '@/utils/request'
import { Row } from 'element-ui'

export function createHosts(data) {
    return request({
        url: 'create/host/',
        method: 'post',
        data
    })
}

export function getHosts() {
    return request({
        url: 'get/host/',
        method: 'get',
    })
}
export function deleteHosts(data) {
    return request({
        url: 'delete/host/',
        method: 'post',
        data
    })
}
export function updateHosts(data) {
    return request({
        url: 'update/host/',
        method: 'put',
        data
    })
}

export function get_grp_tmp() {
    return request({
        url: 'hostsinfo/',
        method: 'get',
    })
}


export function appointHosts(row) {
    return request({
        url: 'virtual_machines/' + row.id + '/',
        method: 'get',
    })
}

export function getVMall() {
    return request({
        url: 'virtual_machines/',
        method: 'get',
    })
}
export function getVMname() {
    return request({
        url: 'virtual_machines/'+'?fields=VM_name',
        method: 'get',
    })
}

export function getConsoleurl(data) {
    return request({
        url: 'consoleurl/',
        method: 'post',
        data
    })
}



