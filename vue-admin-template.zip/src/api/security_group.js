import request from '@/utils/request'

export function recordSG(data) {
    return request({
        url: 'security_groups/',
        method: 'post',
        data
    })
}
export function getSG() {
    return request({
        url: 'security_groups/',
        method: 'get',
    })
}
export function deleteSG(row) {
    return request({
        url: 'security_groups/'+ row.id + '/',
        method: 'delete',
    })
}