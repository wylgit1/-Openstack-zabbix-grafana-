import request from '@/utils/request'
import { Row } from 'element-ui'

export function gettemplate() {
    return request({
        url: 'get/template/',
        method: 'get',
    })
}

export function addtemplate(data) {
    return request({
        url: 'add/template/',
        method: 'post',
        data
    })
}
export function deletetemplate(data) {
    return request({
        url: 'delete/template/',
        method: 'post',
        data
    })
}
export function updateHosts(data) {
    return request({
        url: 'hosts/' + data.id + '/',
        method: 'put',
        data
    })
}

export function get_grp_tmp() {
    return request({
        url: 'hostsinfo/',
        method: 'get',
    })
}


export function appointHosts(row) {
    return request({
        url: 'virtual_machines/' + row.id + '/',
        method: 'get',
    })
}

export function getVMall() {
    return request({
        url: 'virtual_machines/',
        method: 'get',
    })
}
export function getVMname() {
    return request({
        url: 'virtual_machines/'+'?fields=VM_name',
        method: 'get',
    })
}

export function getConsoleurl(data) {
    return request({
        url: 'consoleurl/',
        method: 'post',
        data
    })
}



