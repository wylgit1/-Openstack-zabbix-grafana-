import request from '@/utils/request'
import { Row } from 'element-ui'

export function getScripts(row) {
    return request({
        url: 'scripts/',
        method: 'get',
    })
}
export function createScripts(data) {
    return request({
        url: 'addscripts/',
        method: 'post',
        data
    })
}
export function appointVM(row) {
    return request({
        url: 'virtual_machines/' + row.id + '/',
        method: 'get',
    })
}
export function deleteScripts(row) {
    return request({
        url: 'scripts/' + row.id + '/',
        method: 'delete',
    })
}

