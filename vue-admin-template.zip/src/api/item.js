import request from '@/utils/request'
import { Row } from 'element-ui'

export function getitemdata(data) {
    return request({
        url: 'get/host_item_date/',
        method: 'post',
        data
    })
}

export function additem(data) {
    return request({
        url: 'add/drules/',
        method: 'post',
        data
    })
}
export function deleteitem(data) {
    return request({
        url: 'delete/item/',
        method: 'post',
        data
    })
}
export function updateHosts(data) {
    return request({
        url: 'hosts/' + data.id + '/',
        method: 'put',
        data
    })
}

export function get_grp_tmp() {
    return request({
        url: 'hostsinfo/',
        method: 'get',
    })
}





