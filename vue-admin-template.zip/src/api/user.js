import request from '@/utils/request'

export function login(data) {
    return request({
        url: 'index/login/',
        method: 'post',
        data
    })
}

export function getInfo(token) {
    return request({
        url: 'index/info/',
        method: 'get',
    })
}

export function logout() {
    return request({
        url: '/vue-admin-template/user/logout',
        method: 'post'
    })
}

export function register(data){
    return request({
        url: 'register/',
        method: 'post',
        data
    })
}

export function getUsername(){
    return request({
        url: 'users/'+'?fields=username',
        method: 'get'
    })
}

export function getUserMsg(){
    return request({
        url: 'users/',
        method: 'get'
    })
}
export function updateUser(data) {
    return request({
        url: 'users/' + data.id + '/',
        method: 'put',
        data
    })
}

