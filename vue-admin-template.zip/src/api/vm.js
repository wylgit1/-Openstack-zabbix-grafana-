import request from '@/utils/request'

export function createVM(data) {
    return request({
        url: 'virtual_machines/',
        method: 'post',
        data
    })
}