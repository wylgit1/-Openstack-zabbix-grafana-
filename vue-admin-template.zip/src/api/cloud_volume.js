import request from '@/utils/request'

export function createCV(data) {
    return request({
        url: 'cloud_volume/',
        method: 'post',
        data
    })
}
export function getCV() {
    return request({
        url: 'cloud_volume/',
        method: 'get',
    })
}

export function updateCV(data) {
    return request({
        url: 'cloud_volume/' + data.id + '/',
        method: 'put',
        data
    })
}

export function allocateVM(data) {
    return request({
        url: 'cloud_volume/allocate/',
        method: 'post',
        data
    })
}

export function separateVM(data) {
    return request({
        url: 'cloud_volume/separate/',
        method: 'post',
        data
    })
}
export function getServerVolume(data) {
    return request({
        url: 'cloud_volume/getServerVolume/',
        method: 'post',
        data
    })
}

export function deleteCV(data) {
    return request({
        url: 'cloud_volume/'+data.id+"/",
        method: 'delete',
    })
}


export function getVolumename() {
    return request({
        url: 'cloud_volume/'+'?fields=cloud_volume_name',
        method: 'get',
    })
}