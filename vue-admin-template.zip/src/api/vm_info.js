import request from '@/utils/request'

export function getMsg(token) {
    return request({
        url: 'vminfo/',
        method: 'get',
    })
}