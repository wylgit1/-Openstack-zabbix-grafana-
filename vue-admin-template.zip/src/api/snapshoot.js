import request from '@/utils/request'

export function createSS(data) {
    return request({
        url: 'snapshoot/',
        method: 'post',
        data
    })
}
export function getSS() {
    return request({
        url: 'snapshoot/',
        method: 'get',
    })
}
export function deleteSS(row) {
    return request({
        url: 'snapshoot/' + row.id + '/',
        method: 'delete',
    })
}
export function updateSS(data) {
    return request({
        url: 'snapshoot/' + data.id + '/',
        method: 'put',
        data
    })
}

export function restoreSS(data) {
    return request({
        url: 'restoreSnapshoot/',
        method: 'put',
        data
    })
}
export function getappointedSS(data) {
    return request({
        url: 'snapshoot/'+data.id+'/',
        method: 'get',
    })
}