let cons = {
    apis: 'http://192.168.1.2:8000' // 远程地址
}
// let cons = {
//     apis: 'http://192.168.48.10:8000' // 远程地址
// }


export default cons