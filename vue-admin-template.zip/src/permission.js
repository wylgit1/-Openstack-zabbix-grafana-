import router from './router'
import store from './store'
import { Message } from 'element-ui'
import NProgress from 'nprogress' // progress bar
import 'nprogress/nprogress.css' // progress bar style
import { getToken } from '@/utils/auth' // get token from cookie
import getPageTitle from '@/utils/get-page-title'

NProgress.configure({ showSpinner: false }) // NProgress Configuration
//设置了登录拦截 白名单如下
const whiteList = ['/login','/register'] // no redirect whitelist

//路由拦截器
router.beforeEach(async(to, from, next) => {
  // start progress bar
  NProgress.start()

  // set page title
  document.title = getPageTitle(to.meta.title)

  // determine whether the user has logged in
  const hasToken = getToken()

//判断token是否存在// determine whether the user has logged in
  if (hasToken) {
    //判断是否是登录
    console.log(hasToken)

    if (to.path === '/login') {
      // if is logged in, redirect to the home page
      // if is logged in, redirect to the home page
      // 如果有登录，并且目标路径是 /login，路由到首页
      next({ path: '/' })
      console.log("####@@@")
      NProgress.done()
    } else {
      // const hasGetUserInfo = store.getters.name

      // 从vuex中获取权限
      const hasRoles = store.getters.roles!=[] && store.getters.roles.length > 0
      console.log("#####@@@@@@")
      console.log(store.getters)
      console.log("#@")
      console.log(hasRoles)


      if (hasRoles) {
        next()
      } else {
        try {
          // get user info
          // await store.dispatch('user/getInfo')

          // get user info
          // note: roles must be a object array! such as: ['admin'] or ,['developer','editor']
          // 派发user/getInfo action, 获取当前用户的角色信息
          // roles 必须是一个数组
          // 获取用户的权限信息 存到vuex里面
          const { type } = await store.dispatch('user/getInfo')
          console.log("##$$$$##")
          console.log(type)
          var roles=[]
          roles.push(type)
        
          // generate accessible routes map based on roles
          //根据用户的角色信息，派发到permission/generateRoutes action. 生成动态路由表
          const accessRoutes = await store.dispatch('permission/generateRoutes', roles)
          // dynamically add accessible routes
          // 挂载动态路由，添加到路由
          router.options.routes = store.getters.permission_routes
          router.addRoutes(accessRoutes)

          // hack method to ensure that addRoutes is complete
          // set the replace: true, so the navigation will not leave a history record
          next({ ...to, replace: true })
          // next()
        } catch (error) {
          // remove token and go to login page to re-login
          await store.dispatch('user/resetToken')
          Message.error(error.message || 'Has Error')
          next(`/login?redirect=${to.path}`)
          NProgress.done()
        }
      }
    }
  } else {
    console.log("token不存在")
    /* has no token*/
    //如果token不存在，判断是否存在白名单中
    if (whiteList.indexOf(to.path) !== -1) {
      // in the free login whitelist, go directly
      next()
    } else {
      // other pages that do not have permission to access are redirected to the login page.
      next(`/login?redirect=${to.path}`)
      NProgress.done()
    }
  }
})

router.afterEach(() => {
  // finish progress bar
  NProgress.done()
})
