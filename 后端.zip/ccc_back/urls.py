"""ccc_back URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include
from rest_framework import routers
from drf_yasg import openapi
from drf_yasg.views import get_schema_view
from rest_framework_jwt.views import obtain_jwt_token

from apps.cloud_volume.views import CloudVolumeView
from apps.monitor.hosts.views import HostsView
from apps.monitor.scripts.views import ScriptsView, PlaybooksView
from apps.security_group.views import SecurityGroupView
from apps.snapshoot.views import SnapShootView
from apps.users.views import UserView
from apps.virtual_machine.views import VMInformationView
# from apps.monitor.trigger.views import
from rest_framework.documentation import include_docs_urls
from utils.openstack_api.token import token_api
from utils.openstack_api.vm.vm_api import openstack_get_consoleurl
"""
第三方接口文档插件的配置
需要时再打开，对应打开第三方接口文档路由
"""

# schema_view = get_schema_view(
#     openapi.Info(
#         title="CMC的API接口文档",  # 必传
#         default_version='v1',  # 必传
#         description="这是CCC的接口文档",
#         terms_of_service="http://api.zengsijiu.site",
#         contact=openapi.Contact(email="1114239571@qq.com"),
#         license=openapi.License(name="guoshao"),
#     ),
#     public=True,
#     # permission_classes=(permissions.AllowAny,),   # 权限类
# )

urlpatterns = [
    path("index/login/", obtain_jwt_token),  # 通过此接口获取包含用户名和密码的令牌
    path('vminfo/', VMInformationView.as_view({'get': 'getMsg'})),  # 页面加载时获取必要的数据
    path('hostsinfo/', HostsView.as_view({'get': 'get_grp_tmp'})),  # 页面加载时获取必要的数据
    path('register/', UserView.as_view({'post': 'register'})),
    # path('virtual_machines/', VMInformationView.as_view('')),
    path('', include('apps.users.urls')),  # 这是用户的url，包含了用户信息以及登录
    path('api/', include('rest_framework.urls')),
    path('docs/', include_docs_urls(title='ccc的接口文档')),  # drf自带生成的接口文档
    path("restoreSnapshoot/", token_api.get_token),  # 通过此接口获取包含用户名和密码的令牌
    # 第三方文档路由，需要时再打开
    # path('swagger/', schema_view.with_ui('swagger', cache_timeout=0), name='schema-swagger-ui'),
    # path('redoc/', schema_view.with_ui('redoc', cache_timeout=0), name='schema-redoc'),
    path('consoleurl/',openstack_get_consoleurl),
    path('cloud_volume/',include('apps.cloud_volume.urls')),
    path('', include('apps.monitor.trigger.urls')),
    path('', include('apps.monitor.hosts.urls')),
    path('', include('apps.monitor.scripts.urls')),

]

"""这是使用了viewset视图的url注册"""
router = routers.DefaultRouter()
router.register(r'virtual_machines', VMInformationView)
router.register(r'users', UserView)
router.register(r'security_groups', SecurityGroupView)
router.register(r'snapshoot', SnapShootView)
router.register(r'cloud_volume', CloudVolumeView)
router.register(r'hosts', HostsView)
router.register(r'scripts', ScriptsView)
router.register(r'playbook', PlaybooksView)


# router.register(r'trigger', HostsView)


urlpatterns += router.urls
