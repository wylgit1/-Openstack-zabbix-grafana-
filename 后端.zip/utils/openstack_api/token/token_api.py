import requests
import json
from rest_framework import status
from django.http import HttpResponse
from rest_framework.response import Response

OS_AUTH_URL = 'http://controller'
body = {'auth': {'identity': {'methods': ['password'], 'password': {
    'user': {'domain': {'name': 'default'}, 'name': 'admin', 'password': '123456'}}},
                 'scope': {'project': {'domain': {'name': '''default'''}, 'name': 'admin'}}}}
headers = {}
headers['Content-Type'] = 'application/json'
headers['Accept'] = '*/*'


def get_token(self):
    get_token_url = OS_AUTH_URL + ':5000/v3/auth/tokens'
    result = requests.post(get_token_url, headers=headers, data=json.dumps(body)).headers['X-Subject-Token']
    print(result)
    return HttpResponse(result, status=status.HTTP_200_OK)



