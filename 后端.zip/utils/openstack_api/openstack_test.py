# """这是所有api的测试文件"""
#
# import json
# from django.http import JsonResponse
# from utils import identify
# 测试用
import os
import sys
# sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
# from common import identify

#
def openstack_get_server_volumes():
    print(identify.nova.volumes.get_server_volumes("4516c533-d232-4d12-86d0-57e8fbe68c98"))
    newvol = identify.cinder.volumes.create(name="lvm1019", volume_type="lvm", size=1)

    # print(identify.nova.volumes.get_server_volumes("fda5686f-c549-4964-b3e6-307e488f41e2"))

    # print(identify.nova.volumes.resource_class)
    # print(identify.cinder.volumes.type())
    # myvol = identify.cinder.volumes.get("f3b4435f-3a6c-4709-b233-c535714dd245")
    # print(myvol.status)
    # volume=identify.cinder.volumes.get("76a2c584-82ec-4dae-afda-d504ab0b5ffc")
    # identify.cinder.volumes.update(volume=volume, name="test1234")
    # volume.delete()
    # in -use
    # available
    # myvol = identify.cinder.volumes.create(name="test-vol", volume_type="lvm",size=1)
    # print(identify.cinder.volumes.list())

# # openstack查找host_image云主机镜像
# def openstack_query_host_image(ob):
#     # 通过novaAPI获取镜像列表imagelist
#     image_list = identify.nova.images.list()
#     print(image_list)
#     i = 1
#     image_dict = {}
#     for image in image_list:
#         imagestr = str(image)
#         print(imagestr)
#         if i <= len(image_list):
#             image_dict[i] = imagestr[8:-1]
#             i = i + 1
#     image_data = json.dumps(image_dict)
#     print(image_data)
#     print("获取OpenStack image信息的接口")
#     return JsonResponse(image_data, safe=False, json_dumps_params={"ensure_ascii": False})
#
# # openstack查找floating_ip浮动ip
# def openstack_query_floating_ip(ob):
#     # 通过novaAPI获取浮动ip列表floating_ip list
#     floatingip_list3 = identify.nova.floating_ips.list()
#     i3 = 1
#     float_dict = {}
#     for i in floatingip_list3:
#         floatingstr = str(i).split()
#         if len(floatingstr[3]) < 20:
#             floatingip = floatingstr[4]
#             float_dict[i3] = floatingip[3:-1]
#             i3 = i3 + 1
#     float_data = json.dumps(float_dict)
#     print(float_data)
#     return JsonResponse(float_data, safe=False, json_dumps_params={"ensure_ascii": False})
#
# # openstack查找flavor 云主机flavor
# # flavor是一种描述要创建的服务器的基本维度的方法，包括为使用这种风格构建的服务器分配多少cpu、ram和磁盘空间。
# def openstack_query_flavor(ob):
#     # 通过novaAPI获取flavor列表flavor list
#     flavor_list = identify.nova.flavors.list()
#     i0 = 1
#     flavor_dict = {}
#     for flavor in flavor_list:
#         flavorstr = str(flavor)
#         flavor_dict[i0] = flavorstr[9:-1]
#         i0 = i0 + 1
#     flavor_data = json.dumps(flavor_dict)
#     print(flavor_data)
#     return JsonResponse(flavor_data, safe=False, json_dumps_params={"ensure_ascii": False})
#
# # openstack查找安全组
# def openstack_query_security_group(ob):
#     # 通过novaAPI获取安全组列表security_groups list
#     sec = identify.nova.security_groups.list()
#     data = {}
#     i = 0
#     for s in sec:
#         data[i] = [s.name]
#         i += 1
#     data = json.dumps(data)
#     print(data)
#     return JsonResponse(data, safe=False, json_dumps_params={"ensure_ascii": False})
#
# # openstack查找ip
# def openstack_query_network(ob):
#     # 通过novaAPI获取ip列表networks list
#     net_list = identify.nova.networks.list()
#     i6 = 1
#     network_dict = {}
#     for network in net_list:
#         networkstr = str(network)
#         network_dict[i6] = networkstr[10:-1]
#         # print nova.networks.find(name = networkstr[10:-1])
#         i6 = i6 + 1
#     network_data = json.dumps(network_dict)
#     print(network_data)
#     return JsonResponse(network_data, safe=False, json_dumps_params={"ensure_ascii": False})
#
#
# # openstack查找key
# def openstack_query_key(ob):
#     # 通过novaAPI获取key列表key_list
#     key_list = identify.nova.keypairs.list()
#     i2 = 1
#     key_dict = {}
#     for key in key_list:
#         keystr = str(key)
#         if i2 <= len(key_list):
#             key_dict[i2] = keystr[10:-1]
#         i2 = i2 + 1
#     key_data = json.dumps(key_dict)
#     print(key_data)
#     return JsonResponse(key_data, safe=False, json_dumps_params={"ensure_ascii": False})
#
#
#
#
#
#
#
# # def openstack_update_vm(ob, data):
# #     print(data)
# #     print("这是更新虚拟机的接口")
# #
# #
# # def openstack_destroy_vm(ob, data):
# #     print(ob)
# #     print(data)
# #
# #     print("这是删除虚拟机的接口")
#
#

if __name__ == '__main__':
    # data=Scripts.objects.get(id=1)
    # print(data)
    openstack_get_server_volumes()
# openstack_query_host_image('1', '2')
# openstack_create_vm('1', '2')
# from vm.vm_api import openstack_destroy_vm


