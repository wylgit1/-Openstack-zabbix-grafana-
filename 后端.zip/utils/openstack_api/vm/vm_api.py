"""这是openstack vm的api"""
import cgi
import json
import os
import sys
import time

from django.http import JsonResponse
# from rest_framework import request
from rest_framework import request, status
from rest_framework.response import Response

from apps.virtual_machine.models import VMInformation
from apps.security_group.models import SecurityGroup
# from  import identify
from utils.openstack_api.common import identify
# 测试用
# sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
# from common import identify

from utils.openstack_api.vm_status.status_api import openstack_change_status


# 控制台
def openstack_get_consoleurl(vm):
    data = json.loads(vm.body)
    print(data)
    # ins_id=vm.POST
    ins_id = data.get('VM_id')
    print(ins_id)
    consoleurl = identify.nova.servers.get(ins_id).get_console_url('novnc')
    return JsonResponse(consoleurl, status=status.HTTP_200_OK)


# 创建虚拟机
def openstack_create_vm(ob, createdVM):
    code = 400
    # 通过novaAPI获取当前镜像data中image的镜像ID
    image = identify.nova.glance.find_image(createdVM.get('image'))
    print(createdVM.get('image'))

    # 通过novaAPI获取当前flavor的flavorID
    print(createdVM.get('flavor'))
    flavor = identify.nova.flavors.find(name=createdVM.get('flavor'))

    # 创建实例
    instance = identify.nova.servers.create(name=createdVM.get('VM_name'), image=image, flavor=flavor,
                                                key_name=createdVM.get('key'),
                                                nics=[{'net-id': identify.net_id}], disk_config="AUTO",
                                                config_drive="False")
    ins_id = instance.id
    print(ins_id)

    # 调用novaAPI获取正在创建主机的状态
    status = instance.status

    # 调用novaAPI获取正在创建主机的状态，如果状态不为"ACTIVE"，一直获取，直到状态为"ACTIVE"，执行后续操作
    count = 0
    while (status != "ACTIVE") and (count < 1000):
        count = count + 1

        instance = identify.nova.servers.get(ins_id)
        status = instance.status
        time.sleep(10)
    if status == "ACTIVE":
        state = "运行"
        code = 200

    # 调用novaAPI绑定浮动IP
    identify.nova.servers.get(ins_id).add_floating_ip(createdVM.get('floating_ip'), fixed_address=None)
    # 将openstack生成的主机id放入虚拟机信息表的VM_id字段中 修改status状态
    # vm = VMInformation.objects.get(VM_name=data.get('VM_name'))
    # vm.VM_id = ins_id
    # vm.status = status
    # vm.save()
    createdVM['VM_id'] = ins_id
    createdVM['status'] = state
    print("这是创建虚拟机的接口")
    data = {'code': code, 'data': createdVM}
    return data


# 删除虚拟机
def openstack_destroy_vm(ob, desVM):
    data = {'code': 400, }
    try:
        instance = identify.nova.servers.get(desVM.VM_id)
        SecurityGroup.objects.filter(VM_name=desVM.VM_name).delete()
        instance.delete()
        print("successful")
        data['code'] = 200
    except Exception as e:
        print(e)
    return data


# openstack查找host_image云主机镜像
def openstack_query_host_image():
    # 通过novaAPI获取镜像列表imagelist
    image_list = identify.nova.images.list()
    # print(image_list)
    i = 1
    image_dict = {}
    for image in image_list:
        imagestr = str(image)
        # print(imagestr)
        if i <= len(image_list):
            image_dict[i] = imagestr[8:-1]
            i = i + 1
    # image_data = json.dumps(image_dict)
    # print(image_data)
    print("获取OpenStack image信息的接口")
    return image_dict
    # return JsonResponse(image_data, safe=False, json_dumps_params={"ensure_ascii": False})


# openstack查找floating_ip浮动ip
def openstack_query_floating_ip():
    # 通过novaAPI获取浮动ip列表floating_ip list
    floatingip_list3 = identify.nova.floating_ips.list()
    i3 = 1
    float_dict = {}
    for i in floatingip_list3:
        floatingstr = str(i).split()
        if len(floatingstr[3]) < 20:
            floatingip = floatingstr[4]
            float_dict[i3] = floatingip[3:-1]
            i3 = i3 + 1
    # float_data = json.dumps(float_dict)
    # print(float_data)
    return float_dict
    # return JsonResponse(float_dict, safe=False, json_dumps_params={"ensure_ascii": False})


# openstack查找flavor 云主机flavor
# flavor是一种描述要创建的服务器的基本维度的方法，包括为使用这种风格构建的服务器分配多少cpu、ram和磁盘空间。
def openstack_query_flavor():
    # 通过novaAPI获取flavor列表flavor list
    flavor_list = identify.nova.flavors.list()
    i0 = 1
    flavor_dict = {}
    for flavor in flavor_list:
        flavorstr = str(flavor)
        flavor_dict[i0] = flavorstr[9:-1]
        i0 = i0 + 1
    return flavor_dict


# openstack查找安全组名字
def openstack_query_security_group():
    # 通过novaAPI获取安全组列表security_groups list
    sec = identify.nova.security_groups.list()
    data = {}
    i = 0
    for s in sec:
        data[i] = [s.name]
        i += 1
    # data = json.dumps(data)
    print(data)
    return data
    # return JsonResponse(data, safe=False, json_dumps_params={"ensure_ascii": False})


# openstack添加安全组
def openstack_record_security_group(ob, recordSG):
    # 通过novaAPI获取安全组列表security_groups list
    sec = identify.nova.security_groups.list()
    aboutVM = VMInformation.objects.filter(VM_name=recordSG.get('VM_name'))
    print(aboutVM.values())
    print(aboutVM.values()[0])
    print(aboutVM.values()[0].get('VM_id'))
    recordSG['VM_id'] = aboutVM.values()[0].get('VM_id')
    for s in sec:
        if recordSG.get('security_group_name') == s.name:
            recordSG['security_group_id'] = s.id
    # data = json.dumps(data)
    print(recordSG)
    data = {'code': 200, 'data': recordSG}
    return data
    # return JsonResponse(data, safe=False, json_dumps_params={"ensure_ascii": False})


# openstack删除安全组
def openstack_delete_security_group(ob, deleteSG):
    print(deleteSG)
    data = {'code': 400, }
    if deleteSG.VM_id != "" and deleteSG.security_group_name != "":
        ins_id = deleteSG.VM_id
        instance = identify.nova.servers.get(ins_id)
        security_group_name = deleteSG.security_group_name
        try:
            # identify.nova.security_groups.find(name = "li-xiao")
            instance.remove_security_group(security_group=security_group_name)
            print("sucessful")
        except:
            print("openstack error")
    else:
        print("fail")
    data['code'] = 200
    return data


# openstack查找ip
def openstack_query_network():
    # 通过novaAPI获取ip列表networks list
    net_list = identify.nova.networks.list()
    i6 = 1
    network_dict = {}
    for network in net_list:
        networkstr = str(network)
        network_dict[i6] = networkstr[10:-1]
        # print nova.networks.find(name = networkstr[10:-1])
        i6 = i6 + 1
    # network_data = json.dumps(network_dict)
    # print(network_data)
    return network_dict
    # return JsonResponse(network_data, safe=False, json_dumps_params={"ensure_ascii": False})


# openstack查找key
def openstack_query_key():
    # 通过novaAPI获取key列表key_list
    key_list = identify.nova.keypairs.list()
    i2 = 1
    key_dict = {}
    for key in key_list:
        keystr = str(key)
        if i2 <= len(key_list):
            key_dict[i2] = keystr[10:-1]
        i2 = i2 + 1
    # key_data = json.dumps(key_dict)
    print(key_dict)
    return key_dict
    # return JsonResponse(key_data, safe=False, json_dumps_params={"ensure_ascii": False})


# openstack修改浮动ip
def openstack_modify_ins_fip(oldMsg, newMsg):
    ins_id = newMsg.get("VM_id")
    instance = identify.nova.servers.get(ins_id)
    floating_ip = newMsg.get("floating_ip")
    old_floating_ip = oldMsg.floating_ip
    identify.nova.servers.remove_floating_ip(ins_id, old_floating_ip)
    instance.add_floating_ip(floating_ip)


# openstack修改主机名字
def openstack_modify_ins_name(data):
    ins_id = data.get("VM_id")
    new_name = data.get("VM_name")
    identify.nova.servers.update(server=ins_id, name=new_name)


# # openstack修改主机名字
# def openstack_modify_user_name(data):
#     ins_id = data.get("VM_id")
#     new_name = data.get("nickname")
#     identify.nova.servers.update(server=ins_id, name=new_name)


# 修改主机信息
def openstack_update_vm(ob, newMsg):
    oldVM = VMInformation.objects.get(VM_id=newMsg.get('VM_id'))
    # vm = VMInformation.objects.get(VM_name=data.get('VM_name'))

    # instance = identify.nova.servers.get(newMsg.get('VM_id'))
    print("##@#!#@!")
    print(newMsg)
    print(oldVM.VM_name)
    print(oldVM.floating_ip)
    print(newMsg.get("VM_name"))
    print(oldVM.status)
    print(newMsg.get("status"))
    if newMsg.get("VM_name") != oldVM.VM_name:
        openstack_modify_ins_name(newMsg)
        oldVM.VM_name=newMsg.get("VM_name")
    if newMsg.get("floating_ip") != oldVM.floating_ip:
        openstack_modify_ins_fip(oldVM, newMsg)
        oldVM.floating_ip = newMsg.get("floating_ip")
    if newMsg.get("status") != oldVM.status:
        openstack_change_status(newMsg)
        oldVM.status = newMsg.get("status")
    data = {'status': 200,'data':newMsg}
    return data


def openstack_add_security_group(ob, vm):
    ins_id = vm.get("ins_id")
    instance = identify.nova.servers.get(vm.get("ins_id"))
    security_group_id = vm.get("Securitygroupname")
    try:
        # identify.nova.security_groups.find(name = "li-xiao")
        instance.add_security_group(security_group=security_group_id)
        print("sucessful")
    except:

        print("openstack error")


# def openstack_update_vm(ob, data):
#     print(data)
#     print("这是更新虚拟机的接口")
#
#
# def openstack_destroy_vm(ob, data):
#     print(ob)
#     print(data)
#
#     print("这是删除虚拟机的接口")


# if __name__ == '__main__':
# openstack_query_host_image('1', '2')
# openstack_create_vm('1', '2')

if __name__ == '__main__':
    print(openstack_get_consoleurl())
