import time

from django.http import JsonResponse
from rest_framework import status
from rest_framework.utils import json

from apps.virtual_machine.models import VMInformation
# from  import identify
from utils.openstack_api.common import identify


def openstack_create_server_volumes(ob, data):
    volume_name = data.get("cloud_volume_name")
    volume_type = data.get("cloud_volume_type")
    volume_size = data.get("cloud_volume_size")
    print(volume_name)
    newvol = identify.cinder.volumes.create(name=volume_name, volume_type=volume_type, size=volume_size)
    cloud_volume_id = newvol.id
    data['cloud_volume_id'] = cloud_volume_id
    count = 0
    status = newvol.status
    while (status != "available") and (count < 1000):
        count = count + 1
        volume = identify.cinder.volumes.get(cloud_volume_id)
        status = volume.status
        time.sleep(10)
    data['cloud_volume_status'] = status
    data = {'code': 200, 'data': data}
    return data

    # volume_id = newvol.id
    # identify.nova.volumes.create_server_volume(server_id=1, volume_id=volume_id, device=None)
    # print(identify.nova.volumes.get_server_volumes("b58de28c-4269-44bc-99ee-0928447d8cac"))
    # print(identify.nova.volumes.resource_class)
    # print(identify.cinder.volumes.list())

    # print(myvol)


# available
def openstack_allocate_server_volumes(data):
    data = json.loads(data.body)
    print("#############")
    print(data)
    aboutVM = VMInformation.objects.filter(VM_name=data.get('VM_name'))
    volume_id = data.get("cloud_volume_id")
    server_id = aboutVM.values()[0].get('VM_id')
    if data.get("VM_name") != "" and data.get("cloud_volume_status") == "available":
        identify.nova.volumes.create_server_volume(server_id=server_id, volume_id=volume_id, device=None)
    count = 0
    volume_status = data.get("cloud_volume_status")
    print("####@@@")
    while (volume_status != "in-use") and (count < 1000):
        count = count + 1
        volume = identify.cinder.volumes.get(volume_id)
        volume_status = volume.status
        time.sleep(10)
    print("####@@@@")
    data["VM_id"] = server_id
    data["cloud_volume_status"] = volume_status
    # data = {'code': 200, 'data': data}
    print(data)
    return JsonResponse(data, status=status.HTTP_200_OK)


def openstack_separate_server_volumes(data):
    data = json.loads(data.body)
    print("#############")
    print(data)
    aboutVM = VMInformation.objects.filter(VM_name=data.get('VM_name'))
    volume_id = data.get("cloud_volume_id")
    server_id = aboutVM.values()[0].get('VM_id')
    volumeinfo = identify.cinder.volumes.get(volume_id)
    print("######@@#####")
    print(volumeinfo.attachments[0].get("attachment_id"))
    # attachment_id = volumeinfo.attachments[0].get("attachment_id")
    identify.nova.volumes.delete_server_volume(server_id=server_id, attachment_id=volume_id)
    count = 0
    volume_status = data.get("cloud_volume_status")
    print("####@@@")
    while (volume_status != "available") and (count < 1000):
        count = count + 1
        volume = identify.cinder.volumes.get(volume_id)
        volume_status = volume.status
        time.sleep(10)

    data["VM_id"] = ""
    data["VM_name"] = ""
    data["cloud_volume_status"] = volume_status

    # data = {'code': 200, 'data': data}

    return JsonResponse(data, status=status.HTTP_200_OK)


def openstack_delete_volumes(ob, deldata):
    data = {'code': 400, }
    print(deldata.VM_id)
    server_id = deldata.VM_id
    volume_id = deldata.cloud_volume_id
    if (server_id != ""):
        identify.nova.volumes.delete_server_volume(server_id=server_id, attachment_id=volume_id)
    volume = identify.cinder.volumes.get(volume_id)
    volume.delete()
    data['code'] = 200
    print(deldata)
    return data


def openstack_update_volumes(ob, updatedata):
    new_name = updatedata.get("cloud_volume_name")
    volume_id = updatedata.get("cloud_volume_id")
    volume = identify.cinder.volumes.get(volume_id)
    identify.cinder.volumes.update(volume=volume, name=new_name)
    data = {'data': updatedata, 'code': 200}
    return data


def openstack_get_server_volumes(data):
    data = json.loads(data.body)
    print("#############")
    print(data)
    server_id = data.get("VM_id")
    get_server_volume=identify.nova.volumes.get_server_volumes(server_id)
    tag = False
    if get_server_volume != []:
        tag = True
    print(tag)
    return JsonResponse(tag, status=status.HTTP_200_OK,safe=False)

