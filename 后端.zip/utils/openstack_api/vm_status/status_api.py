from apps.virtual_machine.models import VMInformation
# from common import identify
from utils.openstack_api.common import identify


# 恢复实例
def openstack_resume_ins(data):
    try:
        identify.nova.servers.resume(server=data.get("VM_id"))
        print("successful")
    except:
        print("openstack error")


# 启动实例
def openstack_start_ins(data):
    try:
        identify.nova.servers.start(server=data.get("VM_id"))
        print("successful")
    except:
        print("openstack error")


# 关闭实例
def openstack_stop_ins(data):
    try:
        identify.nova.servers.stop(server=data.get("VM_id"))
        print("successful")
    except:
        print("openstack error")


# 挂起实例
def openstack_suspend_ins(data):
    try:
        identify.nova.servers.suspend(server=data.get("VM_id"))
        print("successful")
    except:
        print("openstack error")


def openstack_change_status(changeVMData):
    if changeVMData.get('status') == '运行':
        openstack_resume_ins(changeVMData)
    elif changeVMData.get('status') == '挂起':
        openstack_suspend_ins(changeVMData)
    elif changeVMData.get('status') == '关闭':
        openstack_stop_ins(changeVMData)
