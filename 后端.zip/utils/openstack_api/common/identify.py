"""这是openstack公众调用的api"""
import novaclient.client as nvclient
import cinderclient.client as cinderclient
import neutronclient.neutron.client as neutronclient
from glanceclient.v2 import client as image_client
import keystoneclient.v3.client as ksclient

neutron = neutronclient.Client('2.0')
nova = nvclient.Client('2.0', username='admin', password='123456', project_id='ce61e95ebcd34c7bb9f3ab7446110a0e',
                       auth_url='http://192.168.1.35:5000')
# username='admin', password='123456', project_name='admin'
cinder = cinderclient.Client('3.0', 'admin', '123456', 'admin', 'http://192.168.1.35:5000/v3')
net_id = '903749d7-fd9c-488a-aa73-75e77cd31901'
k = ksclient.Client(username='admin',
                    password='123456',
                    tenant_name='admin',
                    endpoint_url='http://192.168.1.35:9292',
                    auth_url='http://192.168.1.35:35357/v3')
image = image_client.Client(token=k.auth_token,
                            endpoint='http://192.168.1.35:9292')
# # a = nova.images.find(name='cirros')
# # print(a)
# for _ in images.images.list():
#   print(_)
#   print(type(_))
