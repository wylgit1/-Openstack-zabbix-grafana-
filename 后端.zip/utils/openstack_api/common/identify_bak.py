"""这是openstack公众调用的api"""
import novaclient.client as nvclient
import cinderclient.client as cinderclient
import neutronclient.neutron.client as neutronclient
from glanceclient.v2 import client as image_client
import keystoneclient.v3.client as ksclient

neutron = neutronclient.Client('2.0')
nova = nvclient.Client('2.0', username='admin', password='123456', project_id='3170dd5cbb354858a3e373c613a674a1',
                       auth_url='http://192.168.48.10:5000')
# username='admin', password='123456', project_name='admin'
cinder = cinderclient.Client('3.0', 'admin', '123456', 'admin', 'http://192.168.48.10:5000/v3')
net_id = '93bf5182-90b2-417f-aa16-e7ecedecd799'
k = ksclient.Client(username='admin',
                    password='123456',
                    tenant_name='admin',
                    endpoint_url='http://192.168.48.10:9292',
                    auth_url='http://192.168.48.10:35357/v3')
image = image_client.Client(token=k.auth_token,
                            endpoint='http://192.168.48.10:9292')
# # a = nova.images.find(name='cirros')
# # print(a)
# for _ in images.images.list():
#   print(_)
#   print(type(_))
