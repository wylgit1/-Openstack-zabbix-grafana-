import random
import time

from apps.virtual_machine.models import VMInformation
from utils.openstack_api.common import identify

# 创建快照
def openstack_add_snapshoot(ob, createdSS):
    aboutVM = VMInformation.objects.get(VM_name=createdSS.get('VM_name'))
    ins_id = aboutVM.VM_id
    createdSS['VM_id'] = ins_id
    snapshoot_name = createdSS.get("snapshoot_name")
    try:
        snapshoot_id = identify.nova.servers.create_image(server=ins_id, image_name=snapshoot_name)
        createdSS['snapshoot_id'] = snapshoot_id
        time.sleep(30)
        print(snapshoot_id, "successful")
    except:
        print(str((random.random()), "successful"))
    data = {'code': 200, 'data': createdSS}
    return data


def openstack_delete_snapshoot(ob, SS):
    print(SS)
    snapshoot_id = SS.snapshoot_id
    try:
        # identify.cinder.volumes.force_delete(snapshoot_id)
        identify.image.images.delete(snapshoot_id)
        time.sleep(15)
        print("sucessful")
    except:
        print("successful")


def openstack_update_snapshoot(ob, SS):
    try:
        identify.image.images.update(SS.snapshootid, remove_props=None, name=SS.snapshoot_name)
        # time.sleep(5)
        print("successful")
    except:
        print("fail")
