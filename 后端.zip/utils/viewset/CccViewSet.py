"""这是工具视图"""
from rest_framework.permissions import BasePermission
from rest_framework.response import Response
from rest_framework import viewsets, status


class CccPermission(BasePermission):
    """自定义权限(以下内容主要是查看权限)
    如果不是get请求并且不是超级管理员，就认为没有权限
    如果是get请求，并且不是初始化的get请求，就认为有权限
    """

    def has_permission(self, request, view):
        print(request.method)
        print(request.user)
        print(request.user.is_staff)
        if request.method != 'GET' and request.user.is_staff is False:
            return False
        elif request.user.is_staff is False and view.action_map['head'] == 'getMsg':
            return False
        else:
            return True


class CccViewSet(viewsets.ModelViewSet):
    create_api = None
    update_api = None
    destroy_api = None

    # permission_classes = [CccPermission, ]

    def list(self, request, *args, **kwargs):
        queryset = self.filter_queryset(self.get_queryset())
        page = self.paginate_queryset(queryset)
        if page is not None:
            serializer = self.get_serializer(page, many=True)
            return self.get_paginated_response(serializer.data)

        serializer = self.get_serializer(queryset, many=True)
        data = {'data': serializer.data, 'code': 200}
        return Response(data,status=status.HTTP_200_OK)

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        print(f"这是调用前的结果{serializer.validated_data}")
        if self.create_api is not None:
            res = self.create_api(serializer.validated_data)
            # 确认openstack是否创建成功
            # print(res.get('code'))
            # if res.get('code') == 200:
            #     state = status.HTTP_200_OK
            # print(f"这是调用后的结果{res}")
            print(f"这是调用后的结果{res.get('data')}")
            for item in res['data']:
                print(item)
                serializer.validated_data[item] = res['data'][item]
        print("###@@@@####")
        print(serializer.validated_data)
        serializer.save()
        headers = self.get_success_headers(serializer.data)
        data = {'data': serializer.validated_data}
        return Response(data, status=status.HTTP_200_OK, headers=headers)

    def update(self, request, *args, **kwargs):
        print(request.method)
        partial = kwargs.pop('partial', False)
        instance = self.get_object()
        serializer = self.get_serializer(instance, data=request.data, partial=partial)
        serializer.is_valid(raise_exception=True)
        if getattr(instance, '_prefetched_objects_cache', None):
            # If 'prefetch_related' has been applied to a queryset, we need to
            # forcibly invalidate the prefetch cache on the instance.
            instance._prefetched_objects_cache = {}
        if self.update_api is not None:
            print("序列化数据")
            print(serializer.validated_data)
            res = self.update_api(serializer.validated_data)
            for item in res['data']:
                print(item)
                serializer.validated_data[item] = res['data'][item]
        serializer.save()
        data = {'data': serializer.validated_data, 'code': 200}
        return Response(data,status=status.HTTP_200_OK)

    def destroy(self, request, *args, **kwargs):
        instance = self.get_object()
        # 真正执行删除的代码
        if self.destroy_api is not None:
            res = self.destroy_api(instance)
            # if res.get('status') != 200:
            #     return Response(res)

        self.perform_destroy(instance)
        data = {'data':instance , 'code': 200}
        return Response(data,status=status.HTTP_200_OK)

    def retrieve(self, request, *args, **kwargs):

        instance = self.get_object()
        serializer = self.get_serializer(instance)
        data = {'data': serializer.data, 'code': 200}
        return Response(data,status=status.HTTP_200_OK)
