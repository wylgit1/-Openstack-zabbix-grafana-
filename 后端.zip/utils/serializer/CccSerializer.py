# @Time : 2022/5/11 0011 20:15
# @Author : Guo Shao
# @Email : 1114239571@qq.com
# @File : CccSerializer.py
# @Software: PyCharm
"""
下面是对drf序列化器的封装，在正常项目中，我们可能会有查询个别字段的情况，
不需要每次返回所有数据，从而减少数据的传输，常见用法如下
GET https://wxy.email/book/666/?fields=name,author
GET https://wxy.email/book/?omit=description
"""
from drf_dynamic_fields import DynamicFieldsMixin
from rest_framework import serializers


class CccLinkedSerializer(DynamicFieldsMixin, serializers.HyperlinkedModelSerializer):
    pass


class CccSerializer(DynamicFieldsMixin, serializers.ModelSerializer):
    pass
