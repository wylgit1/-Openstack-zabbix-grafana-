# -*- coding: utf-8 -*-
import os
import time

from ccc_back.settings import BASE_DIR


def all_path():
    script_path = os.path.join(
        BASE_DIR, 'scripts'
    )
    file_list = []
    for maindir, subdir, file_name_list in os.walk(script_path):
        for filename in file_name_list:
            temp_list = {}
            list = filename.split('.')
            print(filename)
            # if list[-1] == 'py' or 'sh':
            if filename.endswith('sh') or filename.endswith('py'):
                file_name = os.path.join(maindir, filename)
                print(file_name)
                if True:
                    try:
                        name = file_name.split('\\')
                        temp_list['name'] = name[-1]
                        # 文件的访问时间
                        # print(time.ctime(os.path.getatime(file_name)))
                        temp_list['atime'] = time.ctime(os.path.getatime(file_name))
                        # 文件的修改时间
                        # print(time.ctime(os.path.getmtime(file_name)))
                        temp_list['mtime'] = time.ctime(os.path.getmtime(file_name))
                        # 文件的创建时间
                        # print(time.ctime(os.path.getctime(file_name)))
                        temp_list['ctime'] = time.ctime(os.path.getctime(file_name))
                        size = os.path.getsize(file_name)
                        temp_list['size'] = size
                        file_list.append(temp_list)
                    except:
                        pass  # 所以异常全部忽略即可

    print(file_list)
    return file_list


if __name__ == '__main__':
    all_path()
