import time

import requests
from django import http
from django.http import JsonResponse
from pyzabbix import ZabbixAPI

# 登录zabbix
from rest_framework import status
from rest_framework.utils import json

from utils.all_path import all_path
from utils.zabbix_api.oldcmc_api.auth import post_headers, zabbix_user, zabbix_pass

zbx_url = "http://192.168.1.35/zabbix/api_jsonrpc.php"
zabbix = ZabbixAPI('http://192.168.1.35/zabbix')
zabbix.session.verify = False
logindata = zabbix.login('Admin', 'zabbix')
cmc_zabbix_api = ('http://192.168.1.35/zabbix', 'Admin', 'zabbix')

# zbx_url = "http://192.168.48.10/zabbix/api_jsonrpc.php"
# zabbix = ZabbixAPI('http://192.168.48.10/zabbix')
# zabbix.session.verify = False
# zabbix.login('Admin', 'zabbix')
# cmc_zabbix_api = ('http://192.168.48.10/zabbix', 'Admin', 'zabbix')

"""触发器相关"""


def get_zabbix_token():
    data = {
        "jsonrpc": "2.0",
        "method": "user.login",
        "params": {
            "user": zabbix_user,
            "password": zabbix_pass
        },
        "id": 0
    }
    r = requests.get(zbx_url, headers=post_headers, data=json.dumps(data))
    auth = json.loads(r.text)
    return auth["result"]


def getGroups(token):
    data = {
        "jsonrpc": "2.0",
        "method": "hostgroup.get",
        "params": {
            "output": "extend",
            "filter": {
                "name": [
                    # 不写这个过滤下的话，会得到四五个多余的模板
                    "Templates",
                    "Templates/Applications",
                    "Templates/Databases",
                    "Templates/Modules",
                    "Templates/Network devices",
                    "Templates/Operating systems",
                    "Templates/Server hardware",
                    "Templates/Virtualization",
                    "Zabbix servers",
                ]
            }
        },
        "id": 2,
        "auth": token,

    }
    # zabbix_url和post_headers都是从old_api里面拿出来的
    request = requests.post(zabbix_url, headers=post_headers, data=json.dumps(data))
    dict = json.loads(request.content)
    return dict['result']


def create_trigger(token, description, expression):
    data = {
        "jsonrpc": "2.0",
        "method": "trigger.create",
        "params": [
            {
                "description": description,
                "expression": expression,
            },
        ],
        "auth": token,
        "id": 1
    }
    request = requests.post(zbx_url, headers=post_headers, data=json.dumps(data))
    dict = json.loads(request.content)
    print(dict)
    return dict


# def create_trigger():
#     createdata = zabbix.trigger.create(
#         params=[
#             {
#                 "description": "Zabbix server: More than 75% used in the history cache",
#                 "expression": "{22245}>75",
#                 "dependencies": [
#                     {
#                         'triggerid': '18712'
#                     }
#                 ]
#             },
#         ],
#         auth=token,
#         id=1
#     ),
#     print(createdata)


# 获取指定主机的触发器
def zabbix_get_trigger_by_hostid(hostid):
    # 将WSGIRequest格式数据中的数据提出来 #
    data = json.loads(hostid.body)
    print(data)
    # ------------------------------- #
    triggers = zabbix.trigger.get(output=["triggerid", "description", "priority", "expression", "status"],
                                  filter={"hostid": data})
    print(triggers)
    return JsonResponse(data=triggers, status=status.HTTP_200_OK, safe=False)


def zabbix_delete_trigger(triggerid):
    trigger = zabbix.trigger.delete(
        triggerid
    )
    print(trigger)
    return trigger


def zabbix_create_action(createaction):
    # 获取主机hH
    data = json.loads(createaction.body)

    print(data)
    print(data['data']['action']['name'])
    print(data['data']['action']['opt_time'])
    print(data['data']['action']['host'])
    print(data['data']['operations'])
    action = zabbix.action.create(
        name=data['data']['action']['name'],  # 动作名称
        eventsource=0,  # 0 - event created by a trigger;
        esc_period=data['data']['action']['opt_time'],  # 默认操作步骤持续时间，最少60
        # 设置默认消息与默认接收人
        def_shortdata="{TRIGGER.NAME}: {TRIGGER.STATUS}",
        def_longdata="{TRIGGER.NAME}: {TRIGGER.STATUS}\r\nLast value: {ITEM.LASTVALUE}\r\n\r\n{TRIGGER.URL}",

        filter={
            "evaltype": 0,  # 0 - and/or; 1 - and; 2 - or; 3 - custom expression.
            # 触发条件
            "conditions": [
                {
                    # 根据触发器创建动作
                    "conditiontype": 2,
                    # 触发器id
                    "value": data['data']['action']['field103'],
                }, ]
        },

        # 要执行的操作
        operations=data['data']['operations'],

        # recovery_operations=[
        #     {
        #         "operationtype": "11",
        #         "opmessage": {
        #             "default_msg": 1
        #         }
        #     }
        # ],
    )

    print(action)
    return JsonResponse({'data': action}, status=status.HTTP_200_OK)


# def zabbix_create_action(createaction):
#     # 获取主机hH
#     data = json.loads(createaction.body)
#
#     print(data)
#     print(data['data']['action']['name'])
#     print(data['data']['action']['opt_time'])
#     print(data['data']['action']['host'])
#     print(data['data']['mess'][0]['time'])
#     print(data['data']['mess'][0]['step'])
#     action = zabbix.action.create(
#         name=data['data']['action']['name'],  # 动作名称
#         eventsource=0,  # 0 - event created by a trigger;
#         esc_period=data['data']['action']['opt_time'],  # 默认操作步骤持续时间，最少60
#         # 设置默认消息与默认接收人
#         def_shortdata="{TRIGGER.NAME}: {TRIGGER.STATUS}",
#         def_longdata="{TRIGGER.NAME}: {TRIGGER.STATUS}\r\nLast value: {ITEM.LASTVALUE}\r\n\r\n{TRIGGER.URL}",
#
#         filter={
#             "evaltype": 0,  # 0 - and/or; 1 - and; 2 - or; 3 - custom expression.
#             # 触发条件
#             "conditions": [
#                 {
#                     # 根据触发器创建动作
#                     "conditiontype": 2,
#                     # 触发器id
#                     "value": data['data']['action']['field103'],
#                 }, ]
#         },
#
#         # 要执行的操作
#         operations=[
#             {
#                 "operationtype": 0,  # 0 - 发送消息;1 - 远程命令;
#                 # "esc_period":"0s",
#                 "esc_period": data['data']['mess'][0]['time'],
#                 "esc_step_from": data['data']['mess'][0]['step'],
#                 "esc_step_to": data['data']['mess'][0]['step'],
#                 # "esc_step_from": 1,
#                 # "esc_step_to": 2,
#                 # "evaltype": 0,  # 过滤条件评估方法可能值:0 - and/or; 1 - and; 2 - or; 3 - 自定义表达式。
#                 "opmessage_grp": [
#                     {
#                         "usrgrpid": "7"
#                     }
#                 ],
#                 "opmessage": {
#                     "default_msg": 1,
#                     "mediatypeid": "1"
#                 }
#             }],
#
#         recovery_operations=[
#             {
#                 "operationtype": "11",
#                 "opmessage": {
#                     "default_msg": 1
#                 }
#             }
#         ],
#     )
#
#     print(action)
#     return JsonResponse({'data': action}, status=status.HTTP_200_OK)


def create_action():
    # 获取主机hH
    userid = None,
    action = zabbix.action.create(
        name="test20232123",  # 动作名称
        eventsource=0,  # 0 - event created by a trigger;
        esc_period=120,  # 默认操作步骤持续时间，最少60
        # 设置默认消息与默认接收人
        def_shortdata="{TRIGGER.NAME}: {TRIGGER.STATUS}",
        def_longdata="{TRIGGER.NAME}: {TRIGGER.STATUS}\r\nLast value: {ITEM.LASTVALUE}\r\n\r\n{TRIGGER.URL}",

        filter={
            "evaltype": 0,  # 0 - and/or; 1 - and; 2 - or; 3 - custom expression.
            # 触发条件
            "conditions": [
                {
                    # 1主机创建动作 2根据触发器创建动作
                    "conditiontype": 1,
                    "operator": 0,
                    # 触发器id
                    "value": "10084",
                }, ]
        },

        # 要执行的操作
        operations=[
            {
                "operationtype": 0,  # 0 - 发送消息;1 - 远程命令;
                "esc_period": "0s",
                "esc_step_from": 1,
                "esc_step_to": 2,
                "evaltype": 0,
                "opmessage_grp": [
                    {
                        "usrgrpid": "7"
                    }
                ],
                # "opmessage_usr": [
                #     {
                #         "userid": userid
                #     }
                # ],
                "opmessage": {
                    "default_msg": 1,
                    "mediatypeid": "1"
                }
            },
            {
                "operationtype": 1,
                "esc_period": "120",
                "esc_step_from": "3",
                "esc_step_to": "4",
                "evaltype": 0,
                "opconditions": [
                    {
                        "conditiontype": 14,
                        "operator": 0,
                        "value": "0"
                    }
                ],
                "opcommand_hst": [
                    {
                        'hostid': '0',
                    }
                ],
                # "opcommand_grp": [{}],
                "opcommand": {
                    "type": 0,
                    "scriptid": "0",
                    "execute_on": "0",
                    "command": 'ls'
                },

            },
        ],

        # recovery_operations=[
        #     {
        #         # 0 - 发送信息;1 - 远程命令;11 - 通知所有参与者。
        #         "operationtype": "11",
        #         "opmessage": {
        #             # 是否使用默认动作消息文本和主题。可用的值:0 - (default) 使用操作中的消息文本和主题 ;1 - 使用动作中的消息文本和主题
        #             "default_msg": 1
        #         }
        #     }
        # ],
    )

    print(action)
    return action


def zabbix_get_action():
    actions = zabbix.action.get(output=["actionid", "name", "status", "mediatypeid"],
                                selectOperations="extend",
                                filter={"eventsource": 0})
    print(actions)
    # return JsonResponse({'data': actions}, status=status.HTTP_200_OK)


def get_scripts(ob):
    file_list = all_path()
    print(file_list)
    return http.JsonResponse({'code': 200, 'errmsg': 'OK', 'file_list': file_list})


if __name__ == '__main__':
    # get_trigger_by_hostid('10084')
    # get_scripts()
    # create_action()
    #
    # zabbix_get_action()

    # triggers = zabbix.trigger.get(output=["triggerid", "name","description", "priority","expression","status"], filter={"hostid": '10084'})
    # print(triggers)
    create_trigger()
