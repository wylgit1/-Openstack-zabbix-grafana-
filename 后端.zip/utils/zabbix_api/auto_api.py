import time

import requests
from django.http import JsonResponse
from pyzabbix import ZabbixAPI

# 登录zabbix
from rest_framework import status
from rest_framework.utils import json

zbx_url = "http://192.168.1.35/zabbix/api_jsonrpc.php"
zabbix = ZabbixAPI('http://192.168.1.35/zabbix')
zabbix.session.verify = False
zabbix.login('Admin', 'zabbix')
cmc_zabbix_api = ('http://192.168.1.35/zabbix', 'Admin', 'zabbix')

# zbx_url = "http://192.168.48.10/zabbix/api_jsonrpc.php"
# zabbix = ZabbixAPI('http://192.168.48.10/zabbix')
# zabbix.session.verify = False
# zabbix.login('Admin', 'zabbix')
# cmc_zabbix_api = ('http://192.168.48.10/zabbix', 'Admin', 'zabbix')
def zabbix_drule_list(ob):
    drules = zabbix.drule.get(
        output=["druleid", "name", "iprange", "delay", "status"]
    )
    return JsonResponse({'data': drules}, status=status.HTTP_200_OK)


def zabbix_create_drule(createdata):
    data = json.loads(createdata.body)
    print(data)
    print(data.get("host_group_name"))
    iprange = data.get("iprange")
    delay = data.get("delay")
    name = data.get("name")
    drule = zabbix.drule.create({
        "name": name,
        "iprange": iprange,
        "delay": delay,
        "dchecks": [
            {
                "type": "9",
                "key_": "agent.ping",
                "ports": "10050",
                "uniq": "0",
            }
        ]
    }
    )
    return JsonResponse({'data': drule}, status=status.HTTP_200_OK)


def zabbix_delete_drule(druleid):
    data = json.loads(druleid.body)
    print(data)
    drule = zabbix.drule.delete(data)
    return JsonResponse({'data': drule}, status=status.HTTP_200_OK)
