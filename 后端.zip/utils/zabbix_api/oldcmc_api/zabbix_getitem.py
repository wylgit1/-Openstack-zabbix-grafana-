#!/usr/bin/env python
# -*- encoding: utf8 -*-

# 导入模块，urllib2是一个模拟浏览器HTTP方法的模块
import json
import sys
import urllib.request as urllib2
from auth import zabbix_header, zabbix_pass, zabbix_url, zabbix_user, auth_code, MySQLport, MySQLuser, MySQLpasswd
import pymysql


json_data = {
    "jsonrpc": "2.0",
    "method": "item.get",
    "params": {
        "output": "extend",
        "selectApplications": "extend",
        # "hostids": "10177",
        # "itemids":"27726"

    },
}
json_base = {
    "jsonrpc": "2.0",
    "auth": auth_code,
    "id": 1
}

json_data.update(json_base)
# 用得到的SESSIONID去验证，获取主机的信息(用http.get方法)
if len(auth_code) == 0:
    print("error")
    sys.exit(1)
if len(auth_code) != 0:
    get_host_data = json.dumps(json_data)
    get_host_data = get_host_data.encode()
    # create request object
    request = urllib2.Request(zabbix_url, get_host_data)
    for key in zabbix_header:
        request.add_header(key, zabbix_header[key])
    # get host list
    try:
        result = urllib2.urlopen(request)
    except Exception as e:
        print(e)
    else:
        response = json.loads(result.read())
        result.close()
        # print (response)

        # print "Number Of Items: ", len(response['result'])
        # 连接数据库
        # conn = pymysql.connect(
        #     host='192.168.48.1',
        #     port=MySQLport,
        #     user=MySQLuser,
        #     passwd=MySQLpasswd,
        #     db='ccc',
        #     charset='utf8',
        # )
        conn = pymysql.connect(
            host='192.168.1.2',
            port=MySQLport,
            user=MySQLuser,
            passwd=MySQLpasswd,
            db='yl_ccc',
            charset='utf8',
        )
        cur = conn.cursor()
        # 清空数据库
        sql1 = "DELETE FROM trigger_citem "
        cur.execute(sql1)
        conn.commit()
        for item in response['result']:
            for i in item['applications']:
                get_data = [item['itemid'], item['name'], item['key_'], item['status'], item['hostid'],
                            item['interfaceid'], item['value_type'], item['type'], item['units'],
                            i['applicationid'], item['description']]
            # 插入一条数据
            sql = "insert into trigger_citem values(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s) "
            try:
                cur.execute(sql, get_data)  # 执行sql语句
                conn.commit()
                # print "insert success!"
            except:
                # 1
                print("Error: unable to fetch item")
                # print get_data

        cur.close()
        conn.close()
