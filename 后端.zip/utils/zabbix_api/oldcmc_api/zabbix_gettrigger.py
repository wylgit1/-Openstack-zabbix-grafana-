#!/usr/bin/env python
# -*- encoding: utf8 -*-

# 导入模块，urllib2是一个模拟浏览器HTTP方法的模块
import json
import sys
import urllib.request as urllib2
from auth import zabbix_header, zabbix_pass, zabbix_url, zabbix_user, auth_code, MySQLport, MySQLuser, MySQLpasswd
import pymysql

json_data = {
    "jsonrpc": "2.0",
    "method": "trigger.get",
    "params": {
        "output": "extend",
        "selectFunctions": "extend"
    },
}
json_base = {
    "jsonrpc": "2.0",
    "auth": auth_code,
    "id": 1
}

json_data.update(json_base)
# 用得到的SESSIONID去验证，获取主机的信息(用http.get方法)
if len(auth_code) == 0:
    sys.exit(1)
if len(auth_code) != 0:
    get_host_data = json.dumps(json_data)
    get_host_data = get_host_data.encode()
    # create request object
    request = urllib2.Request(zabbix_url, get_host_data)
    for key in zabbix_header:
        request.add_header(key, zabbix_header[key])

    # get host list
    try:
        result = urllib2.urlopen(request)
    except Exception as e:
        print(e)
    else:
        response = json.loads(result.read())
        result.close()
        # print (type(response))
        # # 将所有的主机jiankong信息显示出来
        # print "Number Of Triggers: ", len(response['result'])
        # print response
        # # 连接数据库
        # conn = pymysql.connect(
        #     host='192.168.48.1',
        #     port=MySQLport,
        #     user=MySQLuser,
        #     passwd=MySQLpasswd,
        #     db='ccc',
        #     charset='utf8',
        # )
        conn = pymysql.connect(
            host='192.168.1.2',
            port=MySQLport,
            user=MySQLuser,
            passwd=MySQLpasswd,
            db='yl_ccc',
            charset='utf8',
        )
        triggerID = []  # 将所有id汇总
        for trigger in response['result']:
            triggerID.append(trigger['triggerid'])  # 将所有id汇总
            for item in trigger["functions"]:
                condition = [item['itemid'], item['triggerid'], item['function'], trigger['expression']]
                condition = ','.join(condition)  # 数据库中没有
                # condition = str(condition)#数据库中带[]
                # print condition
                get_data = [trigger['triggerid'], trigger['description'], trigger['value'], trigger['priority'],
                            item["itemid"],
                            trigger['comments'], condition]
                get_data1 = [trigger['description'], trigger['value'], trigger['priority'], item["itemid"],
                             trigger['comments']]
                # print get_data
                # 连接数据库mysql
                cur = conn.cursor()
                # 插入一条数据
                sql = "insert into trigger_trigger values(%s,%s,%s,%s,%s,%s,%s) "
                # sql = "insert into main_ctrigger(triggerId,triggerName,triggerValue,triggerPriority,itemId,triggerDescription) values(%s,%s,%s,%s,%s,%s) "
                sql1 = "updata main_ctrigger set triggerName=%s,triggerValue=%s,triggerPriority=%s,itemId=%s,triggerDescription=%s WHERER triggerId =" + \
                       trigger['triggerid']
                try:
                    cur.execute(sql, get_data)  # 新建
                    conn.commit()
                    cur.execute(sql1, get_data1)  # 更新
                    conn.commit()
                except:
                    # print ("Error: unable to fetch data")
                    1
                    # print get_data
        # triggerID=tuple(triggerID)

        triggerID = ",".join(triggerID)  # 输出类型为unicode
        triggerID = triggerID.encode('unicode-escape').decode('unicode-escape')
        # print triggerID,type(triggerID)
        sql2 = "delete  from trigger_trigger where triggerId not in (%s)" % (triggerID)
        cur.execute(sql2)  # 删除zabbix没有的
        conn.commit()
        # tt = cur.fetchall()  # 取查询出来的节点信息
        # print tt
        cur.close()
        conn.close()
