#!/usr/bin/env python
# -*- encoding: utf8 -*-

# 导入模块，urllib.request是一个模拟浏览器HTTP方法的模块
import json
import sys
import urllib
from urllib.request import Request
from urllib.error import URLError
from auth import zabbix_header, zabbix_pass, zabbix_url, zabbix_user, auth_code, MySQLport, MySQLuser, MySQLpasswd
import pymysql

header = {"User-Agent": "Opera/9.80 (Windows NT 6.1; U; en) Presto/2.7.62 Version/11.01"}
# request json
json_data = {
    "jsonrpc": "2.0",
    "method": "host.get",  # 调用的API方法;
    "params": {  # 将被传递给API方法的参数
        "output": "extend",
        "selectGroups": "groupid",
        "selectParentTemplates": "templateid",
        "selectInterfaces": ["ip"],
        "filter": {
            "host": [

            ]
        }
    },
    "auth": auth_code,  # 用户认证令牌
    "id": 1
}

if len(auth_code) == 0:
    sys.exit(1)
if len(auth_code) != 0:
    # 先转化为json
    json_data = json.dumps(json_data)
    # 转化为byte
    json_data = json_data.encode()
    request = urllib.request.Request(zabbix_url, data=json_data, headers=header)
    for key in zabbix_header:
        request.add_header(key, zabbix_header[key])
    try:
        result = urllib.request.urlopen(request)
    except URLError as e:
        print(e)
    else:
        response = json.loads(result.read())
        result.close()
        # print(response)

        # 统计几个主机
        long = len(response['result'])
        # print long
        # 显示主机名称，并循环读取将每个主机定义一个变量

        # 连接数据库
        # conn = pymysql.connect(
        #     host='192.168.48.1',
        #     port=MySQLport,
        #     user=MySQLuser,
        #     passwd=MySQLpasswd,
        #     db='ccc',
        #     charset='utf8',
        # )
        conn = pymysql.connect(
            host='192.168.1.2',
            port=MySQLport,
            user=MySQLuser,
            passwd=MySQLpasswd,
            db='yl_ccc',
            charset='utf8',
        )
        cur = conn.cursor()

        sql1 = "DELETE FROM hosts_hosts "  # 清空数据库myhost这张表
        cur.execute(sql1)  # 执行
        conn.commit()  # 提交
        auto_id = 1
        print(response['result'])
        for host in response['result']:
            for group in host['groups']:
                for interfaces in host['interfaces']:
                    for template in host['parentTemplates']:
                        get_data = [auto_id, host['hostid'], host['name'], host['available'],
                                    host['status'], interfaces["ip"],
                                    group['groupid'],template['templateid']]
                        auto_id = auto_id+1
                        # 此处注意！！要加一个括号[]！！！
                        print(get_data)
                        # 连接数据库mysql
                        # cur = conn.cursor()
                        # 插入一条数据 INSERT INTO `ccc`.`hosts_hosts`(`id`, `create_time`, `update_time`, `host_id`, `host`, `nickname`, `available`, `status`, `host_ip`, `group_id`, `template_id`) VALUES (1, '2022-12-21 21:53:16.000000', '2022-12-21 21:53:16.000000', '10438', '192.168.48.11', '1', '1', '0', '192.168.48.11', '5', '10001');
                        # sql = " insert into hosts_hosts('create_time', 'update_time', 'host_id', 'host', 'nickname', 'available', 'status', 'host_ip', 'group_id', 'template_id') values(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s) "
                        sql = " insert into hosts_hosts values(%s,%s,%s,%s,%s,%s,%s,%s) "
                        try:
                            cur.execute(sql, get_data)  # 执行sql语句
                            conn.commit()
                            # print "insert success!"
                        except:
                            print("Error: unable to fetch data")

        cur.close()
        conn.close()
