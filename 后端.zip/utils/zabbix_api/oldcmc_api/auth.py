# /usr/bin/env python
# -*-coding:utf-8-*-
# 师兄的api必须使用的东西
import json

import requests
import configparser  # python 读取conf格式的文件

cf = configparser.ConfigParser()
cf.read('/root/env/ccc_env/ccc/utils/zabbix_api/oldcmc_api/cmc.conf')
MySQLport = int(cf.get('db', 'db_port'))
MySQLuser = cf.get('db', 'db_user')
MySQLpasswd = cf.get('db', 'db_passwd')
MYSQLip = cf.get('db', 'db_host')
zabbix_ip = cf.get('zbx', 'zbx_ip')
zabbix_url = str(cf.get('zbx', 'zbx_url'))
zabbix_user = str(cf.get('zbx', 'zbx_user'))
zabbix_pass = str(cf.get('zbx', 'zbx_pass'))
zabbix_header1 = cf.get('zbx', 'zbx_header')
zabbix_header = eval(zabbix_header1)
auth_code = ''
header = {"User-Agent": "Opera/9.80 (Windows NT 6.1; U; en) Presto/2.7.62 Version/11.01"}

# url = 'http://192.168.48.10/zabbix/api_jsonrpc.php'
url = 'http://192.168.1.35/zabbix/api_jsonrpc.php'
post_headers = {'Content-Type': 'application/json'}
post_data = {
    "jsonrpc": "2.0",
    "method": "user.login",
    "params": {
        "user": "Admin",
        "password": "zabbix"
    },
    "id": 1
}

ret = requests.post(url, data=json.dumps(post_data), headers=post_headers)
ret = json.loads(ret.text)
auth_code = ret["result"]
