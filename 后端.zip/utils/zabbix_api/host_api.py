import time

import requests
from django.http import JsonResponse
from pyzabbix import ZabbixAPI

# 登录zabbix
from rest_framework import status
from rest_framework.utils import json

zbx_url = "http://192.168.1.35/zabbix/api_jsonrpc.php"
zabbix = ZabbixAPI('http://192.168.1.35/zabbix')
zabbix.session.verify = False
zabbix.login('Admin', 'zabbix')
cmc_zabbix_api = ('http://192.168.1.35/zabbix', 'Admin', 'zabbix')

# zbx_url = "http://192.168.48.10/zabbix/api_jsonrpc.php"
# zabbix = ZabbixAPI('http://192.168.48.10/zabbix')
# zabbix.session.verify = False
# zabbix.login('Admin', 'zabbix')
# cmc_zabbix_api = ('http://192.168.48.10/zabbix', 'Admin', 'zabbix')

"""主机相关"""


###创建主机
def create_host(host_name, host_ip,group_id,template_id):
    host = zabbix.host.create(
        host=host_name,
        interfaces=[
            {
                'type': 1,
                'main': 1,
                'useip': 1,
                'ip': host_ip,
                'dns': '',
                'port': '10050'
            }
        ],
        groups=[{'groupid': group_id}],
        templates=[
            {
                'templateid': template_id,
            },
        ]
    )
    return host


def zabbix_create_host(ob, createdata):
    host = zabbix.host.create(
        host=createdata.get("host"),
        # host_ip=createdata.get("host_ip"),
        interfaces=[
            {
                'type': 1,
                'main': 1,
                'useip': 1,
                'ip': createdata.get("host_ip"),
                'dns': '',
                'port': '10050'
            }
        ],
        groups=[{'groupid': createdata.get("group_id")}],
        templates=[
            {
                'templateid': createdata.get("template_id"),
            },
        ]
    )
    # 查找已建立的信息
    findhost = zabbix.host.get(
        search={
            "host": createdata.get("host"),
        },
        output="extend",
    )
    # 判断是否已经添加成功
    if findhost:
        code = 200
    else:
        code = 400
    print(findhost[0].get('hostid'))
    host_id = findhost[0].get('hostid')

    # 查找templateid对应的模板名称并存放入data中存入数据库
    findtemplate = zabbix.template.get(
        templateids=[createdata.get("template_id")],
        output=["host"],
    )
    print(findtemplate[0].get("host"))
    # 查找groupid对应的主机群组名称并存放入data中存入数据库
    findgroup = zabbix.hostgroup.get(
        groupids=[createdata.get("group_id")],
        output=["name"],
    )
    print(findgroup[0].get("name"))
    # 将获得的信息填入
    createdata["host_id"] = host_id
    createdata["available"] = findhost[0].get('available')
    createdata["status"] = bool(1 - int(findhost[0].get('status')))
    createdata["template_id"] = findtemplate[0].get("host")
    createdata["group_id"] = findgroup[0].get("name")
    data = {'code': code, 'data': createdata}
    return data


# 删除主机
def zabbix_delete_host(deletedata):
    deldata = json.loads(deletedata.body)
    print(deldata)
    print(deldata['hostid'])
    hostid = deldata['hostid']
    data = {'code': 400, }
    # 获取主机
    host = zabbix.host.delete(
        hostid
    )
    data['code'] = 200
    print(host)
    return JsonResponse({'data': host}, status=status.HTTP_200_OK)


# 获取所有主机或者主机组的主机
def zabbix_host_list(ob):
    hostList = zabbix.host.get(
        output=['host', 'hostid', 'name', 'available', 'status', 'interfaceids'],
        selectGroups=['name'],
        selectInterfaces=["ip"],
    )
    print(hostList)
    return JsonResponse({'data': hostList}, status=status.HTTP_200_OK)


# 更新主机
def zabbix_update_host(updatedata):
    updatedata = json.loads(updatedata.body)
    print(updatedata)
    print(updatedata.get("hostid"))
    print(updatedata.get("host"))
    print(updatedata.get("status"))
    updatestatus = bool(1 - updatedata.get("status"))+0
    print(updatestatus)
    host=zabbix.host.update(
        hostid=updatedata.get("hostid"),
        status=updatestatus,
        host=updatedata.get("host"),
    )
    data = {'code': 200, 'data': host}
    return JsonResponse({'data': data}, status=status.HTTP_200_OK)


"""主机群组相关"""


def zabbix_group_list(ob):
    # print(zabbix.hostgroup.get(output=['groupid', 'name']))
    grouplist = zabbix.hostgroup.get(output=['groupid', 'name'])
    return JsonResponse({'data': grouplist}, status=status.HTTP_200_OK)


def zabbix_add_group(createdata):
    data = json.loads(createdata.body)
    print(data)
    print(data.get("host_group_name"))
    name = data.get("host_group_name")
    createdata = zabbix.hostgroup.create(name=name)
    return JsonResponse({'data': createdata}, status=status.HTTP_200_OK)


###删除主机群组
def zabbix_delete_group(hostgroupid):
    data = json.loads(hostgroupid.body)
    print(data)
    # 获取主机
    host = zabbix.hostgroup.delete(
        data
    )

    # print(host)
    return JsonResponse({'data': host}, status=status.HTTP_200_OK)


"""模板相关"""


def zabbix_templates_list(ob):
    templatelist = zabbix.template.get(output=['templateid', 'name'])
    # return zabbix.template.get(output=['templateid', 'name'])
    return JsonResponse({'data': templatelist}, status=status.HTTP_200_OK)


def zabbix_delete_template(templateid):
    data = json.loads(templateid.body)
    print(data)
    template = zabbix.template.delete(
        data
    )
    # print(host)
    return JsonResponse(data=template, status=status.HTTP_200_OK, safe=False)


def zabbix_add_template(templatedata):
    data = json.loads(templatedata.body)
    print(data)
    print(data.get("value"))
    groups = data.get("value")
    print(groups)
    createdata = zabbix.template.create(
        host=data.get("host_template_name"),
        groups=groups
    )
    return JsonResponse(data=createdata, status=status.HTTP_200_OK, safe=False)


def zabbix_update_template(templatedata):
    data = json.loads(templatedata.body)
    print(data)
    print(data.get("value"))
    groups = data.get("value")


# item监控项

def zabbix_item_list(hostid):
    data = json.loads(hostid.body)
    print(data)
    itemlist = zabbix.item.get(output=["itemid", "name", "key_"], filter={"hostid": data})
    print(itemlist)
    # return zabbix.template.get(output=['templateid', 'name'])
    return JsonResponse({'data': itemlist}, status=status.HTTP_200_OK)


def zabbix_delete_item(itemid):
    data = json.loads(itemid.body)
    print(data)
    item = zabbix.item.delete(
        data
    )
    # print(host)
    return JsonResponse(data=item, status=status.HTTP_200_OK, safe=False)


def add_item(itemName, itemKey, hostId, valuetype, datatype, itemgroups, description, unit, interfaceId):
    item = zabbix.item.create({
        "name": itemName,
        "key_": itemKey,
        "hostid": hostId,
        "interfaceid": interfaceId,
        "type": 0,  # 0 - Zabbix agent; 1 - SNMPv1 agent;
        "value_type": valuetype,  # 0 - numeric float; 1 - character; 2 - log; 3 - numeric unsigned; 4 - text.
        "data_type": datatype,  # 0 - (default) decimal; 1 - octal; 2 - hexadecimal; 3 - boolean.
        "applications": itemgroups,
        "description": description,
        "units": unit,
        "delay": 30

    })
    return item


"""应用集相关"""


def zabbix_get_application(hostid):
    data = json.loads(hostid.body)
    print(data)
    applications = zabbix.application.get(output=["applicationid", "name"], filter={"hostid": data})
    return JsonResponse({'data': applications}, status=status.HTTP_200_OK)


def zabbix_delete_application(applicationid):
    data = json.loads(applicationid.body)
    print(data)
    application = zabbix.application.delete(
        data
    )
    return JsonResponse({'data': application}, status=status.HTTP_200_OK)


def add_application(hostid, name):
    application = zabbix.application.create(
        name=name, hostid=hostid
    )
    return application


def zabbix_add_item(templatedata):
    data = json.loads(templatedata.body)
    print(data)
    print(data.get("value"))
    groups = data.get("value")
    print(groups)
    createdata = zabbix.template.create(
        host=data.get("host_template_name"),
        groups=groups
    )
    return JsonResponse(data=createdata, status=status.HTTP_200_OK, safe=False)


# 解决方案
def zabbix_get_action(ob):
    # if actionid:
    #     action = zabbix.action.get(
    #         output="extend",
    #         selectOperations="extend",
    #         filter={
    #             "actionid": actionid,
    #             "eventsource": 0
    #         }
    #     )
    #     return action
    actions = zabbix.action.get(output=["actionid", "name", "status"], filter={"eventsource": 0})
    print(actions)
    return JsonResponse({'data': actions}, status=status.HTTP_200_OK)


def zabbix_del_action(action_id):
    action = zabbix.action.delete(
        action_id
    )
    return action


def get_interfaceis(hostid):
    interface = zabbix.hostinterface.get(
        output=["interfaceid", "ip"],
        # output="extend",
        hostids=hostid
    )
    return interface


def create_graph(name, itemid):
    graphid = zabbix.graph.create(
        {
            "name": name,
            "gitems": [
                {
                    "itemid": itemid,
                    "color": "ffdc60"
                },
            ]
        }
    )
    return graphid


def add_item(itemName, itemKey, hostId, valuetype, datatype, itemgroups, description, unit, interfaceId):
    item = zabbix.item.create({
        "name": itemName,
        "key_": itemKey,
        "hostid": hostId,
        "interfaceid": interfaceId,
        "type": 0,  # 0 - Zabbix agent; 1 - SNMPv1 agent;
        "value_type": valuetype,  # 0 - numeric float; 1 - character; 2 - log; 3 - numeric unsigned; 4 - text.
        "data_type": datatype,  # 0 - (default) decimal; 1 - octal; 2 - hexadecimal; 3 - boolean.
        "applications": itemgroups,
        "description": description,
        "units": unit,
        "delay": '30s'

    })
    return item


def get_application_by_hostid(hostid):
    applications = zabbix.application.get(output=["applicationid", "name"], filter={"hostid": hostid})
    return applications


def add_application(hostid, name):
    application = zabbix.application.create(
        name=name, hostid=hostid
    )
    return application


if __name__ == '__main__':
    # host_list()
    # group_list()
    # zabbix_templates_list()
    # 10001 2
    # zabbix_create_host("2", "compute2", "192.168.1.37", "10001")
    # host_list()
    # data = json.dumps(
    #     {
    #     "jsonrpc": "2.0",
    #     "method": "host.get",
    #     "params": {
    #         "filter": {
    #             "host": [
    #                 "Zabbix server",
    #             ]
    #         }
    #     },
    #     "auth": "038e1d7b1735c6a5436ee9eae095879e",
    #     "id": 1
    # })
    # # 将查询数据发送到zabbix-server
    # # 在post请求头部必须要有 'Content-Type': 'application/json-rpc'
    # headers = {'Content-Type': 'application/json-rpc'}
    # ret = requests.post(zbx_url, data=json.dumps(data), headers=headers)
    #
    # respone_result = ret.json()['result']  # 对结果进行json序列化
    #
    # print(respone_result)
    # host1 = cmc_zabbix_api.get_hostID("compute1")
    #
    # print(host1)
    # 通过key来帅选数据
    # item_list = zabbix.host.get(
    #     search={
    #         "host": 'compute1',
    #     },
    #     output="extend",
    # )
    # print(item_list[0].get('hostid'))
    # print(item_list[0].get('status'))

    # print(host1[0].get(output=["hostid"]))

    # templates_id = zabbix.template.get(
    #     filter={
    #         # 'templateid': '10001'
    #         'name': 'Template OS Linux by Zabbix agent'
    #     },
    #     output=['templateid'],
    # )
    # findtemplate = zabbix.template.get(
    #         templateids=['10001'],
    #         output=["host"],
    #     )
    # print(findtemplate[0].get("host"))

    # findgroup = zabbix.hostgroup.get(
    #     groupids=['2'],
    #     output=['name'],
    # )
    # print(findgroup[0].get('name'))

    # items = zabbix.item.get(output=["itemid", "name", "key_"], filter={"hostid": '10442'})
    # print(items)
    # print(zabbix.host.get(
    #     filter={"hostid": '10442'},
    #     output=["name", "status"]
    # ))
    # print(zabbix.host.update(
    #     hostid='10442',
    #     status=0,
    #     name='test',
    #     host='test2'
    #
    # ))
    # print(zabbix.host.get(
    #     filter={"hostid": '10442'},
    #     output=["name", "status", "host"]
    # ))

    pass
