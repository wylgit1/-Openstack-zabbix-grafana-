import os
import time

import requests
from django.http import JsonResponse
from pyzabbix import ZabbixAPI

# 登录zabbix
from rest_framework import status
from rest_framework.utils import json

from ccc_back.settings import BASE_DIR

zbx_url = "http://192.168.1.35/zabbix/api_jsonrpc.php"
zabbix = ZabbixAPI('http://192.168.1.35/zabbix')
zabbix.session.verify = False
zabbix.login('Admin', 'zabbix')
cmc_zabbix_api = ('http://192.168.1.35/zabbix', 'Admin', 'zabbix')


# zbx_url = "http://192.168.48.10/zabbix/api_jsonrpc.php"
# zabbix = ZabbixAPI('http://192.168.48.10/zabbix')
# zabbix.session.verify = False
# zabbix.login('Admin', 'zabbix')
# cmc_zabbix_api = ('http://192.168.48.10/zabbix', 'Admin', 'zabbix')

def testfile():
    # 判断用户是否添加了脚本
    sql_path = os.path.join(os.path.join(BASE_DIR, 'static'), 'item_file')
    print(sql_path)
    num = os.popen('ls %s|wc -l' % sql_path)
    print(num)
    rel = os.popen('ls' % sql_path)
    print(rel)

    # 如果添加了脚本获取脚本名称
    res = {'code': 200, 'msg': '添加成功'}
    abs_name = ''
    if num != 0:
        for root, dirs, files in os.walk(sql_path):
            # print(files[0])
            file_name = files[0]
            print(file_name)
            abs_name = os.path.join(sql_path, file_name)
        print(abs_name)


def search_it(paths, name):
    try:
        file_lis = os.listdir(paths)
    except:
        # print(paths, ": folder accessDenied")
        return False
    file_lis = os.listdir(paths)
    if file_lis.__contains__(name):
        print(f"{name}在{paths}内")
        print(f"文件的绝对路径为{os.path.join(paths, name)}")
        return True
    else:
        for item in file_lis:
            if search_it(os.path.join(paths, item), name):  # 如果递归的找到了这个文件
                return True  # 所有递归函数全部返回True
        print("找不到")
        return False


if __name__ == '__main__':
    # testfile()
    # paths = os.path.join(os.path.join(BASE_DIR, 'static'), 'item_file')
    # name = '1.docx'
    # search_it(paths,name)
    # createrepo1 = zabbix.template.create(
    #     host='templatetest1',
    #     groups=[{
    #         'groupid': '2'
    #     },{
    #         'groupid': '7'
    #     }]
    # )
    # print(createrepo1)

    # hostgroup = zabbix.hostgroup.get(output=["groupid", "name"])
    # print(hostgroup)

    # data = {'host_template_name': 'test',
    #         'value': [{'groupid': '2', 'name': 'Linux servers'}, {'groupid': '1', 'name': 'Templates'}]}
    # data2 = [{'groupid': '2', 'name': 'Linux servers'}, {'groupid': '1', 'name': 'Templates'}]
    # length = len(data.get("value"))
    # print(length)
    # # print(templatedata.post)
    # groups = [{'groupid': 0}, ]
    # i = 0
    # for item in data.get("value"):
    #     groups[i]["groupid"] = item.get("groupid")
    #     i = i + 1
    # print(groups)
    # print(zabbix.template.get(output=['templateid', 'name']))
    # createdata = zabbix.template.update(
    #     templateid="10446",
    #     name="template1101",
    #     groups=[{'groupid': '2'}, {'groupid': '1'}]
    # )
    # print(createdata)
    # action = zabbix.action.get(
    #     output="extend",
    #     filter={
    #         "eventsource": 0
    #     }
    # )
    # drules = zabbix.drule.get(
    #     output=["druleid", "name", "iprange", "delay", "status"]
    # )
    # print(drules)

    # hostList = zabbix.host.get(
    #     output=['host', 'hostid', 'name', 'available', 'status', 'interfaceids'],
    #     selectGroups=['name'],
    #     selectInterfaces=["ip"],
    # )
    # # print(hostList)

    # check=zabbix.dcheck.get(
    #     output=['extend','key_','type']
    # )
    # print(check)

    # items = zabbix.item.get(output=["itemid", "name", "key_"], filter={"hostid": 10084})
    # print(items)
    # applications = zabbix.application.get(output=["applicationid", "name"], filter={"hostid": 10084})
    # print(applications)
    # print(BASE_DIR)
    # /root/ccc/ccc_back
    # actions = zabbix.action.get(
    #     output=["actionid", "name", "status"],
    #     filter={
    #         "eventsource": 0
    #     }
    # )
    # print(actions)
    # print(zabbix.host.update(
    #     hostid='10465',
    #     status=1,
    #     name='test10000',
    #     host='192.168.1.62',
    # ))
    # drule = zabbix.drule.delete(
    #     8
    # )
    # print(drule)
    item = zabbix.item.get(
        output="extend",
        hostids="10084",
        search={
            "key_": "system.cpu.switches",
        },
        sortfield="name",
    )
    print(item)
    history = zabbix.history.get(
        output="extend",
        history=0,
        itemids="29163",
        sortorder="DESC",
        limit=10,
    )
    print(history)
    pass
