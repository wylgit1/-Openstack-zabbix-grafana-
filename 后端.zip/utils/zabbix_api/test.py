import json
import os
# from ansible.playbook.play import play

from ccc_back.settings import BASE_DIR


#
# s= {'actionid': '10',
#  'name': 'test1537',
# 'status': '0',
#  'operations': [
# 	{'operationid': '15',
# 	'actionid': '10',
# 	'operationtype': '1',
# 	'esc_period': '0',
# 	'esc_step_from': '1',
# 	 'esc_step_to': '1', 'evaltype': '0',
# 'opconditions': [{'opconditionid': '1', 'operationid': '15', 'conditiontype': '14', 'operator': '0', 'value': '0'}],
# 'opcommand': {'type': '0', 'scriptid': '0', 'execute_on': '0', 'port': '', 'authtype': '0', 'username': '',
# 		'password': '', 'publickey': '', 'privatekey': '', 'command': 'ls'},
#  'opcommand_hst': [{'opcommand_hstid': '2', 'hostid': '0'}],
#  'opcommand_grp': []}]}
# print(json.dumps(s))
import random


def testip():
    # ip = '192.168.1.106'
    # com = f'sed -i "/^Server=/cServer={ip}" /etc/ansible/zabbix_agentd.conf'
    # print(com)
    # test = os.popen(com)
    # print(test.read())
    # f = os.popen("ansible-playbook /etc/ansible/get-hostname.yaml")
    # # print(f.read())

    # com2=f'ansible {ip} -a "hostname"|tail -1'
    # com22=os.popen(com2)
    # print(com22.read())
    # 先在前端给ip地址中获取ansible配置文件中没有的ip地址
    # host_ip = ['192.168.1.106', '192.168.1.107']
    # tmp = []
    # for ip in host_ip:
    #     print(ip)
    #     # 查找是否存在
    #     com = 'cat /etc/ansible/hosts|grep %s|wc -l' % ip
    #     fr = os.popen(com)
    #     num = int(fr.read())
    #     # 不存在将IP加入tmp中
    #     if num == 0:
    #         tmp.append(ip)
    # print(tmp)
    name = "test"
    test = "ls"
    with open(f'/etc/ansible/{name}.yaml', 'w') as f:
        f.write(test)


if __name__ == '__main__':
    # testip()
    # with open('/etc/ansible/hosts', 'a') as object:
    #     ip='192.168.1.1'
    #     random_number = random.randint(1, 1000)
    #     name = "agent" + str(random_number)
    #     print(name)
    #     object.write(f"[{name}]")
    #     object.write('\n')
    #     object.write(ip)
    #     object.write('\n')
    # object.close()
    print(BASE_DIR)