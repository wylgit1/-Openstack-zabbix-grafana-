import requests
import json

from utils.zabbix_api.oldcmc_api.auth import zabbix_url, post_headers, zabbix_user, zabbix_pass


def get_zabbix_token():
    data = {
        "jsonrpc": "2.0",
        "method": "user.login",
        "params": {
            "user": zabbix_user,
            "password": zabbix_pass
        },
        "id": 0
    }
    r = requests.get(zabbix_url, headers=post_headers, data=json.dumps(data))
    auth = json.loads(r.text)
    return auth["result"]


def getGroups(token):
    data = {
        "jsonrpc": "2.0",
        "method": "hostgroup.get",
        "params": {
            "output": "extend",
            "filter": {
                "name": [
                    # 不写这个过滤下的话，会得到四五个多余的模板
                    "Templates",
                    "Templates/Applications",
                    "Templates/Databases",
                    "Templates/Modules",
                    "Templates/Network devices",
                    "Templates/Operating systems",
                    "Templates/Server hardware",
                    "Templates/Virtualization",
                    "Zabbix servers",
                ]
            }
        },
        "id": 2,
        "auth": token,

    }
    # zabbix_url和post_headers都是从old_api里面拿出来的
    request = requests.post(zabbix_url, headers=post_headers, data=json.dumps(data))
    dict = json.loads(request.content)
    return dict['result']


# 获取模板群组
def getTHostByGid(token, gid):
    data = {
        "jsonrpc": "2.0",
        "method": "template.get",
        "params": {
            "output": "extend",
            # "groupids": "4",获取zabbix server群组的所有主机，可能其他主机群组也行，但是这里没有试，然后用模板群组是获取不到值的
            "groupids": gid,
            "sortfield": "name"
        },
        # },
        "auth": token,
        "id": 1
    }
    request = requests.post(zabbix_url, headers=post_headers, data=json.dumps(data))
    dict = json.loads(request.content)
    return dict['result']


def getTemplateHost(token):
    data = {
        "jsonrpc": "2.0",
        "method": "template.get",
        "params": {
            "output": "extend",
            # "groupids": "4",获取zabbix server群组的所有主机，可能其他主机群组也行，但是这里没有试，然后用模板群组是获取不到值的
            "sortfield": "name"
        },
        # },
        "auth": token,
        "id": 1
    }
    request = requests.post(zabbix_url, headers=post_headers, data=json.dumps(data))
    dict = json.loads(request.content)
    return dict['result']


# 获取主机群组 暂时只有zabbix server
def getHostByGid(token, gid):
    data = {
        "jsonrpc": "2.0",
        "method": "host.get",
        "params": {
            "output": "extend",
            # "groupids": "4",获取zabbix server群组的所有主机，可能其他主机群组也行，但是这里没有试，然后用模板群组是获取不到值的
            "groupids": gid,
            "sortfield": "name"
        },
        # },
        "auth": token,
        "id": 1
    }
    request = requests.post(zabbix_url, headers=post_headers, data=json.dumps(data))
    dict = json.loads(request.content)
    return dict['result']


def getTriggerItems(token, hostname):
    data = {
        "jsonrpc": "2.0",
        "method": "item.get",
        "params": {
            "output": "extend",
            # "hostids": hostid,
            "host": hostname,
            "sortfield": "name"
        },
        "auth": token,
        "id": 1
    }
    request = requests.post(zabbix_url, headers=post_headers, data=json.dumps(data))
    dict = json.loads(request.content)
    return dict['result']


def create_trigger(token, description, expression):
    data = {
        "jsonrpc": "2.0",
        "method": "trigger.create",
        "params": [
            {
                "description": description,
                "expression": expression,
            },
        ],
        "auth": token,
        "id": 1
    }
    request = requests.post(zabbix_url, headers=post_headers, data=json.dumps(data))
    dict = json.loads(request.content)
    print(dict)
    return dict
