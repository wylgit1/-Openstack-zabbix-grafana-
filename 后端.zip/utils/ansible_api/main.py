from ansible.executor.task_queue_manager import TaskQueueManager
from ansible.module_utils.common.collections import ImmutableDict
from ansible.inventory.manager import InventoryManager
from ansible.parsing.dataloader import DataLoader
from ansible.playbook.play import Play
from ansible.plugins.callback import CallbackBase
from ansible.vars.manager import VariableManager
from ansible import context

context.CLIARGS = ImmutableDict(connection='smart', module_path=['/to/mymodules', '/usr/share/ansible'], forks=10,
                                become=None, become_method=None, become_user=None, check=False, diff=False, verbosity=0)
sources = 'hosts'
loader = DataLoader()
passwords = dict(vault_pass='secret')
inventory = InventoryManager(loader=loader, sources=sources)
inventory.add_group('test111')
inventory.add_host('192.168.1.36', group='test111')
print(inventory.get_groups_dict())
host = inventory.get_host('192.168.1.36')

# variable_manager.set_host_variable('192.168.72.132', 'ansible_ssh_user', 'root')
# variable_manager.set_host_variable('192.168.72.132', 'ansible_ssh_pass', '111111')
host.set_variable('ansible_ssh_user', 'root')
host.set_variable('ansible_ssh_pass', '111111')
print(inventory.get_host('192.168.1.36').get_vars())
play_source = dict(
    name="Ansible Play",
    hosts=['192.168.1.36'],
    gather_facts='no',
    tasks=[
        dict(action=dict(module='shell', args='ls'), register='shell_out'),
        dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}'))),
    ]
)
variable_manager = VariableManager(loader=loader, inventory=inventory)
play = Play().load(play_source, variable_manager=variable_manager, loader=loader)
tqm = TaskQueueManager(inventory=inventory, variable_manager=variable_manager, loader=loader, passwords=passwords, )
result = tqm.run(play)
print("@#")
print(result)
