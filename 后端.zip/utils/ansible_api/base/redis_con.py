import redis

from ccc_back import settings


# 连接类
class RedisConPool:
    # 连接方法
    @staticmethod
    def getRedisConnection():
        info = settings.REDSI_KWARGS_LPUSH
        if settings.REDSI_LPUSH_POOL == None:
            pools = redis.ConnectionPool(host=info.get('host'), port=info.get('port'),
                                         db=info.get('db'))
        else:
            pools = settings.REDSI_LPUSH_POOL
        connection = redis.Redis(connection_pool=pools)
        return connection


# redis中crud方法
class DsRedis:
    @staticmethod
    def lpush(redisKey, data):
        try:
            redisConn = RedisConPool.getRedisConnection()
            redisConn.lpush(redisKey, data)
            redisConn = None
        except:
            return False

    @staticmethod
    def rpop(self, redisKey):
        try:
            redisConn = RedisConPool.getRedisConnection()
            data = redisConn.rpop(redisKey)
            redisConn = None
            return data
        except:
            return False

    @staticmethod
    def delete(redisKey):
        try:
            redisConn = RedisConPool.getRedisConnection()
            data = redisConn.delete(redisKey)
            redisConn = None
            return data
        except:
            return False

    @staticmethod
    def setlock(rkey, value):
        try:
            redisConn = RedisConPool.getRedisConnection()
            redisConn.set(rkey, value)
            # redisConn.expire(redisKey, 1800)设置失效时间为1800s
            redisConn.expire(rkey, 1800)
            redisConn = None
        except:
            import traceback
            print(traceback.print_exc())
            return False

    @staticmethod
    def get(rkey):
        try:
            redisConn = RedisConPool.getRedisConnection()
            result = redisConn.get(rkey)
            redisConn = None
            return result
        except:
            return False


if __name__ == '__main__':
    DsRedis.setlock("tasklock", "0")
    lockstatus = DsRedis.get(rkey="tasklock")
    print(lockstatus)
