import pymongo
from datetime import datetime
from ccc_back.settings import MONGO_HOST, MONGO_PORT, BASE_DIR

if __name__ == '__main__':
    client = pymongo.MongoClient(MONGO_HOST, int(MONGO_PORT),username='root',password='123456')
    # 获取数据库
    db = client['iops']
    # 获取集合Collection
    col = db['tasklog']
    print(col)
    # 插入数据
    # re = col.insert_one({"name": "yl"})
    # print(re)
    # 查询集合下所有数据
    for x in col.find():  # 查询集合中所有文档数据并且遍历
        print(x)  # 输出
