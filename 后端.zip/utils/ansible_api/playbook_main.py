from ansible.executor.playbook_executor import PlaybookExecutor
from ansible.executor.task_queue_manager import TaskQueueManager
from ansible.module_utils.common.collections import ImmutableDict
from ansible.inventory.manager import InventoryManager
from ansible.parsing.dataloader import DataLoader
from ansible.playbook.play import Play
from ansible.plugins.callback import CallbackBase
from ansible.vars.manager import VariableManager
from ansible import context

context.CLIARGS = ImmutableDict(connection='smart', module_path=['/to/mymodules', '/usr/share/ansible'], forks=10,
                                become=None, become_method=None, become_user=None, check=False, diff=False, verbosity=0,syntax=None,start_at_task=None)
sources = 'hosts'
loader = DataLoader()
passwords = dict(vault_pass='secret')
inventory = InventoryManager(loader=loader, sources=sources)
# inventory.add_host('192.168.1.35', group='all')
# print(inventory.get_groups_dict())
host = inventory.get_host('192.168.1.35')
#
# # variable_manager.set_host_variable('192.168.72.132', 'ansible_ssh_user', 'root')
# # variable_manager.set_host_variable('192.168.72.132', 'ansible_ssh_pass', '111111')
host.set_variable('ansible_ssh_user', 'root')
host.set_variable('ansible_ssh_pass', '111111')
print(inventory.get_host('192.168.1.35').get_vars())
variable_manager = VariableManager(loader=loader, inventory=inventory)
executor = PlaybookExecutor(
                playbooks=['/root/ccc/ccc_back/utils/ansible_api/test0319.yaml'], inventory=inventory, variable_manager=variable_manager,
                loader=loader,
                passwords=passwords,
            )
print(executor.run())
