if __name__ == '__main__':
    resource = {
        "dynamic_host": {
            "hosts": [
                {'username': u'root', 'password': '123456', 'ip': '192.168.1.108', 'hostname': 'nginx01', 'port': '22'},
                {"hostname": "778da6afsdwf", "ip": "192.168.1.109", "port": "22", "username": "root",
                 "password": "123456"},
            ],
            "vars": {
                "var1": "ansible",
                "var2": "saltstack"
            }
        }
    }
    print(resource.get('dynamic_host').get('hosts'))