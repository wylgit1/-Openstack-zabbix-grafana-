#!/usr/bin/env python
# -*- coding=utf-8 -*-
# 执行 playbook 的核心类
import traceback
from ansible.executor.playbook_executor import PlaybookExecutor
# ansible 底层用到的任务队列管理器
from ansible.executor.task_queue_manager import TaskQueueManager
# 用于添加选项。比如: 指定远程用户remote_user=None
from ansible.module_utils.common.collections import ImmutableDict
# 管理资源库的，可以指定一个 inventory 文件等
from ansible.inventory.manager import InventoryManager
# 读取 json/ymal/ini 格式的文件的数据解析器
from ansible.parsing.dataloader import DataLoader
# 用于执行 Ad-hoc 的类 ,需要传入相应的参数
from ansible.playbook.play import Play
# 处理任务执行后返回的状态
from ansible.plugins.callback import CallbackBase
# 管理主机和主机组的变量管理器
from ansible.vars.manager import VariableManager
# context上下文管理器，他就是用来接收 ImmutableDict 的示例对象
from ansible import context, constants
# 对 主机、主机组 执行操作 ，可以给主机添加变量等操作，扩展
from ansible.inventory.host import Host, Group


class ModelResultsCollector(CallbackBase):

    def __init__(self, *args, **kwargs):
        super(ModelResultsCollector, self).__init__(*args, **kwargs)
        self.host_ok = {}
        self.host_unreachable = {}
        self.host_failed = {}

    def v2_runner_on_unreachable(self, result):
        self.host_unreachable[result._host.get_name()] = result

    def v2_runner_on_ok(self, result, *args, **kwargs):
        self.host_ok[result._host.get_name()] = result

    def v2_runner_on_failed(self, result, *args, **kwargs):
        self.host_failed[result._host.get_name()] = result


class PlayBookResultsCollector(CallbackBase):
    CALLBACK_VERSION = 2.0

    def __init__(self, *args, **kwargs):
        super(PlayBookResultsCollector, self).__init__(*args, **kwargs)
        self.task_ok = {}
        self.task_skipped = {}
        self.task_failed = {}
        self.task_status = {}
        self.task_unreachable = {}

    def v2_runner_on_ok(self, result, *args, **kwargs):
        self.task_ok[result._host.get_name()] = result

    def v2_runner_on_failed(self, result, *args, **kwargs):
        self.task_failed[result._host.get_name()] = result

    def v2_runner_on_unreachable(self, result):
        self.task_unreachable[result._host.get_name()] = result

    def v2_runner_on_skipped(self, result):
        self.task_ok[result._host.get_name()] = result

    def v2_playbook_on_stats(self, stats):
        hosts = sorted(stats.processed.keys())
        for h in hosts:
            t = stats.summarize(h)
            self.task_status[h] = {
                "ok": t['ok'],
                "changed": t['changed'],
                "unreachable": t['unreachable'],
                "skipped": t['skipped'],
                "failed": t['failures']
            }


class MyInventory:
    """
    this is IOPS ansible inventory object.
    """

    def __init__(self, resource, sources):
        self.resource = resource
        self.sources = sources
        self.loader = DataLoader()
        self.inventory = InventoryManager(loader=self.loader, sources=self.sources)
        self.variable_manager = VariableManager(loader=self.loader, inventory=self.inventory)
        self.dynamic_inventory()

    def add_dynamic_group(self, hosts, groupname, groupvars=None):
        """
            add hosts to a group
        """
        self.inventory.add_group(groupname)
        my_group = Group(name=groupname)
        # if group variables exists, add them to group
        if groupvars:
            for key, value in groupvars.items():
                my_group.set_variable(key, value)

        # add hosts to group
        for host in hosts:
            # set connection variables
            hostip = host.get('ip')
            hostport = host.get("port")
            username = host.get("username")
            password = host.get("password")
            self.inventory.add_host(host=hostip, group=groupname)
            my_host = self.inventory.get_host(hostip)
            my_host.set_variable('ansible_ssh_pass', password)
            my_host.set_variable('ansible_ssh_user', username)
            print("----------")
            print(my_host.get_vars())
            print(self.inventory.hosts)
            print('~~~~~~~groups')
            print(self.inventory.groups)
            # my_host.set_variable('ansible_ssh_private_key_file', ssh_key
            # set other variables
            for key, value in host.items():
                if key not in ["ip", "hostname", "port", "username", "password"]:
                    my_host.set_variable(key, value)
                    # self.variable_manager.set_host_variable(host=my_host, varname=key, value=value)

            # add to group

            # self.inventory.add_host(host=hostname, group=groupname, port=hostport)

    def dynamic_inventory(self):
        """
            add hosts to inventory.
        """
        if isinstance(self.resource, list):
            self.add_dynamic_group(self.resource, 'default_group')
        elif isinstance(self.resource, dict):
            for groupname, hosts_and_vars in self.resource.items():
                self.add_dynamic_group(hosts_and_vars.get("hosts"), groupname, hosts_and_vars.get("vars"))


class Run:
    def __init__(self, resource,redisKey=None,logId=None, *args, **kwargs):
        self.resource = resource
        self.inventory = None
        self.loader = DataLoader()
        self.passwords = {}
        self.callback = None
        self.variable_manager = None
        self.__initializeData()
        self.variable_manager = VariableManager(self.loader, self.inventory)
        self.redisKey = redisKey
        self.logId = logId
        context.CLIARGS = ImmutableDict(connection='smart', module_path=['/to/mymodules', '/usr/share/ansible'],
                                        forks=10,
                                        become=None, become_method=None, become_user=None, check=False, diff=False,
                                        verbosity=0, syntax=None, start_at_task=None)

    def __initializeData(self):

        # 实例化 资产配置对象
        myinvent = MyInventory(self.resource, '/root/ccc/ccc_back/utils/ansible_api/hosts')  # 调用动态添加
        self.inventory = myinvent.inventory

    def run_model(self, host_list, module_name, module_args):
        """
        run module from andible ad-hoc.
        module_name: ansible module_name
        module_args: ansible module args
        """

        play_source = dict(
            name="Ansible Play",
            hosts=host_list,
            gather_facts='no',
            tasks=[dict(action=dict(module=module_name, args=module_args), register='shell_out')]
        )
        play = Play().load(play_source, variable_manager=self.variable_manager, loader=self.loader)
        tqm = None
        # if self.redisKey:self.callback = ModelResultsCollectorToSave(self.redisKey,self.logId)
        # else:self.callback = ModelResultsCollector()
        self.callback = ModelResultsCollector()
        import traceback
        try:
            tqm = TaskQueueManager(
                inventory=self.inventory,
                variable_manager=self.variable_manager,
                loader=self.loader,
                passwords=self.passwords,
                # stdout_callback="minimal",
            )
            tqm._stdout_callback = self.callback
            constants.HOST_KEY_CHECKING = False  # 关闭第一次使用ansible连接客户端是输入命令
            tqm.run(play)
        except Exception as err:
            print(traceback.print_exc())
            # DsRedis.OpsAnsibleModel.lpush(self.redisKey,data=err)
            # if self.logId:AnsibleSaveResult.Model.insert(self.logId, err)
        finally:
            if tqm is not None:
                tqm.cleanup()

    def run_playbook(self, playbook_path):
        """
        run ansible palybook
        """
        try:
            # if self.redisKey:self.callback = PlayBookResultsCollectorToSave(self.redisKey,self.logId)
            self.callback = PlayBookResultsCollector()
            print('~~~~~')
            print(self.inventory.groups.get('all'))
            print(playbook_path)
            executor = PlaybookExecutor(
                playbooks=playbook_path, inventory=self.inventory, variable_manager=self.variable_manager,
                loader=self.loader,
                passwords=self.passwords,
            )
            executor._tqm._stdout_callback = self.callback
            constants.HOST_KEY_CHECKING = False  # 关闭第一次使用ansible连接客户端是输入命令
            print(executor.run())

        except Exception as err:
            print("打印异常")
            traceback.print_exc()
            return False

    def get_model_result(self):
        self.results_raw = {'success': {}, 'failed': {}, 'unreachable': {}}
        # print(self.callback.task_ok)
        # print(self.callback.task_failed)

        for host, result in self.callback.host_ok.items():
            hostvisiable = host.replace('.', '_')
            self.results_raw['success'][hostvisiable] = result._result

        for host, result in self.callback.host_failed.items():
            hostvisiable = host.replace('.', '_')
            self.results_raw['failed'][hostvisiable] = result._result

        for host, result in self.callback.host_unreachable.items():
            hostvisiable = host.replace('.', '_')
            self.results_raw['unreachable'][hostvisiable] = result._result

        # return json.dumps(self.results_raw)
        return self.results_raw

    def get_playbook_result(self):
        self.results_raw = {'skipped': {}, 'failed': {}, 'ok': {}, "status": {}, 'unreachable': {}, "changed": {}}
        for host, result in self.callback.task_ok.items():
            self.results_raw['ok'][host] = result._result
        for host, result in self.callback.task_failed.items():
            self.results_raw['failed'][host] = result._result
        for host, result in self.callback.task_status.items():
            self.results_raw['status'][host] = result
        # for host, result in self.callback.task_changed.items():
        #     self.results_raw['changed'][host] = result
        for host, result in self.callback.task_skipped.items():
            self.results_raw['skipped'][host] = result._result
        for host, result in self.callback.task_unreachable.items():
            self.results_raw['unreachable'][host] = result._result
        return self.results_raw


if __name__ == '__main__':
    resource = {
        "dynamic_host": {
            "hosts": [
                {'username': 'root', 'password': '11111', 'ip': '192.168.1.36', 'port': '22', },
            ],
        }
    }
    rbt = Run(resource)
    rbt.run_model(host_list=['192.168.1.36'], module_name='shell', module_args="ls")
    data = rbt.get_model_result()
    # rbt.run_playbook(playbook_path=['/etc/ansible/openfile.yaml'])
    # data = rbt.get_playbook_result()
    print(data)
