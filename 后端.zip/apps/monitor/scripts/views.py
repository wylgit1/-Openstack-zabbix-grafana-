import json

import datetime
from django.http import JsonResponse, HttpResponse
from django.shortcuts import render

# Create your views here.
from requests import Response
from rest_framework import status

from apps.monitor.scripts.models import Scripts, Playbooks, ConnectionInfo
from apps.monitor.scripts.serializer import ScriptsSerializer, PlaybooksSerializer
from utils.ansible_api.ansible_main import Run
from utils.viewset.CccViewSet import CccViewSet

from utils.ansible_api.base.MgCon import *
from utils.ansible_api.base.redis_con import *
from utils.ansible_api.lib.utils import prpcrypt


class ScriptsView(CccViewSet):
    """
    list:查询
    create:新增
    update:修改
    retrieve:单例
    destroy:删除
    """
    queryset = Scripts.objects.all()
    serializer_class = ScriptsSerializer

    def addscripts(self, request):
        # sdata = Scripts.objects.filter(scriptsId=1)
        # print(sdata.values()[0])
        print(request)
        data = json.loads(request.body.decode())
        print(data)
        name = data.get("scriptsName")
        content = data.get("scriptsContent")
        description = data.get("scriptsDescription")
        with open(f'/etc/ansible/{name}.yaml', 'w') as f:
            f.write(content)
        scriptdata = {'scriptsName': name, 'scriptsFilePath': f'/etc/ansible/{name}.yaml',
                      'scriptsDescription': description}
        serializer = self.get_serializer(data=scriptdata)
        # serializer = ScriptsSerializer(Scripts, data=scriptdata)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        print(scriptdata)
        return JsonResponse(data=scriptdata, status=status.HTTP_200_OK, safe=False)


class PlaybooksView(CccViewSet):
    """
    list:查询
    create:新增
    update:修改
    retrieve:单例
    destroy:删除
    """
    queryset = Playbooks.objects.all()
    serializer_class = PlaybooksSerializer

    def addplaybook(self, request):
        # sdata = Scripts.objects.filter(scriptsId=1)
        # print(sdata.values()[0])
        print(request)
        data = json.loads(request.body.decode())
        print(data)
        funcName = data.get("funcName")
        nickName = data.get("nickName")
        playbook = data.get("playbook")
        with open(f'/etc/ansible/{nickName}.yaml', 'w') as f:
            f.write(playbook)
        playbookdata = {'funcName': funcName, 'nickName': nickName,
                        'playbook': playbook}
        serializer = self.get_serializer(data=playbookdata)
        # serializer = ScriptsSerializer(Scripts, data=scriptdata)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        print(playbookdata)
        return JsonResponse(data=playbookdata, status=status.HTTP_200_OK, safe=False)

    def executeplaybook(self, request):
        data = json.loads(request.body.decode())
        playbookdata = data.get('temp')
        hostsdata = data.get('multipleSelection')
        print(playbookdata)
        print(hostsdata)
        print(len(hostsdata))
        playbookname = playbookdata.get('nickName')
        playbookid = playbookdata.get('id')
        print(playbookname)
        hosts = []
        for i in range(len(hostsdata)):
            tempdata = {'username': hostsdata[i].get('server_name'), 'ip': hostsdata[i].get('server'),
                        'port': hostsdata[i].get('port'), 'password': hostsdata[i].get('passwd')}
            hosts.append(tempdata)
            print(hosts)
        print(hosts)

        resource = {
            "dynamic_host": {
                "hosts": [
                    {'username': 'root', 'password': '111111', 'ip': '192.168.1.35', 'port': '22', },
                ],
            }
        }
        resource["dynamic_host"]["hosts"] = hosts
        print(resource)
        adhoc_task(resource,playbookname,playbookid)
        # rbt = Run(resource)
        # # # rbt.run_model(host_list=['192.168.1.35'], module_name='shell', module_args="ls")
        # # # data = rbt.get_model_result()
        # rbt.run_playbook(playbook_path=[f'/etc/ansible/{playbookname}.yaml'])
        # data = rbt.get_playbook_result()
        # print(data)
        # data = json.dumps(data, indent=4, ensure_ascii=False, sort_keys=False, separators=(',', ':'))
        # with open('/root/ccc/ccc_back/static/result', 'a') as object:
        #     object.write(data)
        #     object.write('\n')
        # object.close()
        return JsonResponse(data=data, status=status.HTTP_200_OK, safe=False)


# --------------------日志部分--------------------

class DateEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, datetime):
            return obj.__str__()
        return json.JSONEncoder.default(self, obj)


# Create your views here.
# def adhoc_task(request):
#     if request.method == "POST":
#         result = {}
#         jobs = request.body
#         init_jobs = json.loads(jobs)
#
#         mod_type = init_jobs["mod_type"] if not init_jobs["mod_type"] else "shell"
#         sn_keys = init_jobs["sn_key"]
#         exec_args = init_jobs["exec_args"]
#         group_name = init_jobs["group_name"] if not init_jobs["group_name"] else "imoocc"
#         taskid = init_jobs.get("taskid")
#         if not sn_keys or not exec_args or not taskid:
#             result = {'status': "failed", "code": 0o02, "info": "传入的参数mod_type不匹配！"}
#             return HttpResponse(json.dumps(result), content_type="application/json")
#         else:
#             # 实例化传入taskid
#             rlog = InsertAdhocLog(taskid=taskid)
#         if mod_type not in ("shell", "yum", "copy"):
#             result = {'status': "failed", "code": 0o03, "info": "传入的参数不完整！"}
#             rlog.record(id=10008)
#         else:
#             # 按照先后顺序记录到mongo中
#             try:
#                 sn_keys = set(sn_keys)
#                 hosts_obj = ConnectionInfo.objects.filter(sn_key__in=sn_keys)
#                 rlog.record(id=10000)
#
#                 if len(sn_keys) != len(hosts_obj):
#                     rlog.record(id=40004)
#                 else:
#                     rlog.record(id=10002)
#                     resource = {}
#                     hosts_list = []
#                     vars_dic = {}
#                     # cn = prpcrypt()
#                     hosts_ip = []
#                     for host in hosts_obj:
#                         # sshpasswd = cn.decrypt(host.ssh_userpasswd)
#                         sshpasswd = host.ssh_userpasswd
#                         if host.ssh_type in (1, 2):
#                             """
#                             resource =  {
#                                 "dynamic_host": {
#                                     "hosts": [
#                                                 {"hostname": "192.168.1.108", "port": "22", "username": "root", "ssh_key": "/etc/ansible/ssh_keys/id_rsa"},
#                                                 {"hostname": "192.168.1.109", "port": "22", "username": "root","ssh_key": "/etc/ansible/ssh_keys/id_rsa"}
#                                               ],
#                                     "vars": {
#                                              "var1":"ansible",
#                                              "var2":"saltstack"
#                                              }
#                                 }
#                             }
#                             """
#                             hosts_list.append(
#                                 {"hostname": host.sn_key, "ip": host.ssh_hostip, "port": host.ssh_host_port,
#                                  "username": host.ssh_username, "ssh_key": host.ssh_rsa})
#                             # hosts_ip.append(host.sn_key)
#                             hosts_ip.append(host.ssh_hostip)
#                         elif host.ssh_type in (0, 4):
#                             hosts_list.append(
#                                 {"hostname": host.sn_key, "ip": host.ssh_hostip, "port": host.ssh_host_port,
#                                  "username": host.ssh_username, "password": sshpasswd})
#                             # hosts_ip.append(host.sn_key)
#                             hosts_ip.append(host.ssh_hostip)
#                         elif host.ssh_type == 3:
#                             hosts_list.append(
#                                 {"hostname": host.sn_key, "ip": host.ssh_hostip, "port": host.ssh_host_port,
#                                  "username": host.ssh_username, "ssh_key": host.ssh_rsa, "password": sshpasswd})
#                             # hosts_ip.append(host.sn_key)
#                             hosts_ip.append(host.ssh_hostip)
#                     resource[group_name] = {"hosts": hosts_list, "vars": vars_dic}
#                     rlog.record(id=10004)
#                     # 任务锁检查
#                     lockstatus = DsRedis.get(rkey="tasklock")
#                     print("!!!!!!!!!!!!!!!!!!")
#                     print(lockstatus)
#                     print(hosts_list)
#                     if lockstatus is False or lockstatus == '1':
#                         # 已经有任务在执行
#                         rlog.record(id=40005)
#                     else:
#                         # 开始执行任务
#                         DsRedis.setlock("tasklock", 1)
#                         jdo = Run(resource=resource, redisKey='1')
#                         print("hosts_ip=========")
#                         print(hosts_ip)
#                         jdo.run_model(host_list=hosts_ip, module_name=mod_type, module_args=exec_args)
#                         res = jdo.get_model_result()
#                         rlog.record(id=19999, input_con=res)
#                         rlog.record(id=20000)
#                         DsRedis.setlock("tasklock", 0)
#                         result = {"status": "success", "info": res}
#
#             except Exception as e:
#                 import traceback
#                 print(traceback.print_exc())
#                 DsRedis.setlock("tasklock", 0)
#                 result = {"status": "failed", "code": 0o05, "info": e}
#             finally:
#                 return HttpResponse(json.dumps(result), content_type="application/json")
def adhoc_task(resource,playbookname,playbookid):
    # if request.method == "POST":
    #     result = {}
    #     jobs = request.body
    #     init_jobs = json.loads(jobs)
    #
    #     mod_type = init_jobs["mod_type"] if not init_jobs["mod_type"] else "shell"
    #     sn_keys = init_jobs["sn_key"]
    #     exec_args = init_jobs["exec_args"]
    #     group_name = init_jobs["group_name"] if not init_jobs["group_name"] else "imoocc"
    #     taskid = init_jobs.get("taskid")
    #     if not sn_keys or not exec_args or not taskid:
    #         result = {'status': "failed", "code": 0o02, "info": "传入的参数mod_type不匹配！"}
    #         return HttpResponse(json.dumps(result), content_type="application/json")
    #     else:
    #         # 实例化传入taskid
    #         rlog = InsertAdhocLog(taskid=taskid)
    #     if mod_type not in ("shell", "yum", "copy"):
    #         result = {'status': "failed", "code": 0o03, "info": "传入的参数不完整！"}
    #         rlog.record(id=10008)
    #     else:
    #         # 按照先后顺序记录到mongo中
    #         try:
    #             sn_keys = set(sn_keys)
    #             hosts_obj = ConnectionInfo.objects.filter(sn_key__in=sn_keys)
    #             # hosts_obj = ConnectionInfo.objects.filter(sn_key__in=sn_keys)
    #             rlog.record(id=10000)
    #             if len(sn_keys) != len(hosts_obj):
    #                 rlog.record(id=40004)
    #             else:
    #                 rlog.record(id=10002)
    #                 resource = {}
    #                 hosts_list = []
    #                 vars_dic = {}
    #                 # cn = prpcrypt()
    #                 hosts_ip = []
    #                 for host in hosts_obj:
    #                     # sshpasswd = cn.decrypt(host.ssh_userpasswd)
    #                     sshpasswd = host.ssh_userpasswd
    #                     if host.ssh_type in (1, 2):
    #                         """
    #                         resource =  {
    #                             "dynamic_host": {
    #                                 "hosts": [
    #                                             {"hostname": "192.168.1.108", "port": "22", "username": "root", "ssh_key": "/etc/ansible/ssh_keys/id_rsa"},
    #                                             {"hostname": "192.168.1.109", "port": "22", "username": "root","ssh_key": "/etc/ansible/ssh_keys/id_rsa"}
    #                                           ],
    #                                 "vars": {
    #                                          "var1":"ansible",
    #                                          "var2":"saltstack"
    #                                          }
    #                             }
    #                         }
    #                         """
    #                         hosts_list.append(
    #                             {"hostname": host.sn_key, "ip": host.ssh_hostip, "port": host.ssh_host_port,
    #                              "username": host.ssh_username, "ssh_key": host.ssh_rsa})
    #                         # hosts_ip.append(host.sn_key)
    #                         hosts_ip.append(host.ssh_hostip)
    #                     elif host.ssh_type in (0, 4):
    #                         hosts_list.append(
    #                             {"hostname": host.sn_key, "ip": host.ssh_hostip, "port": host.ssh_host_port,
    #                              "username": host.ssh_username, "password": sshpasswd})
    #                         # hosts_ip.append(host.sn_key)
    #                         hosts_ip.append(host.ssh_hostip)
    #                     elif host.ssh_type == 3:
    #                         hosts_list.append(
    #                             {"hostname": host.sn_key, "ip": host.ssh_hostip, "port": host.ssh_host_port,
    #                              "username": host.ssh_username, "ssh_key": host.ssh_rsa, "password": sshpasswd})
    #                         # hosts_ip.append(host.sn_key)
    #                         hosts_ip.append(host.ssh_hostip)
    #                 resource[group_name] = {"hosts": hosts_list, "vars": vars_dic}
        result = {}
        # 实例化传入taskid
        rlog = InsertAdhocLog(taskid=playbookid)
        rlog.record(id=10000)
        if resource['dynamic_host']['hosts'] is None:
              rlog.record(id=40004)
        else:
              rlog.record(id=10002)

        try:
                rlog.record(id=10004)
                # 任务锁检查
                lockstatus = DsRedis.get(rkey="tasklock")
                print("!!!!!!!!!!!!!!!!!!")
                print(lockstatus)
                # print(hosts_list)
                # if lockstatus is False or lockstatus == '1':
                if lockstatus == '1':
                    # 已经有任务在执行
                    rlog.record(id=40005)
                else:
                    # 开始执行任务
                    DsRedis.setlock("tasklock", 1)
                    jdo = Run(resource=resource, redisKey='1')
                    # print("hosts_ip=========")
                    # print(hosts_ip)
                    # jdo.run_model(host_list=hosts_ip, module_name=mod_type, module_args=exec_args)
                    jdo.run_playbook(playbook_path=[f'/etc/ansible/{playbookname}.yaml'])
                    res = jdo.get_playbook_result()
                    rlog.record(id=19999, input_con=res)
                    rlog.record(id=20000)
                    DsRedis.setlock("tasklock", 0)
                    result = {"status": "success", "info": res}
        except Exception as e:
            import traceback
            print(traceback.print_exc())
            DsRedis.setlock("tasklock", 0)
            result = {"status": "failed", "code": 0o05, "info": e}
        finally:
            return HttpResponse(json.dumps(result), content_type="application/json")


# Create your views here.
def adhoc_task_log(request):
    if request.method == "GET":
        taskid = request.GET.get("taskid")
        result = {}
        if taskid:
            rlog = InsertAdhocLog(taskid=taskid)
            res = rlog.getrecord()
            result = {"status": "success", 'taskid': taskid, "info": res}
        else:
            result = {"status": "failed", "info": "没有传入taskid值"}
        res = json.dumps(result, cls=DateEncoder)
        return HttpResponse(res, content_type="application/json")


def delete_task_log(request):
    if request.method == "DELETE":
        taskid = request.GET.get("taskid")
        print(taskid)
        result = {}
        if taskid:
            rlog = DeleteAdhocLog(taskid=taskid)
            res = rlog.deleterecord()
            result = {"status": "success", 'taskid': taskid, "info": res}
        else:
            result = {"status": "failed", "info": "没有传入taskid值"}
        return HttpResponse(result, content_type="application/json")
