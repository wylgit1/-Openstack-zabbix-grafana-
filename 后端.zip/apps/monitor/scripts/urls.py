# -- coding: utf-8 --

from django.urls import path, re_path
from django.conf.urls import url

from utils.zabbix_api.action_api import zabbix_get_trigger_by_hostid, zabbix_create_action, get_scripts, create_trigger
from utils.zabbix_api.auto_api import zabbix_drule_list, zabbix_create_drule, zabbix_delete_drule
from . import views
from .views import ScriptsView, PlaybooksView, adhoc_task, adhoc_task_log,delete_task_log

urlpatterns = [
    # # 接受文件
    # path('addscripts/', views.addscripts,name="addscripts"),
    path('addscripts/', ScriptsView.as_view({'post': 'addscripts'})),
    path('addplaybook/', PlaybooksView.as_view({'post': 'addplaybook'})),
    path('executeplaybook/', PlaybooksView.as_view({'post': 'executeplaybook'})),
    path('adhocdo/', adhoc_task),
    path('adhoclog', adhoc_task_log),
    path('deletelog',delete_task_log)
]
