# -- coding: utf-8 --

from django.urls import path, re_path
from django.conf.urls import url

from utils.zabbix_api.action_api import zabbix_get_trigger_by_hostid, zabbix_create_action, get_scripts, create_trigger
from utils.zabbix_api.auto_api import zabbix_drule_list, zabbix_create_drule, zabbix_delete_drule
from . import views
from utils.zabbix_api.host_api import zabbix_templates_list, zabbix_add_template, zabbix_delete_template, \
    zabbix_group_list, zabbix_delete_group, zabbix_add_group, zabbix_host_list, zabbix_item_list, zabbix_delete_item, \
    zabbix_get_application, zabbix_delete_application, zabbix_get_action
from .views import GetGroupsView, GetHostsView, GetTriggerItemView

urlpatterns = [
    # re_path(r'^\?page=(\d+)$', VMInformationView.get_page)
    # 模板
    #     url(r'^get/templates/$', views.GetTemplatesView.as_view()),
    #     url(r'^get/template_data/$', views.GetTemplatesDataView.as_view()),
    #     url(r'^add/template/$', views.AddTemplateView.as_view()),
    #     url(r'^del/template/$', views.DelTemplateView.as_view()),

    path('get/host/', zabbix_host_list),
    path('get/template/', zabbix_templates_list),
    path('add/template/', zabbix_add_template),
    path('delete/template/', zabbix_delete_template),

    path('get/group/', zabbix_group_list),
    path('add/group/', zabbix_add_group),
    path('delete/group/', zabbix_delete_group),

    path('get/drules/', zabbix_drule_list),
    path('add/drules/', zabbix_create_drule),
    path('delete/drules/', zabbix_delete_drule),

    # path('consoleurl/', openstack_get_consoleurl),
    #
    # # 监控项
    path('delete/item/', zabbix_delete_item),
    path('get/host_item_date/', zabbix_item_list),
    # path('create/item/', views.AddItemView.as_view()),
    # path('get/application_date/', views.GetApplication_View.as_view()),
    # # 接受文件
    # path('get/file/', views.GetFileView.as_view()),
    # # 应用集
    # path('delete/application/', zabbix_delete_application),
    # path('add/application/', zabbix_delete_application),
    # path('get/application/', zabbix_get_application),
    # 解决方案
    path('get/action/', zabbix_get_action),
    # path('add_action/', views.add_action,name="add_action"),
    path('add/action/',zabbix_create_action),
    # path('test/', views.test()),
    # url(r'^share/jiemi/$', views.GetSolutionView.as_view()),
    path('get_groups/', GetGroupsView.as_view()),
    path('get_hosts/', GetHostsView.as_view()),
    path('get/trigger/', zabbix_get_trigger_by_hostid),
    path('create/trigger/', views.createTrigger),
    path('get/script/', get_scripts),
    path('get_childtriggers/', GetTriggerItemView.as_view()),

]
