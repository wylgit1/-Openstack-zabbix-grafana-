from django.shortcuts import render
import json
import os, sys, stat
from django import http
import base64

from django.http import HttpResponse, JsonResponse
from django.shortcuts import render
import urllib.request as urllib2
from django.core import serializers
from django.views import View
from rest_framework.views import APIView
from rest_framework_jwt.authentication import jwt_decode_handler

from utils.viewset.CccViewSet import CccViewSet
from utils.zabbix_api.host_api import get_application_by_hostid
from ..hosts.models import Hosts
from .models import Trigger, citem
from utils.zabbix_api.oldcmc_api.auth import zabbix_header, zabbix_url, auth_code
from apps.monitor.trigger.models import Trigger
from apps.monitor.trigger.serializer import TriggerSerializer
# Create your views here.
from utils.get_groups_hosts import *


# class TriggerView(CccViewSet):
#     """
#     的管理接口
#     list:查询
#     create:新增
#     update:修改
#     retrieve:单例
#     destroy:删除
#     """
#     queryset = Trigger.objects.all()
#     serializer_class = TriggerSerializer
#     create_api = openstack_create_server_volumes
#     update_api = openstack_update_volumes
#     destroy_api = openstack_delete_volumes
#     reCreate = None

def add_triggers(request):
    if request.method == "POST":
        triggersname = request.POST.get('triggersname')
        condition = request.POST.get('condition')
        description = request.POST.get('description')
        severity = request.POST.get('severity')
        # request json //create host
        judge = request.POST.get('judge')
        if judge == "0":
            json_data = {
                "jsonrpc": "2.0",
                "method": "trigger.create",
                "params": {
                    "description": triggersname,
                    "expression": condition,
                    "comments": description,
                    "priority": severity
                },
                "auth": auth_code,
                "id": 1
            }
        # 用得到的SESSIONID去验证，获取主机的信息(用http.get方法)
        else:
            triggersId = request.POST.get('triggersId')
            json_data = {
                "jsonrpc": "2.0",
                "method": "trigger.update",
                "params": {
                    "triggerid": triggersId,
                    "description": triggersname,
                    "expression": condition,
                    "comments": description,
                    "priority": severity
                },
                "auth": auth_code,
                "id": 1
            }
        if len(auth_code) == 0:
            sys.exit(1)
        if len(auth_code) != 0:
            host_create_data = json.dumps(json_data, ensure_ascii=False)
            # print host_create_data
            host_create_data = host_create_data.encode()
            # create request object

            request2 = urllib2.Request(zabbix_url, host_create_data)
            for key in zabbix_header:
                request2.add_header(key, zabbix_header[key])

            # get host list
            try:
                result = urllib2.urlopen(request2)
            except Exception as e:
                print("Exception as e")
                print(e)
            else:
                print("Exception as e的else")
                response = json.loads(result.read())
                result.close()
                print(response)

                trigger_data = {'triggersname': triggersname, 'condition': condition, 'description': description,
                                'severity': severity}
                # ---name和condition写入txt
                fp = open("/root/ENV/smartwarehouse/smartwarehouse/zabbix_api/old_api/trigger_condition.txt", 'w+')
                fp.write(triggersname)
                fp.write("\n")
                fp.write(condition)
                fp.close()
                os.system('python3 /root/ENV/smartwarehouse/smartwarehouse/zabbix_api/old_api/zabbix_gettrigger.py')
                os.system('python3 /root/ENV/smartwarehouse/smartwarehouse/zabbix_api/old_api/trigger_condition.py')
                ai_triggerid = int(response['result']['triggerids'][0].encode("utf-8"))  # 通过zabbix_creattrigger中返回值获取ID
                triggerid = ai_triggerid
                return render(request, 'old_cmc/add_triggers.html', locals())
    if 'updatetriggersId' in request.GET:  # 必须有if
        print("enter if 'updatetriggersId' in request.GET?")
        updatetriggersId = request.GET['updatetriggersId']
        os.system('python3 /root/ENV/smartwarehouse/smartwarehouse/zabbix_api/old_api/zabbix_gettrigger.py')
        trigger = Trigger.objects.values().filter(triggerId=updatetriggersId)  # 取数据库的数据,取出的是ValuesQuerySet对象
        trigger = list(trigger)  # 先转化为list，然后转化为json
        return HttpResponse(json.dumps(trigger), content_type='application/json')
    # 刚刚点击添加触发器时会先进到这个fbv，但是都不满足条件，所以直接到这里
    return render(request, 'old_cmc/add_triggers.html', {'hostip': '192.168.43.135:8000'})


def add_triggers_child(request):
    os.system('python3 /root/ENV/smartwarehouse/smartwarehouse/zabbix_api/old_api/zabbix_gethost.py')
    host = Hosts.objects.all()
    os.system('python3 /root/ENV/smartwarehouse/smartwarehouse/zabbix_api/old_api/zabbix_getitem.py')
    item = citem.objects.all()
    # 下面两步将数据库获得的queryset格式转换为json格式
    data = serializers.serialize("json", item)
    data1 = json.dumps(data)
    # print(data1)

    return render(request, 'old_cmc/add_triggers_child.html', locals())


def add_action(request):
    # 获取主机信息
    os.system('python3 /root/ccc/ccc_back/utils/zabbix_api/oldcmc_api/zabbix_gethost.py')
    host = Hosts.objects.all()
    # 获取监控项信息
    os.system('python3 /root/ccc/ccc_back/utils/zabbix_api/oldcmc_api/zabbix_getitem.py')
    item = citem.objects.all()
    # 下面两步将数据库获得的queryset格式转换为json格式
    data = serializers.serialize("json", item)
    data1 = json.dumps(data)
    # 获取t触发器信息
    os.system('python3 /root/ccc/ccc_back/utils/zabbix_api/oldcmc_api/zabbix_gettrigger.py')
    trigger = Trigger.objects.all()
    # 下面两步将数据库获得的queryset格式转换为json格式
    data2 = serializers.serialize("json", trigger)
    data3 = json.dumps(data2)
    username = request.GET.get('username')
    request.session['username'] = username
    # 如果是添加动作的请求
    if request.method == "POST":
        actionName = request.POST.get('actionName')
        hostId = request.POST.get('hostId')
        itemId = request.POST.get('itemId')
        osc = request.POST.get('osc')
        triggerId = request.POST.get('triggerId')
        # ---------------------------------------------取list-----------------------------
        from1 = request.POST.getlist('from1')
        OpcommandhostId1 = request.POST.getlist('OpcommandhostId1')
        hostip = request.POST.getlist('hostip')
        print("这是hostip", hostip)
        commands1 = request.POST.getlist('Commands1')
        stepduration1 = request.POST.getlist('stepduration1')
        # -----------------------------上为命令 下为邮件-------------------------------------
        stepduration2 = request.POST.getlist('stepduration2')
        from2 = request.POST.getlist('from2')
        mediatype2 = request.POST.getlist('mediatype2')
        # ----------------------------对list进行填充进json-----------------------------
        # ---------执行命令------------
        json_command = []  # 给一个空列表
        n = len(from1)
        for m in range(n):
            json_command1 = {
                "operationtype": 1,
                "esc_period": stepduration1[m],
                "esc_step_from": from1[m],
                "esc_step_to": from1[m],
                "evaltype": 0,
                "opconditions": [
                    {
                        "conditiontype": 14,  # Type of condition. Possible values: 14 - event acknowledged.
                        "operator": 0,  #
                        "value": "0"
                    }
                ],
                "opcommand_hst": [
                    {
                        "hostid": OpcommandhostId1[m],
                    }
                ],
                "opcommand": {
                    "type": 0,  # Possible values: 0 - custom script; 1 - IPMI; 2 - SSH; 3 - Telnet; 4 - global script.
                    "command": commands1[m],  # Command to run.
                    "execute_on": 0,  # Possible values: 0 - Zabbix agent; 1 - Zabbix server.
                }
            }
            json_command.append(json_command1)  # 加入[]
        # ----------发邮件------------
        json_mail = []
        i = len(from2)
        for j in range(i):
            json_mail1 = {
                "operationtype": 0,
                "esc_period": stepduration2[j],
                "esc_step_from": from2[j],
                "esc_step_to": from2[j],
                "evaltype": 0,
                "opmessage_grp": [
                    {
                        "usrgrpid": "7"
                    }
                ],
                "opmessage": {
                    "default_msg": 1,
                    "mediatypeid": mediatype2[j],
                }
            }

            json_mail.append(json_mail1)  # 加入[]
        # --------------------拼接直接相加list------
        json_html = json_command + json_mail
        judge = request.POST.get('judge')
        if judge == "0":
            json_data = {
                "jsonrpc": "2.0",
                "method": "action.create",
                "params": {
                    "name": actionName,  # action名字
                    "eventsource": 0,  # 0 - event created by a trigger;
                    "status": 0,
                    "esc_period": osc,
                    "def_shortdata": "{TRIGGER.STATUS}: {TRIGGER.NAME}",
                    "def_longdata": "{\r\n\"Trigger status\": \"{TRIGGER.STATUS}\",\r\n\"Trigger name\": \"{TRIGGER.NAME}\",\r\n\"Trigger severity\": \"{TRIGGER.SEVERITY}\",\r\n\"Action name\": \"{ACTION.NAME}\",\r\n\"Event ID\": \"{EVENT.ID}\",\r\n\"Event value\": \"{EVENT.VALUE}\",\r\n\"Event status\": \"{EVENT.STATUS}\", \r\n\"Event time\": \"{EVENT.TIME}\",\r\n\"Event date\": \"{EVENT.DATE}\",\r\n\"Event age\": \"{EVENT.AGE}\",\r\n\"Event acknowledgement\": \"{EVENT.ACK.STATUS}\",\r\n\"Event acknowledgement history\": \"{EVENT.ACK.HISTORY}\",\r\n\"Item values\": \"{ITEM.NAME1} ({HOST.NAME1}:{ITEM.KEY1}): {ITEM.VALUE1}\",\r\n\"Original event ID\": \"{EVENT.ID}\"\r\n}",
                    "recovery_msg": 1,
                    "r_longdata": "{\r\n\"Trigger status\": \"{TRIGGER.STATUS}\",\r\n\"Trigger name\": \"{TRIGGER.NAME}\",\r\n\"Trigger severity\": \"{TRIGGER.SEVERITY}\",\r\n\"Action name\": \"{ACTION.NAME}\",\r\n\"Event ID\": \"{EVENT.ID}\",\r\n\"Event value\": \"{EVENT.VALUE}\",\r\n\"Event status\": \"{EVENT.STATUS}\", \r\n\"Event time\": \"{EVENT.TIME}\",\r\n\"Event date\": \"{EVENT.DATE}\",\r\n\"Event age\": \"{EVENT.AGE}\",\r\n\"Event acknowledgement\": \"{EVENT.ACK.STATUS}\",\r\n\"Event acknowledgement history\": \"{EVENT.ACK.HISTORY}\",\r\n\"Item values\": \"{ITEM.NAME1} ({HOST.NAME1}:{ITEM.KEY1}): {ITEM.VALUE1}\",\r\n\"Original event ID\": \"{EVENT.ID}\"\r\n}",
                    "r_shortdata": "{TRIGGER.STATUS}: {TRIGGER.NAME}",
                    "filter": {
                        "evaltype": 0,  # 0 - and/or; 1 - and; 2 - or; 3 - custom expression.
                        "conditions": [
                            {
                                "conditiontype": 2,
                                # Possible values for trigger actions: 0 - host group; 1 - host; 2 - trigger; 3 - trigger name;
                                # 4 - trigger severity; 5 - trigger value; 6 - time period; 13 - host template; 15 - application; 16 - maintenance status.
                                "operator": 0,
                                # Possible values: 0 - (default) =; 1 - <>; 2 - like; 3 - not like; 4 - in; 5 - >=; 6 - <=; 7 - not in.
                                "value": triggerId  # triggerid
                            },
                        ],

                    },
                    "operations": json_html,
                    "recovery_operations": json_mail,

                },
                "auth": auth_code,
                "id": 1
            }
            # print(json_data)
        if len(auth_code) == 0:
            sys.exit(1)  # 有错误退出
        if len(auth_code) != 0:
            host_create_data = json.dumps(json_data)
            host_create_data = host_create_data.encode()
            request2 = urllib2.Request(zabbix_url, host_create_data)  # urllib2可以接受一个Request类的实例来设置URL请求的headers
            for key in zabbix_header:
                request2.add_header(key, zabbix_header[key])
            try:
                result = urllib2.urlopen(request2)  # urllib2.Request.urlopen打开
            except Exception as e:
                print(e)
            else:
                response = json.loads(result.read())
                result.close()
                print(response)
                action_data = {"actionName": actionName}
                # --------------------------------下面为保存脚本以及下发脚本的代码-----------------------------------#
                username = request.GET.get('username')
                print(username)
                # 为某个用户的某个动作创建文件夹
                os.makedirs('/etc/zabbix/script/%s/action/%s' % (username, actionName))
                text1 = request.POST.getlist('text1')  # 将前端标签内容获取下来存入text1变量中
                stepname = request.POST.getlist('sname')
                text23 = request.FILES.getlist('upload_script')
                filename = request.POST.get('filename')  # 上传文件名
                filename = filename.split('.')
                filename = filename[-1]  # 上传文件后缀，即类型
                nn = len(from1)
                for i in range(nn):
                    if text1[i] != "":
                        # 写入step1的执行脚本
                        fp = open("/etc/zabbix/script/%s/action/%s/%sM.py" % (username, actionName, stepname[i]),
                                  'w+')  # 新建，替换读写，r+不能创建，只替换
                        fp.write(text1[i])
                        fp.close()
                        os.chmod("/etc/zabbix/script/%s/action/%s/%sM.py" % (username, actionName, stepname[i]),
                                 stat.S_IRWXU | stat.S_IRWXG | stat.S_IRWXO)  # mode:777
                        # ------------cmc和zabbix不再一起
                        if hostip[i] == "127.0.0.1":
                            sendip = myhostip
                        else:
                            sendip = hostip[i]
                        print(sendip)
                        # 创建不存在的文件夹
                        fs = os.popen(
                            'ssh %s mkdir -p /etc/zabbix/script/%s/action/%s' % (sendip, username, actionName))
                        print(fs.read())
                        mm2 = 'scp -p /etc/zabbix/script/%s/action/%s/%sM.py %s:/etc/zabbix/script/%s/action/%s/%sM.py' % (
                            username, actionName, stepname[i], sendip, username, actionName, stepname[i])
                        print(mm2)
                        f = os.popen(mm2)
                        print(f.read())
                        # 上传的
                        with open(
                                '/etc/zabbix/script/%s/action/%s/%s.%s' % (username, actionName, stepname[i], filename),
                                'wb+') as destination:
                            for chunk in text23[i].chunks():
                                destination.write(chunk)
                        os.chmod(
                            "/etc/zabbix/script/%s/action/%s/%s.%s" % (username, actionName, stepname[i], filename),
                            stat.S_IRWXU | stat.S_IRWXG | stat.S_IRWXO)  # mode:777
                        mm3 = 'scp -p /etc/zabbix/script/%s/action/%s/%s.%s %s:/etc/zabbix/script/%s/action/%s/%s.%s' % (
                            username, actionName, stepname[i], filename, sendip, username, actionName, stepname[i],
                            filename)
                        fr = os.popen(mm3)
                        print(fr.read())
                return render(request, 'old_cmc/add_action.html', locals())
        # -----------------------update-----------------------
    # print(type(locals()))
    myhostip = "192.168.72.132"
    return render(request, 'old_cmc/add_action.html', locals())


def test():
    print("123")


def add_action_child(request):
    username = request.GET.get('username')
    print("这是子窗口的用户信息", username)
    if request.method == "POST":
        item_name = request.POST.get('item_name')
        action_name = request.POST.get('actionName')
        item_key = request.POST.get('item_key')
        host = request.POST.get('host')
        text1 = request.POST.get('text')
        text2 = request.FILES.get('upload_script')
        os.makedirs('/etc/zabbix/script/%s/action/%s' % (username, action_name))
        fp = open("/etc/zabbix/script/%s/action/%s/%s.sh" % (username, action_name, item_name), 'w+')
        fp.write(text1)
        fp.close()
        return render(request, 'old_cmc/add_action_child.html', locals())
    return render(request, 'old_cmc/add_action_child.html', locals())


def createTrigger(request):
    # request.POST.get是form表单要这样获取数据的,
    # 其他的类似http://192.168.43.135:8000/create_trigger/?triggername=triggername&operationaldata=operationaldata,
    # 还是得要用request.GET.get()获取数据
    print(request)
    triggername = request.GET.get('triggername')
    operationaldata = request.GET.get('operationaldata')
    severity = request.GET.get("severity")
    expression = request.GET.get("expression")
    print("expression")
    print(expression)
    description = request.POST.get("description")
    res = {'code': 2020, 'msg': '', 'data': ""}
    zabbix_token = get_zabbix_token()
    result = create_trigger(zabbix_token, triggername, expression)
    if result.get('result') is not None:
        res['msg'] = "触发器创建成功"
        res['data'] = result
    else:
        res['msg'] = "触发器创建失败"
    return JsonResponse(res)


class GetGroupsView(APIView):
    def get(self, request):
        res = {'code': 2013, 'msg': '主机群组获取成功', 'data': ""}
        zabbix_token = get_zabbix_token()
        result = getGroups(zabbix_token)
        res['data'] = result
        print(res)
        return JsonResponse(res)


class GetHostsView(APIView):
    def get(self, request):
        gid = request._request.GET.get("groupid")
        print("--------------")
        print(type(gid))
        res = {'code': 2014, 'msg': '主机获取成功', 'data': ""}
        zabbix_token = get_zabbix_token()
        if gid == "1":
            # template
            print("gid==1 choice")
            result = getTemplateHost(zabbix_token)
        elif gid == "4":
            # zabbix server
            print("gid==4 choice")
            result = getHostByGid(zabbix_token, gid)
        else:
            result = getTHostByGid(zabbix_token, gid)
        res['data'] = result
        print(res)
        return JsonResponse(res)


class GetTriggerItemView(APIView):
    def get(self, request):
        hostname = request._request.GET.get("hostname")
        print(hostname)
        res = {'code': 2015, 'msg': '触发器获取成功', 'data': ""}
        zabbix_token = get_zabbix_token()
        result = getTriggerItems(zabbix_token, hostname)
        # state是决定监控项状态的
        res['data'] = result
        return JsonResponse(res)


class GetSolutionView(View):
    def get(self, request):
        jiemi = request.GET.get("jiemi")
        print(json.dumps(jiemi))
        jiemi = json.loads(jiemi)
        # print(type(jiemi))
        # 根据前端返回的数据生成脚本文件
        for step in jiemi["desc"]:
            com = step.get('com')
            # 获取文件保存的路径
            tmp = com.split(' ')
            path = tmp[-1]
            print(path)
            # 解密文件内容
            com_jiami = step.get('com_jiami')
            com_jiami = com_jiami.replace(' ', '+')
            com_jiami = com_jiami.encode()
            s2 = base64.decodebytes(com_jiami)
            s2 = s2.decode()
            # 写入文件内容
            with open(path, 'w') as fp:
                fp.write(s2)
        res = {'code': 200, 'msg': '添加成功', 'data': []}
        return http.JsonResponse(res)

