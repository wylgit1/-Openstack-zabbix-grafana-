from django.db import models


# Create your models here.
# 触发器表
class Trigger(models.Model):
    triggerId = models.IntegerField(primary_key=True)
    triggerName = models.CharField(max_length=255)
    triggerValue = models.IntegerField()
    triggerPriority = models.IntegerField()
    itemId = models.IntegerField()
    triggerDescription = models.CharField(null=True, max_length=255)
    condition = models.CharField(null=True, max_length=10000)

    # 返回相应的值
    def __unicode__(self):
        return self.triggerId


class citem(models.Model):
    itemId = models.IntegerField(primary_key=True)
    itemName = models.CharField(max_length=255)
    itemKey = models.CharField(max_length=255)
    itemStatus = models.IntegerField()
    # templateId = models.IntegerField(null=True,max_length=10)
    hostId = models.IntegerField()
    interfaceId = models.IntegerField()
    valuetype = models.IntegerField(null=True)
    datatype = models.IntegerField(null=True)
    units = models.CharField(null=True, max_length=255)
    applicationId = models.IntegerField(null=True)
    description = models.CharField(null=True, max_length=255)

    # 返回相应的值
    def __unicode__(self):
        return self.itemId
