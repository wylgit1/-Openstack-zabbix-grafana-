# -- coding: utf-8 --

from django.urls import path, re_path
from django.conf.urls import url

from utils.zabbix_api.auto_api import zabbix_drule_list, zabbix_create_drule, zabbix_delete_drule
from . import views
from utils.zabbix_api.host_api import zabbix_templates_list, zabbix_add_template, zabbix_delete_template, \
    zabbix_group_list, zabbix_delete_group, zabbix_add_group, zabbix_host_list, zabbix_item_list, zabbix_delete_item, \
    zabbix_get_application, zabbix_delete_application, zabbix_get_action, zabbix_delete_host, zabbix_update_host

urlpatterns = [
    # re_path(r'^\?page=(\d+)$', VMInformationView.get_page)
    # 模板
    #     url(r'^get/templates/$', views.GetTemplatesView.as_view()),
    #     url(r'^get/template_data/$', views.GetTemplatesDataView.as_view()),
    #     url(r'^add/template/$', views.AddTemplateView.as_view()),
    #     url(r'^del/template/$', views.DelTemplateView.as_view()),
    path('get/host/', zabbix_host_list),
    path('update/host/', zabbix_update_host),
    path('create/host/', views.CreateHostsView.as_view()),
    path('get/hosts_already/', views.GetHostsAlreadyView.as_view()),
    path('delete/host/', zabbix_delete_host),
    path('get/template/', zabbix_templates_list),
    path('add/template/', zabbix_add_template),
    path('delete/template/', zabbix_delete_template),

    path('get/group/', zabbix_group_list),
    path('add/group/', zabbix_add_group),
    path('delete/group/', zabbix_delete_group),

    path('get/drules/', zabbix_drule_list),
    path('add/drules/', zabbix_create_drule),
    path('delete/drules/', zabbix_delete_drule),

    # path('consoleurl/', openstack_get_consoleurl),
    #
    # # 监控项
    path('delete/item/', zabbix_delete_item),
    path('get/host_item_date/', zabbix_item_list),
    path('create/item/', views.AddItemView.as_view()),
    path('get/application_date/', views.GetApplication_View.as_view()),
    # 接受文件
    path('get/file/', views.GetFileView.as_view()),
    # # 应用集
    path('delete/application/', zabbix_delete_application),
    path('add/application/',  views.AddApplicationView.as_view()),
    path('get/application/', zabbix_get_application),
    # 解决方案
    path('get/action/', zabbix_get_action),

    # 密码管理页面
    path('del/server/<int:id>/', views.ServerDetailAPIView.as_view()),
    path('server/', views.ServerListAPIView.as_view()),


]
