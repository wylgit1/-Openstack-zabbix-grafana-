# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models
from utils.models import BaseModel


# Create your models here.
class Hosts(models.Model):
    host_id = models.CharField(max_length=50)
    host = models.CharField(max_length=50)
    available = models.CharField(default=None,max_length=200)
    status = models.CharField(default=None, max_length=20)
    host_ip = models.CharField(default=None, max_length=200)
    group_id = models.CharField(max_length=50)
    template_id = models.CharField(max_length=50)

    # class Meta:
    #     verbose_name = "服务器密码管理"
    #     verbose_name_plural = verbose_name
    #
    # def __str__(self):
    #     return self.server

class HostPassMan(BaseModel):
    server = models.CharField(max_length=20)
    port = models.SmallIntegerField()
    server_name = models.CharField(max_length=50)
    passwd = models.CharField(default=None,max_length=200)
    master = models.CharField(default=None, max_length=20)
    remark = models.CharField(default=None, max_length=200)
    isConfidentialityFree = models.BooleanField(default=False,max_length=20)
    class Meta:
        verbose_name = "服务器密码管理"
        verbose_name_plural = verbose_name

    def __str__(self):
        return self.server
