from rest_framework import serializers

from utils.serializer.CccSerializer import CccSerializer
from .models import Hosts, HostPassMan


# Serializer相当于View和Model的中间层，避免view频繁直接操作model object的同时，规范数据字段格式、内容、validator、提供序列化数据等等，同时可以定义方法实现对model的特定操作。

class HostsSerializer(CccSerializer):
    class Meta:
        model = Hosts
        fields = '__all__'

class HostPassManSerialzier(serializers.ModelSerializer):
    """
        服务器账号密码管理的序列化器
    """

    class Meta:
        model = HostPassMan
        fields = "__all__"
