import os

import json

import random
from django import http
from django.shortcuts import render

# Create your views here.
from rest_framework.views import APIView

from apps.monitor.hosts import models, serializer
from apps.monitor.hosts.models import Hosts, HostPassMan
from apps.monitor.hosts.serializer import HostsSerializer, HostPassManSerialzier
from ccc_back.settings import BASE_DIR
from utils.zabbix_api.host_api import zabbix_create_host, zabbix_delete_host, zabbix_update_host, zabbix_group_list, \
    zabbix_templates_list, zabbix, get_interfaceis, create_graph, add_item, add_application, get_application_by_hostid, \
    create_host
from utils.viewset.CccViewSet import CccViewSet
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework import status
from django.views import View


class HostsView(CccViewSet):
    """
    HOSTS主机的管理接口
    list:查询
    create:新增
    update:修改
    retrieve:单例
    destroy:删除
    """
    queryset = Hosts.objects.all()
    serializer_class = HostsSerializer
    create_api = zabbix_create_host
    update_api = zabbix_update_host
    destroy_api = zabbix_delete_host

    @action(methods=['get'], detail=False)
    # 得到前端渲染所需数据
    def get_grp_tmp(self, request):
        """
        调用openstack的api给前端用于初始化
        """
        try:
            # 嵌套字典
            Msg = {}
            print("1111")
            print(Msg)
            Msg['group'] = zabbix.hostgroup.get(output=['groupid', 'name'])
            Msg['template'] = zabbix.template.get(output=['templateid', 'name'])
            print("创建信息")
            print(Msg)
            Msg['code'] = 200
            return Response(Msg, status=status.HTTP_200_OK)
        except Exception as e:
            print("出现异常")
            dict = {}
            dict['code'] = status.HTTP_400_BAD_REQUEST
            return Response(dict)


class GetFileView(View):
    def post(self, request):
        try:
            # 写入之前删除文件
            # os.popen("rm -rf /root/ENV/smartwarehouse/smartwarehouse/static/item_file/*")
            files = request.FILES.getlist("file", None)  # 接收前端传递过来的多个文件
            for file in files:
                print(file.name)
                sql_path = os.path.join(os.path.join(BASE_DIR, 'static'), 'item_file')
                sql_path = os.path.join(sql_path, file.name)
                print(sql_path)
                # 写入文件
                with open(sql_path, 'wb') as f:
                    for content in file.chunks():
                        # print(content)
                        f.write(content)
            return http.JsonResponse({'code': 200, 'msg': '添加成功'})
        except Exception as e:
            return http.JsonResponse({'code': 400, 'msg': '添加失败'})


class AddItemView(View):
    def post(self, request):
        # 格式化前端发送的数据，并接受
        data = json.loads(request.body.decode())
        print(data)
        item_application = data.get('item_application')
        item_name = data.get('item_name')
        item_key = data.get('item_key')
        item_data_type = data.get('item_data_type')
        item_shuju_typtem_desc = data.get('item_shuju_type')
        item_desc = data.get('item_desc')
        hostid = data.get('hostid')
        unit = data.get('unit')
        # 首先根据hostid获取interfaceid
        interfaceid = get_interfaceis(hostid)[0]['interfaceid']
        ip = get_interfaceis(hostid)[0]['ip']
        # 调用zabbix-api添加监控项
        item = add_item(item_name, item_key, hostid, item_data_type, item_shuju_typtem_desc, item_application,
                        item_desc, unit, interfaceid)
        print(item)
        # 为新添加的item创建图像
        itemid = item["itemids"][0]
        create_graph(item_name, itemid)
        # 判断用户是否添加了脚本
        sql_path = os.path.join(os.path.join(BASE_DIR, 'static'), 'item_file')
        print(sql_path)
        num = os.popen('ls %s|wc -l' % sql_path)

        print(num)
        # 如果添加了脚本获取脚本名称
        res = {'code': 200, 'msg': '添加成功'}
        abs_name = ''
        if num != 0:
            for root, dirs, files in os.walk(sql_path):
                # print(files[0])
                file_name = files[0]
                print(file_name)
                abs_name = os.path.join(sql_path, file_name)
            print(abs_name)
            # 如果用户上传的脚本需要脚本，将脚本上传到用户的指定目录，并添加监控项键值到配置文件
            os.popen("scp %s %s:/etc/zabbix/" % (abs_name, ip))
            abs_name2 = '/etc/zabbix/' + file_name
            print(abs_name2)
            str = "UserParameter=%s,sh %s" % (item_key, abs_name2)
            print(str)
            os.popen('ansible %s -m shell -a "echo %s >> /etc/zabbix/zabbix_agentd.conf"' % (ip, str))
            # 重启zabbix-agent客户端
            os.popen('ansible %s -m service -a "name=zabbix-agent state=restarted enabled=yes"' % ip)
            return http.JsonResponse(res)
        else:
            if item:
                return http.JsonResponse(res)
            else:
                res["dode"] = 400
                res["msg"] = "添加监控项失败"
                return http.JsonResponse(res)


class GetApplication_View(View):
    def get(self, request):
        try:
            hostid = request.GET.get("hostid")
            print(hostid)
            applications = get_application_by_hostid(hostid)
            # print(applications)
            if applications:
                res = {'code': 200, 'msg': '获取成功', 'applications': applications}
                return http.JsonResponse(res)
            else:
                res = {'code': 400, 'msg': '获取失败'}
                return http.JsonResponse(res)
        except Exception as e:
            res = {'code': 400, 'msg': '删除失败'}
            return http.JsonResponse(res)


class AddApplicationView(View):
    def post(self, request):
        # 添加主机
        data = json.loads(request.body.decode())
        print(data)
        hostid = data.get('hostid')
        application_name = data.get('application_name')
        # print(host_name)
        application = add_application(hostid, application_name)
        if application:
            res = {'code': 200, 'msg': '添加成功'}
            return http.JsonResponse(res)
        else:
            res = {'code': 400, 'msg': '添加成功'}
            return http.JsonResponse(res)


###########################下面是管理服务器账号密码的视图实现###################################
class ServerListAPIView(APIView):
    def get(self, request):
        query_set = HostPassMan.objects.all()
        serializer = HostPassManSerialzier(query_set, many=True)
        return Response(serializer.data)

    def post(self, request):
        """新增一条数据"""
        # 创建序列化对象
        serializer = HostPassManSerialzier(data=request.data)
        # 验证参数合法性
        # 设置raise_exception=True后，出错时，会给客户端返回json出错信息
        serializer.is_valid(raise_exception=True)
        # 保存部门到数据库表中
        serializer.save()
        print(serializer.data)
        ip = serializer.data.get('server')
        server_name = serializer.data.get('server_name')
        passwd = serializer.data.get('passwd')
        f = os.popen('sshpass -p%s ssh-copy-id %s@%s -o StrictHostKeyChecking=no' % (passwd, server_name, ip))
        print(f.read())
        # 返回响应对象
        return Response(serializer.data)


class ServerDetailAPIView(APIView):

    def put(self, request, pk):
        """修改一条数据"""
        try:
            host = HostPassMan.objects.get(pk=pk)
        except Exception as e:
            return Response(status=status.HTTP_404_NOT_FOUND)
        serializer = HostPassManSerialzier(host, data=request.data)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(serializer.data)

    def get(self, request, id):
        """删除一条数据"""
        try:
            host = HostPassMan.objects.get(pk=id)
            f = os.popen("sed -i '/%s/d' /root/.ssh/known_hosts" % host)
        except Exception as e:
            return Response(status=status.HTTP_404_NOT_FOUND)
        host.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)


####################################主机相关###
###获取所有主机或者主机组的主机
def host_list(group=None):
    if group:
        return zabbix.host.get(
            output=['host', 'hostid', 'name', 'available', 'status'],
            groupids=[group],
            selectGroups=['name']
        )
    else:
        return zabbix.host.get(
            output=['host', 'hostid', 'name', 'available', 'status', 'interfaceids'],
            selectGroups=['name'],
            selectInterfaces=["ip"],
        )


# 1.host
class GetHostsAlreadyView(View):
    def get(self, request):
        try:
            hosts = HostPassMan.objects.all()
            serializer = HostPassManSerialzier(hosts, many=True)
            # 获取已经添加免密的所有主机
            # print(serializer.data)
            hosts_list = []
            # 获取已经监控了的主机
            hosts = host_list()
            #  将已经监控了的主机放到一个数组里
            interfaces = []
            for j in hosts:
                interfaces.append(j['interfaces'][0]['ip'])
            print(interfaces)
            # 对已经监控了的主机进行排除
            for i in serializer.data:
                if i["server"] not in interfaces:
                    tmp = {}
                    tmp["label"] = i["server"]
                    tmp["value"] = i["server"]
                    hosts_list.append(tmp)
            # print(hosts_list)
            res = {'code': 200, 'msg': '删除成功', 'data': hosts_list}
            return http.JsonResponse(res)
        except Exception as e:
            res = {'code': 400, 'msg': '删除成功'}
            return http.JsonResponse(res)


class CreateHostsView(View):
    def post(self, request):
        # 添加主机
        data = json.loads(request.body.decode())
        # 两种添加主机的方式，先打印看看
        print(data)
        try:
            host_name = data.get('host')
            host_ip = data.get('host_ip')
            host_group = int(data.get('group_id'))
            host_template = int(data.get('template_id'))
            print(create_host(host_name,
                              host_ip,
                              host_group,
                              host_template))
        except:
            # 获取前端想要给ansible添加的ip地址
            host_ip = data.get('rightData')
            # print(host_ip)
            # 获取ansible配置文件中已经添加了的ip地址
            """方法一,即将停止服务"""
            """
            loader = DataLoader()
            inventory = InventoryManager(loader=loader, sources="/etc/ansible/hosts")
            hosts = []
            hosts += inventory.list_hosts()
            print(hosts)
            """
            """方法二，手动判断"""
            # 先在前端给ip地址中获取ansible配置文件中没有的ip地址
            tmp = []
            for ip in host_ip:
                print(ip)
                # 查找是否存在
                com = 'cat /etc/ansible/hosts|grep %s|wc -l' % ip
                fr = os.popen(com)
                num = int(fr.read())
                # 不存在将IP加入tmp中
                if num == 0:
                    tmp.append(ip)
            print(tmp)
            # 将前端给的但是ansible中并没有进行配置的ip地址写入到ansible的配置文件当中
            with open('/etc/ansible/hosts', 'a') as object:
                for i in tmp:
                    random_number = random.randint(1, 1000)
                    agentname = "agent" + str(random_number)
                    print(agentname)
                    object.write(f"[{agentname}]")
                    object.write('\n')
                    object.write(i)
                    object.write('\n')
            object.close()
            # 替换agent配置文件中的ip和hostname
            for ip in tmp:
                replace_agentname = f'sed -i "/^- hosts:/c- hosts: {agentname}" /etc/ansible/main.yaml'
                rpan = os.popen(replace_agentname)
                print(rpan)
                get_hostname = f'ansible {ip} -a "hostname"|tail -1'
                hostname = os.popen(get_hostname).read()
                print(hostname)
                # serverip 为server端ip 我的server端装在192.168.1.35
                # 需要关闭防火墙
                # systemctl stop firewalld.service  # 停止firewall
                # systemctl disable firewalld.service  # 禁止firewall开机启动
                # systemctl status firewalld.service  # 查看防火墙状态
                # 放行10050端口
                # #放行10050端口
                # firewall-cmd --zone=public --add-port=10050/tcp --permanent
                # #重启防火墙
                # firewall-cmd --reload
                replace_ip1 = 'sed -i "/^Server=/cServer=192.168.1.35" /etc/ansible/zabbix_agentd.conf'
                replace_ip2 = 'sed -i "/^ServerActive=/cServerActive=192.168.1.35" /etc/ansible/zabbix_agentd.conf'
                replace_hostname = f'sed -i "/^Hostname=/cHostname={hostname}" /etc/ansible/zabbix_agentd.conf'
                rp1 = os.popen(replace_ip1)
                rp2 = os.popen(replace_ip2)
                rph = os.popen(replace_hostname)
                print(rp1.read())
                print(rp2.read())
                print(rph.read())
                # 执行剧本
                f = os.popen("ansible-playbook /etc/ansible/main.yaml")
                print(f.read())
                host_name = data.get('host')
                host_ip = ip
                host_group = int(data.get('group_id'))
                host_template = int(data.get('template_id'))
                print(create_host(host_name,
                                  host_ip,
                                  host_group,
                                  host_template))
        res = {'code': 200, 'msg': '添加成功'}
        return http.JsonResponse(res)
