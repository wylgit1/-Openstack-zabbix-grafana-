from django.db import models
from django.contrib.auth.models import AbstractUser, UserManager,BaseUserManager


# class UserManage(BaseUserManager):
#     # _表示是受保护的，只能在这个类中可以调用
#     def _create_user(self, telephone, username, password, **kwargs):
#         if not telephone:
#             raise ValueError('必须要传递手机号')
#         if not password:
#             raise ValueError('必须要输入密码')
#         user = self.model(telephone=telephone, username=username, **kwargs)
#         user.set_password(password)
#         user.save()
#         return user
#
#     # 创建普通用户
#     def create_user(self, telephone, username, password, **kwargs):
#         kwargs['is_superuser'] = False
#         return self._create_user(telephone=telephone, username=username, password=password, **kwargs)
#
#     # 创建超级用户
#     def create_superuser(self, telephone, username, password, **kwargs):
#         kwargs['is_superuser'] = True
#         return self._create_user(telephone=telephone, username=username, password=password, **kwargs)


class User(AbstractUser):
    username = models.CharField(max_length=150, unique=True)
    USERNAME_FIELD = 'username'
    password = models.CharField(max_length=150, unique=True)
    type = models.IntegerField(null=True)
    client_ip = models.CharField(max_length=32, null=True)
    client_mac = models.CharField(max_length=64, null=True)
    student_name = models.CharField(max_length=15, null=True)
    student_number = models.IntegerField(null=True)
    student_password = models.CharField(max_length=128, null=True)

    class Meta(AbstractUser.Meta):
        pass

    # # 以上自定义的User模型上并没有objects方法，所以我们需要自定义
    objects = UserManager()

    def get_full_name(self):
        return self.username

    def get_short_name(self):
        return self.username
