# -*- coding: utf-8 -*-
from __future__ import unicode_literals

import hashlib

from rest_framework.response import Response
from rest_framework.utils import json

from apps.users.serializer import UserSerializer
#
# from .models import User
from django.http import JsonResponse
from rest_framework.views import APIView
from rest_framework import viewsets, status
from django.contrib.auth import get_user_model
from django.contrib.auth.hashers import make_password, check_password
from utils.viewset.CccViewSet import CccViewSet

User = get_user_model()


class UserInfo(APIView):
    def get(self, request, *args, **kwargs):
        res = {
            "code": 200,
            "msg": "获取用户信息成功",
            "data": []
        }
        try:
            userInfo = list(User.objects.filter(username=request.user.username).values())
            if len(userInfo) > 0:
                userInfo = userInfo[0]
            else:
                userInfo = {}
            res["data"] = userInfo
        except Exception as e:
            res["code"] = -1
            res["msg"] = f"获取用户信息失败, {e}"
        return JsonResponse(res)


class UserView(CccViewSet):
    queryset = User.objects.all()
    serializer_class = UserSerializer

    def register(self, request, *args, **kwargs):
        print(request)
        print(request.data)

        if request.method == "POST":
            #  获取用户输入的数据
            username = request.data.get("username")
            pwd = request.data.get("password")
            type = request.data.get("type")
            email = request.data.get("email")
            is_superuser = request.data.get("is_superuser")
            is_active = request.data.get("is_active")
            # 密码加密 使用pbkdf2_sha256加密
            print(username)
            print(pwd)
            password = make_password(pwd, None, 'pbkdf2_sha256')
            print(password)

            # 判断是否有数据
            content = "参数不全"
            ## 保存数据
            user = User()
            user.username = username
            user.password = password
            user.type = type
            user.email = email
            user.is_superuser = is_superuser
            user.is_active = is_active
            user.save()
            # data=json.dumps(user)
            content = "添加成功"
        return Response(status=status.HTTP_200_OK)
