# -- coding: utf-8 --

from django.urls import path
from .views import UserInfo, UserView

urlpatterns = [
    path('index/info/', UserInfo.as_view()),
    # path('getusernames/', UserInfo.as_view()),
]
