from django.db import models


class VMInformation(models.Model):
    VM_id=models.CharField(max_length=64,blank=True)
    nickname = models.CharField(max_length=32)
    VM_name = models.CharField(max_length=32, null=False)
    # client_mac = db.Column(db.String(64), unique=True, nullable=False)
    client_mac = models.CharField(max_length=64)
    ip = models.CharField(max_length=32, null=False)
    floating_ip = models.CharField(max_length=32)
    key = models.CharField(max_length=32, null=False)
    image = models.CharField(max_length=32, null=False)
    image_type = models.CharField(max_length=10, null=False)
    status = models.CharField(max_length=32, null=False)
    flavor = models.CharField(max_length=32, null=False)
    rent_time = models.IntegerField()
    sign = models.CharField(max_length=6, default='true')
    VM_security_group = models.CharField(max_length=255)
