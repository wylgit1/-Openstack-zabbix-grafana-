from django.apps import AppConfig


class VirtualMachineConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.virtual_machine'
