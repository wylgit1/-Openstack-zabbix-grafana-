from utils.serializer.CccSerializer import CccLinkedSerializer, CccSerializer
from .models import VMInformation


# Serializer相当于View和Model的中间层，避免view频繁直接操作model object的同时，规范数据字段格式、内容、validator、提供序列化数据等等，同时可以定义方法实现对model的特定操作。

class VMInformationSerializer(CccSerializer):
    class Meta:
        model = VMInformation
        fields = '__all__'
# __all__  =  [ 'bar' ,  'baz' ]
# 将fields属性设置为特殊属性'all'，以指示应使用模型中的所有字段。说白了就是将Meta模型中的所有字段填加到ModelForm元类里的属性
# 举个反例子：将ModelForm的内部元类的排除属性设置为将被排除在表单之外的字段列表。title字段不在ModelForm属性里
# exclude=['title']
