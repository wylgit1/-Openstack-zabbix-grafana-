from django.http import HttpResponse
from rest_framework.pagination import PageNumberPagination
from rest_framework.permissions import IsAdminUser, AllowAny
from rest_framework.response import Response
from rest_framework import status
from utils.viewset.CccViewSet import CccViewSet, CccPermission
from utils.openstack_api.vm.vm_api import openstack_create_vm, openstack_query_flavor, openstack_query_network, \
    openstack_query_key, openstack_query_host_image, openstack_query_floating_ip, openstack_query_security_group, \
    openstack_destroy_vm, openstack_update_vm
from .models import VMInformation
from .serializer import VMInformationSerializer
from rest_framework.decorators import action
from rest_framework import status, permissions


class VMInformationView(CccViewSet):
    """
    虚拟机的管理接口
    list:查询
    create:新增
    update:修改
    retrieve:单例
    destroy:删除
    """
    queryset = VMInformation.objects.all().order_by("id")
    serializer_class = VMInformationSerializer
    create_api = openstack_create_vm
    update_api = openstack_update_vm
    destroy_api = openstack_destroy_vm

    """实现方法一：通过action自己添加方法,参考链接
    https://q1mi.github.io/Django-REST-framework-documentation/api-guide/routers/#routing-for-extra-actions
    """

    """前段页面加载时进行调用"""

    # serializer.data['VM_id']=openstack_create_vm()

    @action(methods=['get'], detail=False, permission_classes=(CccPermission,), )
    # 得到前端渲染所需数据
    def getMsg(self, request):
        """
        调用openstack的api给前端用于初始化
        """
        try:
            # 嵌套字典
            Msg = {}
            print("1111")
            print(Msg)
            Msg['flavor'] = openstack_query_flavor()
            Msg['host_image'] = openstack_query_host_image()
            Msg['network'] = openstack_query_network()
            Msg['key'] = openstack_query_key()
            Msg['floating_ip'] = openstack_query_floating_ip()
            Msg['security_group'] = openstack_query_security_group()
            print(Msg)
            Msg['code'] = 200
            return Response(Msg,status=status.HTTP_200_OK)
        except Exception as e:
            print("出现异常")
            dict = {}
            dict['code'] = status.HTTP_400_BAD_REQUEST
            return Response(dict)

