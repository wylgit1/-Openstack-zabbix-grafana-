# -- coding: utf-8 --

from django.urls import path, re_path
from .views import VMInformationView

urlpatterns = [
    # re_path(r'^\?page=(\d+)$', VMInformationView.get_page)
]
