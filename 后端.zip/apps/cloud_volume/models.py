from django.db import models


# Create your models here.
class CloudVolume(models.Model):
    cloud_volume_id = models.CharField(max_length=64,blank=True)
    VM_id = models.CharField(max_length=64,blank=True)
    VM_name = models.CharField(max_length=64,blank=True)
    cloud_volume_name = models.CharField(max_length=64)
    cloud_volume_type = models.CharField(max_length=64)
    cloud_volume_size = models.IntegerField(null=True)
    cloud_volume_status = models.CharField(max_length=32,blank=True)
