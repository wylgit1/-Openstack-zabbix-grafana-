from django.shortcuts import render

# Create your views here.
from utils.openstack_api.cloud_volume.volume_api import openstack_create_server_volumes, openstack_delete_volumes, \
    openstack_update_volumes
from utils.viewset.CccViewSet import CccViewSet
from apps.cloud_volume.models import CloudVolume
from apps.cloud_volume.serializer import CloudVolumeSerializer


class CloudVolumeView(CccViewSet):
    """
    的管理接口
    list:查询
    create:新增
    update:修改
    retrieve:单例
    destroy:删除
    """
    queryset = CloudVolume.objects.all()
    serializer_class = CloudVolumeSerializer
    create_api = openstack_create_server_volumes
    update_api = openstack_update_volumes
    destroy_api = openstack_delete_volumes
    reCreate = None
