# -- coding: utf-8 --
from utils.openstack_api.cloud_volume.volume_api import openstack_allocate_server_volumes, \
    openstack_separate_server_volumes,openstack_get_server_volumes
from django.urls import path
urlpatterns = [
    path("allocate/", openstack_allocate_server_volumes),
    path("separate/", openstack_separate_server_volumes),
    path("getServerVolume/", openstack_get_server_volumes),

]
