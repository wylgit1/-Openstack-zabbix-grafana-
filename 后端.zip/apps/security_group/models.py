from django.db import models


# Create your models here.
# Field               | Type        | Null | Key | Default | Extra |
# +---------------------+-------------+------+-----+---------+-------+
# | security_group_id   | varchar(64) | NO   | PRI | NULL    |       |
# | VM_id               | varchar(64) | YES  | MUL | NULL    |       |
# | VM_name             | varchar(64) | YES  |     | NULL    |       |
# | security_group_name | varchar(64) | YES  |     | NULL    |       |
# | security_group_type | varchar(64) | YES  |     | NULL    |
class SecurityGroup(models.Model):
    security_group_id = models.CharField(max_length=64)
    VM_id = models.CharField(max_length=64, blank=True)
    VM_name = models.CharField(max_length=64)
    security_group_name = models.CharField(max_length=64)
    security_group_type = models.CharField(max_length=32)
