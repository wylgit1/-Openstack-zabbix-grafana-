from django.shortcuts import render

# Create your views here.
from apps.security_group.models import SecurityGroup
from apps.security_group.serializer import SecurityGroupSerializer
from utils.openstack_api.vm.vm_api import openstack_record_security_group, openstack_delete_security_group
from utils.viewset.CccViewSet import CccViewSet


class SecurityGroupView(CccViewSet):
    """
    安全组的管理接口
    list:查询
    create:新增
    update:修改
    retrieve:单例
    destroy:删除
    """
    queryset = SecurityGroup.objects.all()
    serializer_class = SecurityGroupSerializer
    create_api = openstack_record_security_group
    # update_api = openstack_update_vm
    destroy_api = openstack_delete_security_group


