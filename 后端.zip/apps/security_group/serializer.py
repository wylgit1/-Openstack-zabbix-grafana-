from utils.serializer.CccSerializer import CccSerializer
from .models import SecurityGroup


# Serializer相当于View和Model的中间层，避免view频繁直接操作model object的同时，规范数据字段格式、内容、validator、提供序列化数据等等，同时可以定义方法实现对model的特定操作。

class SecurityGroupSerializer(CccSerializer):
    class Meta:
        model = SecurityGroup
        fields = '__all__'
