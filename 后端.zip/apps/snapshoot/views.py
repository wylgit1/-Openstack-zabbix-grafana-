from django.shortcuts import render

# Create your views here.
from apps.snapshoot.models import SnapShoot
from apps.snapshoot.serializer import SnapShootSerializer
from utils.openstack_api.snapshoot.snapshoot_api import openstack_add_snapshoot,openstack_delete_snapshoot,openstack_update_snapshoot
from utils.viewset.CccViewSet import CccViewSet


class SnapShootView(CccViewSet):
    """
    快照的管理接口
    list:查询
    create:新增
    update:修改
    retrieve:单例
    destroy:删除
    """
    queryset = SnapShoot.objects.all()
    serializer_class = SnapShootSerializer
    create_api = openstack_add_snapshoot
    update_api = openstack_update_snapshoot
    destroy_api = openstack_delete_snapshoot

