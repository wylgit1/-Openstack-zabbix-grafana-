from django.db import models


# Create your models here.
# +--------------------+--------------+------+-----+---------+-------+
# | Field              | Type         | Null | Key | Default | Extra |
# +--------------------+--------------+------+-----+---------+-------+
# | snapshoot_id       | varchar(64)  | NO   | PRI | NULL    |       |
# | VM_id              | varchar(64)  | NO   | MUL | NULL    |       |
# | VM_name            | varchar(32)  | NO   |     | NULL    |       |
# | snapshoot_name     | varchar(64)  | NO   |     | NULL    |       |
# | snapshoot_describe | varchar(200) | YES  |     | NULL    |       |
# | snapshoot_user     | varchar(32)  | YES  |     | NULL    |       |
# +--------------------+--------------+------+-----+---------+-------+
class SnapShoot(models.Model):
    snapshoot_id = models.CharField(max_length=64)
    VM_id = models.CharField(max_length=64, blank=True)
    VM_name = models.CharField(max_length=64)
    snapshoot_name = models.CharField(max_length=64)
    snapshoot_describe = models.CharField(max_length=200, blank=True)
    snapshoot_user = models.CharField(max_length=32, blank=True)
